# decode诊断导入冲突来源更正

2026-09-12 23:22 SGT补充核对。

V2启动修正登记及V1失败收据把顶层`scripts`冲突归因于Agent-R1，这是过早归因，应更正。实际`importlib.util.find_spec('scripts').origin`为：

`.venv/lib/python3.10/site-packages/scripts/__init__.py`

`importlib.metadata.packages_distributions()['scripts']`返回`['verl']`。冲突来自已安装verl发布的常规`scripts`包遮蔽本项目同名namespace路径，不能归因于Agent-R1。

这不改变已确认的失败位置（创建LLM前）、0模型请求、或V2修复方式（直接导入唯一诊断模块，避免顶层scripts命名空间）。V2回归测试模拟任意外部scripts包，已覆盖实际冲突类型。冻结的V1/V2登记、源码及收据原文保留，最终报告以本更正为准；没有修改任何依赖源码。
