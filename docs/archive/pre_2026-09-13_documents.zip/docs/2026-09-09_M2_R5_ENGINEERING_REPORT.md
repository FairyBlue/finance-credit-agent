# M2 R5 有限工程验证报告（2026-09-09）

**全部 76 条工程轨迹完成，六个 cells 及最终独立审计通过；本批已停止，未启动主 screening。**
non-thinking + single_tool_v1 在本批真实更新、保存及同 worker 最终评估中没有触及响应上限。
但全部轨迹均无成功买卖或持仓，M2/plain 的实际 residual 为零；当前不能判定 M2 有效或无效。

人工时间统一为新加坡时间 SGT（UTC+8）。最终审计于 **9 月 9 日 12:08:08** 完成；
12:42 的读回复核确认服务 MainPID=0、退出码0。systemd 的 active/exited 是已完成状态。

## 执行范围与结果

本批严格沿用 [R5 登记](2026-09-08_M2_SCREENING_EXECUTION_AMENDMENT_R5.md)：四项1.7B
wiring 各8条训练、一次 actor/critic 更新、2条同 worker 最终 Train greedy；随后两个4B
pilot 各16条训练、两次 actor/critic 更新、2条最终 Train greedy。各 cell 从对应 exact base
新初始化，不使用旧 R4 权重或抵扣旧成功样本。全部评估窗口均为登记的两个 Train windows。

| 模型 / arm | 开始 → 完成（SGT） | 耗时 | Train / 最终 Train greedy | actor / critic 更新 | 结果 |
| --- | --- | ---: | ---: | ---: | --- |
| 1.7B A2 | 9月8日18:58:05 → 19:11:11 | 13分05秒 | 8 / 2 | 1 / 1 | PASSED |
| 1.7B M1 | 9月8日19:11:25 → 19:28:29 | 17分03秒 | 8 / 2 | 1 / 1 | PASSED |
| 1.7B M2-plain | 9月8日19:34:29 → 19:50:13 | 15分44秒 | 8 / 2 | 1 / 1 | PASSED |
| 1.7B M2 | 9月9日11:11:05 → 11:28:35 | 17分29秒 | 8 / 2 | 1 / 1 | PASSED |
| 4B M1 | 9月9日11:29:06 → 11:48:17 | 19分11秒 | 16 / 2 | 2 / 2 | PASSED |
| 4B M2 | 9月9日11:48:34 → 12:07:53 | 19分18秒 | 16 / 2 | 2 / 2 | PASSED |

耗时取 launcher 的 elapsed_seconds，含启动检查、初始化、训练、保存与最终评估；显示到秒的
起止时间有舍入差。两个4B pilot 均比当时30–50分钟的粗估更快；该预估已被实际结果替代。

合计64条训练、12条最终 Train greedy，actor/critic 各8次真实更新。每次更新均有非零梯度及
抽样参数变化证据；这些探针不等于对全模型每个参数的独立数值审计。

## 完整性与行为覆盖

| 模型 / arm | 请求数（Train + eval） | response tokens | 最长响应 | invalid（Train / eval） | 成功买卖 / 持仓轨迹 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1.7B A2 | 323 | 7,867 | 34 | 31 / 3 | 0 / 0 |
| 1.7B M1 | 304 | 7,589 | 34 | 29 / 2 | 0 / 0 |
| 1.7B M2-plain | 316 | 7,752 | 34 | 32 / 2 | 0 / 0 |
| 1.7B M2 | 320 | 7,711 | 34 | 30 / 2 | 0 / 0 |
| 4B M1 | 360 | 5,400 | 15 | 0 / 0 | 0 / 0 |
| 4B M2 | 361 | 5,434 | 34 | 0 / 0 | 0 / 0 |

总计 **1,984 次请求，41,753 个 response tokens，4,805,054 个 prompt tokens**。
请求记录均为 COMPLETE，4096响应上限触发0；所有轨迹均完整到达20个推进决策、21个sessions。
这支持本批有限工程完整性，不证明以后更长训练仍不会超长，也不表示原 thinking 路径已修复。

4B M1 的训练和最终评估全部为 hold，共360次。4B M2 为360次 hold 加1次 compute；
其所有推进动作也都是 hold。全批无成功 buy/sell、无正持仓，原始净收益为零。
两者最终两个 Train windows 的共同 scorer Y 分别相同：
`formal-train-0001 = -4.123583658505734`、`formal-train-0005 = -4.690993457725437`。
Y 包含相对 benchmark 项，不能把现金净收益0误认为 Y=0；这两个窗口的相同分数也不是正式
M2−M1 的统计检验结果。

1.7B 共131次 invalid，4B 为0。生产证据保存了动作结果、计数和请求哈希，但没有持久化
完整响应或工具错误原文，不能准确将这些 invalid 分类为 schema、多工具、lookback 等原因，
也不能据 action=invalid 推断模型原始响应从未尝试买卖。完整性通过不等于零非法动作。

## Residual 的实际读数

1.7B M2-plain 和 M2 各有32/40组开启 family diversity gate（80%），但同窗 siblings 的
终局 Y 相同，实际 plain/pooled S 都是0，pooling changed rows 也是0。

4B M1 和 M2 的每轮40组推进动作均为 hold，family diversity 和 pooling opportunity 都是0。
4B M2 两轮共320个训练推进 rows 的非零 S 计数为0，mean_abs_S和std_S也为0。
A2/M1 的 applied S=0则是对照定义，不是对 M2 机制的检验。

因此本批的准确结论是：**真实更新、checkpoint、同 worker 训练后生成及归档链路已运行；
交易、持仓和 residual 的实际作用尚未得到覆盖。** S=0时该 batch 的 residual 增量为0；
不同 arms 的轨迹长度、critic、U和权重不因此必然逐位相同。参数发生变化也不等于学到了
盈利交易信号。原 full-screening 的逐seed coverage判据不事后套用到这两轮pilot，更不追加
训练直到出现买卖或非零S。

## 资源、停止与证据

9月8日两次停止都发生在前一成功cell归档约2秒后、下一cell创建前的112GiB磁盘准入检查。
当时没有产生下一cell的训练轨迹；原STOPPED收据、日志和成功cells保留。恢复使用原生产
队列的PASSED保留分支，没有重训成功cells或恢复checkpoint。

9月9日管理员扩容已确认：容器可见容量621.79GB（579.09GiB），本批完成后可用约403.34GiB。
没有再次清理缓存或Python环境，agentr1保留。成功cells按既定归档策略完成checkpoint验收后
移除重权重/optimizer payload，保留marker、inventory、配置、轨迹和探针；它们不是现在仍可
加载的完整恢复点。旧FAILED checkpoint仍保留。

4B M1/M2 的共享cgroup采样最高memory.current分别为57.51/57.34GiB；各自采样区间
memory.high增加15/127，OOM和OOM-kill均无新增。共享cgroup读数不是单进程独占占用，
也不是连续采样得到的绝对峰值。未以trainer中的聚合GPU内存计数代替物理GPU峰值。

服务器systemd服务使用Linger=yes、stdin=null、KillMode=control-group、Restart=no。
最终退出码0、MainPID=0；本轮没有主动断开网络进行故障注入，进程生命周期不依赖SSH。
停止状态为 `ENGINEERING_COMPLETE_REVIEW_REQUIRED`；未自动启动主screening、Dev策略评估、
formal Valid或Final OOS。Prepared完整性检查会读取/哈希Dev文件，不应写成从未读取Dev字节。

冻结执行commit：`9e0a3f81f3cbfe7c4ef6ff30044d4113114149f4`。
R5配置SHA256：`c59d0c3c9b9f8107bbba1ba1b6151d5501c194fde7eb0f0722a3fd38d8c26715`。
最终审计SHA256：`bcbf6caae2bfb1bd6353696a2a9404393598cf866c8a9aeff408b8b1fc638d5c`。

原始收据位于 `runs/m2-screening-20260908-v11/`：

- `engineering_final_audit.json`：六cell及76条轨迹完整审计，包含独立重算的residual和证据文件哈希。
- `continuation_reentry2_result.json`：单次pilot退出码0与固定预算结束状态。
- `final_readout_20260909.json`：本报告数值来源；写报告前读回并核对审计绑定的176个文件哈希。
- 各cell的`summary.json`、`archive.json`、`artifacts/`及`resources.jsonl`：原始执行和机制证据。

完整token IDs、响应原文及全量U/critic/whitening tensors没有持久化，本次不能独立重新解码
所有EOS或重建全部GAE/白化张量。原最终审计及这些限制保留，不因文档更新改写执行身份。

## 下一步判断

当前不直接进入主screening，也不切换thinking。下一步建议先诊断共同non-thinking生产路径
为何几乎只选择hold：核对实际prompt、观测和工具约束是否提供清晰且可执行的买卖路径，
并补足原始响应/工具错误的记录能力。若需要新的模型诊断，先固定Train样本、共同设置和
有限预算，再观察行为；不按M2胜负挑prompt、不额外奖励买卖。是否采用此设置做主筛选，
应结合这些诊断和机制覆盖再决定。
