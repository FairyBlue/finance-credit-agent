# M2：4B从材料理解到真实交易的四组诊断

登记：2026-09-12，人工时间使用SGT（UTC+8）。用户已批准此前讨论的四组方案。本文件、文本与样本预算在GPU请求前冻结；本批仅使用4B，不启动训练、Dev/OOS或主screening。

## 问题与对照

[上一批](2026-09-12_M2_SEMANTICS_DIAGNOSTIC_REPORT.md)4B在明确参考定义后64/64题、448/448事实全对，但答题不等于在交易回合使用信息。1.7B三个说明候选未解决循环，后续行为诊断转向最终目标模型4B。此次要区分定义说明、投资目标及两者组合对真实工具动作的影响。

| 标签 | condition | 原features | 定义说明 | 投资目标 |
|---|---|---|---|---|
| A | features | 有 | 无 | 无 |
| B | features_defined | 有 | 有 | 无 |
| C | features_objective | 有 | 无 | 有 |
| D | features_defined_objective | 有 | 有 | 有 |

A→B是定义转移的主要对照，A→C与B→D分别检查目标文字在不同信息说明条件下的行为差异。四组同批完整报告，不选择收益或交易次数最好的提示词。两窗/八siblings只能作描述性诊断，不作显著性或普遍能力主张。

## 精确修改

全部复用旧`m2_decision_conditions.py`的features环境：20股原顺序、最近五条真实PIT close、price_change/mean_return/volatility；日期推进后重新计算，同日重复观察复用相同表。原features隐藏成功结果记忆和历史数量表，本批也保持这一点。状态、工具schema、解析器、成交、奖励及终止规则均保持原样。

B/D只读取冻结`m2_comprehension_probe.py`里的`INTERFACE_REFERENCE`和`METRIC_REFERENCE`，用固定`Reference definitions:`标题和换行拼接；没有复制quiz system、题目、答案或“不执行交易”的答题指令。C/D只读取冻结`m2_hold_probe.py`的原`OBJECTIVE`段落，原文不改：

> Your objective is to grow the portfolio's value after commission and slippage over the episode, while managing drawdown, turnover and concentration. Use the available point-in-time evidence to decide whether a trade is justified. Holding cash is allowed; there is no requirement to trade.

新增文字放入system前缀，随后由原renderer追加原样`single_tool_v1`。D按定义、空行、目标的顺序拼接；A完全不加前缀。原用户任务文本和当前状态不改。新增内容每个交易回合持续可见；仍输出一个真实tool call，不要求说明推理、不强制比较顺序或交易。

原目标段落此前只在无完整features表的首步诊断中得到hold，不能据此认定它在本批完整轨迹有效或无效；该段是通用净值/成本/风险目标，不宣称逐项精确表达benchmark-scaled scorer。所有训练reward、credit、arm标签和事后收益均不进入输入。

## 固定总体与预算

Qwen3-4B revision `1cfa9a7208912126459214e8b04321603b3df60c`，全新未训练base，仅加载一次。原`pilot_train.parquet`两行`formal-train-0001/0005`，source index0/4；每条通过四次真实脚本hold到共同session4全现金状态，再开始模型交互。该前缀不包含模型选择。

4条件×2窗口×8siblings=64轨迹；按窗口构成两个32条cohort，各含四条件。seed42、step1、sample_index=窗口0/1、rollout_n=0..7、validate=false；env_step只计模型请求、不含四次前缀。相同身份跨条件用同一seed规则，不声称不同输入或cohort与旧批逐token相同。

每条最多128次请求，与此前4B轨迹诊断一致。session4之后仍需16次合法日期推进才能到真实21-session终局。未done而达到预算记HORIZON_REACHED；输入/响应截断记INCOMPLETE，不执行截断动作、不补抽或重试。最多8192模型请求、33,554,432个response tokens；模型运行的256个脚本前缀hold另计，不与模型动作混算。

保持non-thinking、temperature1、top_p1、top_k−1、n1/request、原native EOS。输入8192、响应4096、context12288；BF16、vLLM V1、GPU memory utilization0.50、max_num_seqs32、max_num_batched_tokens16384、CUDA graphs[1,2,4,8,16,32]、原prefix/chunk缓存设置。诊断siblings8不改变正式训练n4。

## 验证与执行

新增显式候选模块与runner，不修改旧SHA绑定代码。复用旧执行器的独立模块实例，适配表纳入manifest。CPU验证A初始输入与旧features的messages/tools/token完全相同，B/C/D仅增加登记文字；真实脚本路径下表格、账本、奖励与终局一致，实际提示均不超过输入预算。测试固定总体、前缀隔离、预算和失败身份保留。

prepare保存真实初始输入、精确文字、源代码/包/模型/数据身份及前缀收据。服务器systemd user service、Linger=yes、stdin=null、Restart=no、KillMode=control-group、三小时上限、文件日志，独立于客户端网络；不注入真实断网，不删除文件。来源、映射或引擎异常停止并保存部分总体，观察到hold/循环等行为则正常完成剩余固定人口。

结束后核对所有身份、原始tokens/EOS、实际动作/环境反馈、持续提示因素、PIT指标及真实成交。记录完整性、无效/重复工具、股票覆盖、持仓/交易、每窗siblings动作和终局结果差异。只有真实完整轨迹才报告正式终局指标，失败留在固定分母；零交易或有交易均不自动代表通过，观察到动作变化不等于证明使用了某个指标或形成盈利策略。

运行目录`runs/m2-transfer-diagnostic-20260912/trajectory-v1/`。写独立报告、机器汇总和SGT最新进展；保留旧证据。本次完成后只提出下一步，不自动更新训练默认配置或追加实验。
