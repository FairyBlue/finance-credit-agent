# M2：历史可用性与工具结果记忆诊断计划

登记日期：2026-09-09，新加坡时间 SGT（UTC+8）。状态：执行前登记；用户已同意检查历史信息、修复工具结果记忆，并验证完整 Train 轨迹。结果另写报告，不根据结果修改本计划。

## 1. 已知问题与本次问题

旧环境每步重建当前状态，仅保留最近三次调用参数和最新一次工具结果。计算第二只股票后，第一只股票的计算数值会从下一次模型输入中消失。这是已确认的观察设计缺口；尚不能据此断言它造成了全部 hold。

历史原因是上下文溢出：2026-08-27 的 G1 审计发现初始输入 5,141 tokens、八次 hold 后 40,285 tokens；后续改为固定前缀加当前状态，但没有同时实现有界结果记忆。长度验收不能证明信息保留正确。相关记录见 `docs/2026-08-27_H100_G1_AUDIT_RESULTS.md` 和提交 `9b72dca27d0f4ca0fa35ad534820cbd1ed32c94c`。

上一项 48 个首步请求的诊断保持原样：修复工具 schema 后，4B 仍全部 hold；1.7B 第一窗因历史不足而 compute 失败。中性目标文本 C 没有被采用。本次检验：明确显示可计算的历史数量、保留跨股票工具结果后，固定完整轨迹是否能完成，工具错误及动作分布有何变化。

## 2. 新观察版本 `history_memory_v1`

保留原有当前行情、现金、持仓、会话进度、最近三次调用参数，以及完整的 `last_tool_result`。新增两项：

- `compute_history`：每只冻结股票当前实际可见的 close 记录数量；计算最少需要 2 条，lookback 参数最大 60。计数复用 `_compute` 的同一可见记录选择方法，按原适配器的可用时间和顺序处理，不偷读未来数据，不增加新历史数据。
- `tool_result_memory`：成功的 compute/retrieve 结果进入每条轨迹独立的记忆。compute 行保留 symbol、metric、lookback_requested、lookback_used、原始 as_of、原始数值；retrieve 保留已有工具返回的完整结果和有界调用摘要。hold、交易和 invalid 不清空记忆，reset 清空，跨轨迹不共享。

记忆最多 20 条成功结果，其中 retrieve 最多 2 条；整个紧凑 JSON 对象最多 4,096 ASCII 编码字节。超过容量时淘汰最旧条目，公开 retained/evicted/refreshed 数量与容量。20 条结果不等于保证覆盖 20 只股票。相同工具、完整规范化参数、相同 as_of 的重复调用刷新原条目；新日期另存一条，保留来源时间，不把旧数值伪装成今日重算。完整参数用于去重，不使用截短的 query 作为键。

当前结果已经出现在 `last_tool_result` 时，表中省略这一个重复副本，并用 `current_result_in_last_tool_result` 标明；它仍计入 retained_count。下次观察不再带该字段时，记忆重新显示此项。retrieve 的 query 和可选 symbol 摘要分别最多 80 个 ASCII 字符，显示是否截短；不截短记忆里的工具返回结果。记忆容量不等于无限聊天历史，原始交互记录另作审计证据。

历史数量是 **可见 close 记录数**，不是交易日数；不增加去重、排序或独立 event_at 规则。请求 lookback=60、实际只有 5 条时仍按原计算规则使用 5 条；只有少于 2 条时不能计算。未来数据隔离、同时间版本、非 market 数据等由真实环境 CPU 测试验证。

## 3. 共同输入预算修订

真实 tokenizer 预检显示：增加结果表后，20 条 compute 记忆加持仓和 retrieve 可超过旧 4,096-token 输入上限。本次两组统一使用：

| 项目 | 本次固定值 |
|---|---:|
| 输入上限 | 8,192 tokens |
| 单次输出上限 | 4,096 tokens |
| engine context | 12,288 tokens |
| max_num_seqs / 最大活动批次 | 8 / 8 |
| max_num_batched_tokens | 8,192 |
| rollout GPU memory utilization | 0.20 |

这是新的观察与资源版本。两组具有相同预算；不能拿旧 4,096 输入限制下的失败率直接充当本次对照。输出限制、自然 EOS 判定、non-thinking、已有 single_tool_v1、工具 schema 和采样设置保持一致。不偷偷截短模型输入、不依赖自动截断。超过 8,192 的输入保留全文证据并标记该轨迹 INCOMPLETE。

上线前用实际缓存 tokenizer 检查有压力的合成状态；合成数据只用于 CPU 工程检查，不进入模型诊断或学习数据。此预算尚未通过 actor/critic 更新、checkpoint、同 worker 最终评估的资源门禁，不继承旧 R5 的训练验收。

## 4. 固定 32 条完整 Train 轨迹

| 因子 | 固定值 |
|---|---|
| 模型 | fresh Qwen3-4B、fresh Qwen3-1.7B，各使用此前冻结的本地 revision |
| 观察 | legacy、history_memory_v1 |
| Train 窗口 | 原 pilot_train 的 formal-train-0001 / 0005，source index 0 / 4 |
| 每个窗口每组 | 4 条 sibling，固定 seed 42 的生产派生方式 |
| 总量 | 2 模型 × 2 观察 × 2 窗口 × 4 = 32 条 |

每个模型仅加载一次，顺序为 4B 后 1.7B；每个模型先 legacy 的 8 条，再新观察的 8 条。每条初始会话 index=0，21 个 sessions，必须真实完成 20 次有效推进且仅最后一步 done，才能记为 COMPLETE。compute/retrieve/invalid 不冒充推进。

每条最多 256 次模型请求，因此总请求最多 8,192，总输出 token 上界 33,554,432。身份为 step=1、sample_index=窗口索引、rollout_n=0..3、validate=false，逐环境请求派生 seed。temperature=1、top_p=1、top_k=-1。两组使用相同种子规则，但输入和活动批次不同，不承诺 token 级复现。

冻结全部 32 个身份。输入/输出/步数上限失败只终止该条，其他既定轨迹继续；不重抽、不补齐、不拼接、不恢复旧 checkpoint。基础设施、数据、来源哈希或请求对应关系失败时停止模型及后续控制器，不重试。未开始的身份保留为 UNSTARTED，不能从分母消失。

## 5. 证据、执行与判读

执行脚本为 `scripts/diagnostics/m2_observation_probe.py`，新目录为 `runs/m2-hold-diagnostic-20260909/observation-v1/`。prepare 仅使用 CPU，冻结计划、源码、包版本、模型与数据身份；legacy 两窗初始 token IDs 必须逐个等于上一项修复 schema 的 B 组，两个观察组的原始前缀和工具定义必须相同。

每次请求记录实际完整 messages/tools、prompt IDs、派生 seed、传入和有效采样参数、vLLM 请求对应关系、原始输出 token IDs、EOS/finish reason、解码后的实际动作和真实环境返回；逐步记录会话推进、错误与成交。完整轨迹才记录环境原始终局 finance metrics（含共同 scorer 的 terminal_score），仅作描述，不按收益选观察、模型或样本。本次不构造训练 advantage/residual，不声称 M2 获益。

服务器使用独立 systemd user service，Linger=yes、StandardInput=null、Restart=no、KillMode=control-group、文件日志与进度收据。控制器各模型最多一次，磁盘和 GPU 启动前检查；整个服务最多三小时，超时保留失败，不自动续跑。服务独立于客户端连接；不假称已经实际注入断网测试。

验收分开记录：

1. 代码性质：真实环境跨股票记忆不丢失，PIT 边界不变，reset 隔离，成交/账本/奖励/trace 不变；四个 screening arms 使用同一显式观察配置，默认 legacy 和旧配置不变。
2. 轨迹工程：固定 32 条状态齐全、逐步请求与动作一一对应、自然 EOS、输入与输出限制、真实 20 次推进。
3. 行为观察：各模型/观察的完整率、动作数、invalid 原因、工具循环、计算股票覆盖、成交及持仓；即使全 hold 仍如实报告。新组同时改变历史可用性提示和记忆，因此行为变化不能单独归因于其中一个组件。

不训练、不更新权重、不做 Dev 策略评估、formal Valid、Final OOS 或主 screening。本次结束后形成报告；若完整性通过但行为仍退化，保留这个结论，再决定下一项有界诊断。
