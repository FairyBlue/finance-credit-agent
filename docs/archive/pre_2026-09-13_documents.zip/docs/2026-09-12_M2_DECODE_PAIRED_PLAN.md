# M2：同进程自然decode与事后评分配对诊断

登记日期：2026-09-12 SGT，GPU执行前冻结。

承接概率路径报告及用户“继续”的授权。保持已安装vLLM及训练默认代码不变，不升级依赖，不更换模型，不强制交易。本批只做一次小型诊断，完成后报告，不自动扩大实验。

当前安装的V1尚无自定义logits processor扩展；结构化输出的grammar mask在sampler读取原始概率之前应用。因此不通过这些方式强制旧234个token，也不将受约束概率当成原分布。改用原8个固定输入，各生成一次，再对每条实际输出配对评分。**输出人口发生变化，不能替代上一批固定输出的失败记录。** 不再重放旧1024人口。

沿用Qwen3-4B原revision、BF16、原vLLM缓存/graph/并发32配置及原non-thinking输入。8请求同批提交，各使用原sibling0请求的seed和temperature1/top_p1/top_k−1，max_tokens4096。只运行一次；不根据是否hold、输出是否等于历史或概率是否通过来补抽。若不完整、缺证据或基础设施失败，记录并停止，不重试。

使用vLLM公开collective_rpc接口，在本项目模块中注册只读PyTorch sampler前后观察回调。前回调复制输入logits及请求位置；后回调在副本上计算FP32 log_softmax，保存实际选中token的原始概率、logit、归一化常数、rank、请求ID、已有输出prefix、已计算KV长度、当前调度token数和最后输入位置。回调返回None，不改变输入、返回值、随机数状态或采样器实现。GPU启动后安装，生成后移除；不在site-packages写入或monkeypatch方法。观察回调增加同步和运行开销，不保证与无观察的历史调度相同。

首token来自prompt prefill，其余token只有在已计算KV/位置、当前调度长度及历史prefix全部匹配时才记为已验证decode。chunked prefill尚未完成时的临时采样记录单独保留，不能计为最终输出。所有实际输出token包括EOS必须一一匹配观察记录；观察原始概率与公开返回概率最大差≤1e-5才允许解释配对结果。

随后移除回调，仍在同一LLM实例中，将8条完整实际输出连同EOS附于原prompt，以prompt_logprobs对每个实际token重新评分；每条只生成1个辅助token，不执行。原校准阈值逐token绝对差≤0.1、整条logprob和差≤0.5，8/8才通过本批配对门禁。报告首token与后续decode分别的最大差，以及与历史输出是否相同；不选择其中匹配的子集代替整体结果。

预算上限：8次自然请求（合计至多32768输出tokens）、8次评分请求及8个辅助token。0环境动作、0训练、0完整交易轨迹、0 Dev/OOS。输出不是强制旧文本；如产生交易调用也不执行，不更新成交率。

先做CPU观察回调不干预测试、token/来源核对与源码冻结。服务器独立systemd user service，Linger=yes、stdin=null、Restart=no、KillMode=control-group、一小时上限，持久化记录，不依赖客户端连接。结束后独立重算全部概率比较，检查依赖源码未变，写报告与SGT进展。若本批仍失败，不据此宣布vLLM损害交易能力，也不无限追查底层；报告未解决范围和对交易实验的实际限制。
