# M2：工具状态说明与4B信息理解诊断

登记日期：2026-09-12，时间使用新加坡SGT（UTC+8）。用户已批准执行[上一批报告](2026-09-09_M2_DECISION_DIAGNOSTIC_REPORT.md)的下一步。本文及问题、评分规则在本批模型请求前冻结；本批结果另写报告，不修改旧报告或补抽旧样本。

## 要解决的问题

上一批1.7B的raw与memory_only各16/16完整，history_only为5/16、both为1/16。退化同时涉及真实历史不足的错误重试、历史充足时的合法重复compute；成功结果记忆及PIT数量核验一致。4B直接获得全部20股指标后仍主要hold/abstain，仅一次买入，尚不能判断是任务理解、信息语义还是决策倾向。

本次沿两条线推进：将历史可用性和时间说明分开检验；用预先固定事实答案检查4B能否读懂任务、指标和信息边界。不增加交易次数门槛、不改奖励或买卖执行规则，不将选择现金本身标为错误。

## A：1.7B的两个说明因素，64条固定轨迹

采用原Qwen3-1.7B revision、原`pilot_train.parquet`的两个Train窗口`formal-train-0001/0005`，source index为0/4。从原session0开始，不添加前缀。每窗口每条件8条，rollout index 0..7，base seed42，生产seed identity为step1、sample_index=窗口索引、rollout_n=0..7、validate=false、env_step=本条模型请求序号。

| 条件 | 旧有界结果记忆 | 新可用性状态 | 新时间说明 |
|---|---|---|---|
| memory_only | 有 | 无 | 无 |
| availability | 有 | 有 | 无 |
| time_semantics | 有 | 无 | 有 |
| availability_time | 有 | 有 | 有 |

所有条件隐藏旧`compute_history`数量表，保留同一`tool_result_memory`实现。两个新因素仅加入当前观察JSON，原任务、工具schema及`single_tool_v1`系统文本保持一致。memory_only须用CPU证明与上一批同名条件的实际观察/token一致；其余条件只能增加登记的独立字段。该新环境仅作为显式诊断候选，正式配置默认值不变。

可用性字段`compute_availability`包括原始as_of、固定说明、`[symbol,status]`表。按冻结20股原顺序列出，每股真实PIT可见close数量至少2时为`ready`，否则为`unavailable`。说明区分“历史要求满足”与“参数仍必须有效”；不展示原最小值/数量表，不把任何股票硬编码为可用，不改变实际参数校验或工具列表。准确文字及字段顺序由冻结源码和真实prepare输入共同绑定。

时间字段`decision_time_semantics`分四点说明：成功的buy/sell/hold/abstain推进一个session；compute/retrieve/invalid不推进；同日期相同参数的compute不会使新数据变得可用；保存结果保留原as_of，日期推进后需判断其是否仍适用于当前决策。它不额外展示历史数量或可用性。组合条件是两字段的并集。

按窗口组成两个固定cohort，每个32条（四条件×8），无新身份补位。每条最多64次模型请求，总上界4096。到真实done才记COMPLETE（21个sessions、20次合法推进）；预算到达且未done记HORIZON_REACHED。输入/响应截断记INCOMPLETE，该身份永久停止，不重试、不补全模型输出。自然EOS但工具格式或参数无效的动作由原环境正常反馈。

主要读数为每条件固定16条的完整/预算到达/截断计数、真实日期推进、历史不足错误、合法重复compute、无效格式、调用股票与结果来源。分别报告两个窗口，区分不可用状态重试与可用状态循环；保留动作、真实成交及完整终局原始指标，不按收益筛选。对照用于检查显示方式的行为影响，不将这两个窗口的完整率外推为训练稳定性，也不将memory_only视为已证明优于raw。

## B：4B的固定事实理解检查，64次独立请求

采用原Qwen3-4B revision，同两个Train窗口各通过真实环境执行四次hold，固定在session4全现金状态。每窗口只构造并冻结一个共同快照；这些是脚本构造，不是模型选择，也不用于训练。沿用上一批features实现，展示原顺序全部20股、lookback5的price_change/mean_return/volatility，原始值只来自当前PIT。

四个题族×两窗口×8个siblings，共64个独立单轮请求，没有追问、提示修正或模型交易动作。每题都提供相同引用材料：原任务文本、原串行工具规则、真实工具schema与状态，以及从冻结环境实现提取的指标定义和接口时间说明。新的system明确这是材料阅读检查，引用的工具调用规则不是要求当前执行交易；工具schema作为材料提供，不注册为当前可调用工具。输出只需短结构化JSON事实，不要求内部推理。

因此这项检查衡量的是**补充明确定义后的任务/信息理解**，不能声称测出了旧裸表的自发理解或真实交易能力。不会把原任务未明确声明的收益目标当作原文事实。

| 题族 | 内容 | 预先固定评分 |
|---|---|---|
| 任务与接口 | 任务类别、每轮工具数量、成交时间、hold合法性及推进、未来信息/做空/杠杆 | portfolio_management；1；next_open；hold合法并推进；未来价格/做空/杠杆均否 |
| 数值读取 | 原symbols顺序前三股GS/MSFT/HD的三个显示指标 | 9个数值和股票身份逐字段核对，原数值绝对误差≤1e-8，不转换成百分数 |
| 指标含义 | 5个close对应几个相邻收益、三指标定义 | 5；4；最后/最初−1；相邻simple return算术均值；相邻simple return总体标准差 |
| 信息边界 | 全20股历史指标和当前cash/positions是否已给，下一开盘价或未来收益保证是否已给；过去上涨是否保证下一期上涨；是否需再compute才能读已有表格 | 前两项是，后四项否 |

问题提供固定字段格式和合法枚举代码集合，避免将代码名称猜测当成理解能力。各题按精确键、类型、字段事实和整题全对分别计分。数值拒绝bool及非有限值；JSON拒绝重复键、NaN、围栏或前后额外文本，不修复模型答案。格式错误、事实错误、截断和未开始身份都留在固定64分母内，不能只统计可解析答案。

理解检查的seed另行登记：base42，step1，sample_index=4×window_index+question_index，rollout_n=0..7、validate=false、env_step0。每窗口四题×8形成一个固定32请求批，共两批。不执行模型输出的env.step，不将这64个答案称为64条完整交易轨迹，不与A的COMPLETE合并。

## 共同资源、来源与停止规则

沿用本地冻结模型和环境包：vLLM0.9.2/V1、torch2.7.0+cu128、transformers4.53.2，BF16、non-thinking、temperature1、top_p1、top_k−1、n1，原EOS合同不变。两个模型各加载一次，依次运行，允许CPU预检与代码工作并行。

输入8192、响应4096、context12288；GPU utilization0.50、max_num_seqs32、max_num_batched_tokens16384、CUDA graphs `[1,2,4,8,16,32]`，prefix caching/chunked prefill沿用已验证设置。A最多4096请求，B固定64请求，总上界4160请求、17,039,360个response tokens。八个sibling身份仅用于独立诊断，不改变训练n4。

prepare读取真实原Train数据与tokenizer，冻结两份独立manifest、实际输入、模型/包/源码及本计划。旧runner与观察模块按已有SHA校验后复用；若用独立模块实例适配执行器，适配表和无串扰测试必须保存，不修改旧源码文件。额外新候选与题库也全部纳入对应来源清单；答案来源、评分规则和格式规则在GPU请求前冻结。

所有原始messages/schema/token IDs、原始响应、有效采样参数、动作映射、环境反馈和终局记录落盘。数据/来源、输入对应关系或引擎异常停止相应运行，保存已完成、部分结果和未开始身份，不启动替代样本。语义错误或不完整轨迹是需要保留的实验结果，不按成功与否重复运行。

服务器systemd user service、Linger=yes、stdin=null、Restart=no、KillMode=control-group、文件日志；控制作业最多三小时，独立于客户端网络。记录退出码、GPU资源及容器OOM计数；不声称已经注入真实断网故障。已扩容磁盘约有403 GiB空闲，无清理需求。

## 验证、交付与后续边界

先完成显示因素独立性、PIT可用性、memory_only兼容、状态/账本不变、请求上限与不重试、评分器负例和实际输入预算的CPU检查。沿用已有奖励核验，不重复12条市场策略运行，不修改奖励/风险/成本系数。验证新代码及受影响测试，不为无关平台启动扫描超时反复运行全套测试。

本批结束后独立核对固定64轨迹和64理解请求、全部seed/原生EOS/原始响应映射、实际PIT与结果记忆、字段评分。每条训练候选的不完整状态均保留。依据实际结果判断新的状态说明是否减轻两类循环；理解正确仍选择现金，不能直接判成策略错误。

新增代码：`m2_semantics_conditions.py`、`m2_semantics_probe.py`、`m2_comprehension_probe.py`及对应测试。新目录：`runs/m2-semantics-diagnostic-20260912/trajectory-v1/`、`comprehension-v1/`。写独立报告及机器汇总，更新SGT的`runs/M2_SCREENING_LATEST.md`；旧证据与已有未提交工作全部保留。

本次授权落实上述两项诊断；不会因单批表现改善而自动进入训练更新、Dev/OOS或主screening。需要继续扩大验证时，先据实际结果形成明确后续方案。
