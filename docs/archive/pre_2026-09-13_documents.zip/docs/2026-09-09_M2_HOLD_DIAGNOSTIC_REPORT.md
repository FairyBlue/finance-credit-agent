# M2 R5 全现金行为：诊断与代码修复

当前状态（2026-09-09 14:34:55 SGT）：代码修复、CPU 回归、固定 48 个首步请求与独立核验均已完成。
GPU 作业已于 14:32:49 结束，当前没有训练或诊断进程运行。
人工时间统一为新加坡时间（SGT，UTC+8）。

已经找到并修复工具接口的确定缺陷，但 **4B 的全 hold 行为仍未解决**：旧接口、修复接口和
追加中性目标文本三个条件均为 8/8 hold。1.7B 则暴露了首窗可用历史不足的具体错误；
追加目标文本也使它全部转向 hold，因此该提示词候选不设为默认值。
本轮保留共同 non-thinking，没有修改奖励或通过要求买卖来制造 M2 residual。
旧 R5 仍为工程完整性通过、机制覆盖不足。

## 已确认的问题与排除项

| 项目 | 证据与结论 |
|---|---|
| 工具参数说明与执行不一致 | 上游 schema 转换丢弃范围、长度、默认值和额外字段限制；例如模型可见 schema 允许 `lookback=1`、`target_weight=1.1`、`hold(reason=...)`，环境实际拒绝。已修复。 |
| 旧日志缺少动作原文和错误 | 成功请求仅有响应 hash，环境 `info` 未持久化，无法重建 R5 1.7B 的 131 次 invalid 原因。已为新运行增加可选完整诊断。 |
| 训练误用 greedy | 未发现。配置和真实方法的 CPU 参数交接为 Train temperature=1、eval=0；旧日志不含引擎逐请求参数，不能把配置当成完整现场收据。 |
| seed 重复或缓存返回同一 hold | 4B M1/M2 共 721 个请求逐个重算匹配，臂内无 seed 碰撞；有 40/43 种 prompt hash，M2 存在一条不同 compute 响应。没有发现回答缓存复用。 |
| 输入被写死为 hold | 旧首 prompt 精确重建为 2382 tokens，匹配实际 hash；末尾只有 Qwen non-thinking 的原生空 thinking 前缀，没有 hold 文本。 |
| 买卖分支不可用 | 合法 buy 与 sell 经真实 Hermes→TradingEnv.step→next-open 成交路径通过。空仓 sell 或目标方向错误仍应拒绝。 |

工具约束修复发生在本地 [src/env/tools.py](../src/env/tools.py)，从真实 `_ARG_MODELS`
导出完整 schema，绕过上游有损导出。工具名称、描述、运行时参数校验、解析器和成交规则保留。
公开 schema 表达规范 JSON 参数；运行时原本支持的数值字符串转换也仍支持。

真实两个缓存 tokenizer 均确认新增约束完整进入模板。同一个首 prompt 增至 2553 tokens，
增加 171，低于 4096。新 schema 也改变了 JSON 字段顺序，因此模型对照应视为完整 schema
展示方式变化，不能把输出变化仅归功于其中某个约束。

## 仍待验证的行为解释

原始任务只有 “Manage the portfolio using only point-in-time tools.”，串行工具规则也没有明确
资金增长、成本和风险目标。这可能让模型倾向安全的默认动作，但原有文本在此前运行中也存在，
尚不足以单独解释 R4→R5 的变化。

环境每步只保留当前行情、最近三次调用参数和最新一次工具结果。连续计算不同股票时，前一个
计算数值不会继续保留，可能限制跨股票比较。第一个 pilot 窗口首步只有一根可见 close，
无法完成至少两根价格的 compute；第二个窗口首步有五根，并不是所有 session 0 都没有历史。
本轮不改观察历史和窗口，也不加入更早或未来行情。这些限制不能仅凭代码阅读认定为 hold 原因。

## 新的诊断记录

在新的 screening settings 中显式添加：

```yaml
capture_interactions: true
```

[launcher](../src/agents/screening_launcher.py) 将它绑定到解析后的配置和运行身份，并传给
`data.screening_capture_interactions`。省略时保持旧成功响应 hash-only 行为。

[flow](../src/agents/agent_flow.py) 保存有界输入/输出 token IDs、管理器请求 ID、该边界实际
转发的 sampling 参数、停止原因；[environment](../src/env/trading.py) 保存真实收到的动作文本、
返回观察、工具错误和成交信息。每段文本最多 65536 字符、token 前缀最多 4096，均有截断标记
和全文 hash。数据留在证据文件，不进入模型观察或奖励。

管理器 request ID 与转发参数不等同于下游引擎收据；独立模型诊断会另外记录原生 vLLM 信息。
生成被截断时不执行环境，不补造 step；流程复用后环境创建失败时不沿用前一条证据。
非法非文本 Action 仍按原语义返回 invalid，不因开启记录额外崩溃。

## 验证与有限模型诊断

- 全套非 integration CPU 回归：748 passed、137 subtests passed、1 deselected；
  这次收集发生在新首步 runner 测试文件落盘前。
- 首步 runner 单独 39 项测试通过，覆盖 48 请求表、seed、EOS/cap、输出错配、非法动作、
  引擎/解码异常保留原 tokens、不补抽与禁止覆盖已有结果。
- 修改的四个运行时源文件 mypy 通过；已有修改的 Ruff 与 diff 空白检查通过。
- 真实环境测试覆盖有效买卖、compute、invalid、完整终止以及开关前后的观察/奖励/credit 等价。
- 新首步诊断按 [预登记计划](2026-09-09_M2_HOLD_DIAGNOSTIC_PLAN.md) 固定最多 48 请求，
  只用两个原 Train 窗口、两个 fresh base、三个条件。不会重启主 screening。

固定结果如下。A 是旧 schema，B 是修复 schema，C 是 B 加预登记的中性目标文本。

| Fresh base | 条件 | 完整响应 | 首步动作 | invalid / cap | 每响应 tokens |
|---|---|---:|---|---|---:|
| 4B | A | 8/8 | hold × 8 | 0 / 0 | 15 |
| 4B | B | 8/8 | hold × 8 | 0 / 0 | 15 |
| 4B | C | 8/8 | hold × 8 | 0 / 0 | 15 |
| 1.7B | A | 8/8 | 有效 compute × 4；invalid × 4 | 4 / 0 | 34 |
| 1.7B | B | 8/8 | 有效 compute × 4；invalid × 4 | 4 / 0 | 34–35 |
| 1.7B | C | 8/8 | hold × 8 | 0 / 0 | 15 |

48/48 响应均自然 EOS 完整，最长 35 tokens，没有 4096 cap；合计 1025 response tokens、
119800 prompt tokens。环境有效动作 40 次、invalid 8 次；无买卖或成交。
“完整响应”只表示生成完成，不能代替环境合法性，更不表示完成了交易轨迹。

4B 从 14:21:31 启动到 14:28:16 退出约 6 分 45 秒，主要耗时在文件扫描、加载与初始化；
推理引擎于 14:28:13 就绪，24 个请求于 14:28:14 全部记录完毕。退出码 0。
`screening/result.json` SHA：`5f69341d3cea1ef057c75593e60429570066155bb10ce15e28ccf60d08762e6b`。
1.7B 从 14:28:18 到 14:32:47，约 4 分 28 秒；推理引擎于 14:32:43 就绪，
24 个请求于 14:32:45 记录完毕。退出码 0。
`wiring/result.json` SHA：`599f1397864705155bccbecfc20cb93c7c26459ad71363ad755c85fcf16a6382`。

1.7B 的具体错误全部来自第一个窗口：

- A：三次合法的 `compute(AAPL, price_change, lookback=2)` 因只有一根可见 close 而失败；
  另一次 `lookback=1` 直接违反参数下界。第二个窗口四次 volatility 计算成功。
- B：四次 compute 参数均在合法范围内，但仍因只有一根 close 而失败（lookback 为 2/2/20/2）；
  第二个窗口四次 mean_return 计算成功。本批未再出现 lookback 越界，invalid 总数仍为 4/8。
- C：八次都改成 hold。invalid 降到零同时伴随全部工具尝试消失，不能认定交互能力改善。

两条件合计八次 invalid 中，七次为实际历史不足、一次为参数下界违规。这是本轮新采样的
错误分解，**不能反向推断旧 R5 的 131 次 invalid 也是同一分布**。

独立核验了每条 seed、采样参数、prompt IDs、原始响应 tokens、解码文本和真实环境 step 对齐。
这支持“schema 修复或这段目标说明均未改变两个固定初始状态下的 4B 首步动作”，
不支持“完整轨迹已修复”或“M2 学习无效”。本轮不会为得到 buy 而继续追加提示词或抽样。
1.7B A→B 的八条响应 tokens 全部改变，但成功/invalid 动作族未变；B→C 八条均变成 hold。
本轮没有依据支持提高 temperature、增大 token cap 或切换 thinking；也没有比较两种思考模式。

服务 `fca-m2-hold-probe-v1-20260909.service` 独立于 SSH，Restart=no，已按预算结束。
最终 MainPID=0、ExecMainStatus=0、Result=success；active/exited 是保留的完成元数据。
GPU 显存占用回到 0 MiB，cgroup high/max/oom/oom_kill 本轮增量均为 0。没有清理缓存或环境。

冻结 manifest SHA：`0b3ac1091f20182a0ae0ad74fad817b0f68394956bb5ceefbf6c24ea74916ab3`。
63 个运行源码/计划文件已逐项 hash 核对后保存为 `probe-v1/source_snapshot.tar.gz`，
归档 SHA：`e78afcfb9c5c5f5d1711aa30e4c9498ed3537a642e168b71e9df317f9ae60596`。
工作树修改未混入旧 R5 的执行身份；新 manifest 同时记录各文件实际 hash。

独立核验状态：`ALL_48_FIRST_STEP_EVIDENCE_VERIFIED`；审计文件 SHA：
`7899628dbe513a71751320494fc359c76b2cd8ee902e574f47846aad1fa28e8b`。
最终读数 `probe-v1/final_readout.json` 绑定 92 个证据文件，SHA：
`19abe93e2e5f0252e9148ffb951494cb6da70c5a7eb2351b40b35aa2f66f8dd8`。
这是证据一致性验收，完整轨迹数和训练更新数均为零。

## 下一项工作应解决什么

优先检查共同观察中如何表达 **实际可用历史数量**，以及如何有界保留最近工具计算结果，
让模型能判断何时 compute 可用，并比较先前计算。首日真实缺数据时必须保留这一事实，
不能填造收益/波动率或悄悄更换窗口。短期工具记忆和历史提示的行为影响仍待独立对照验证。

在新的观察合同、输入预算和共同配置登记后，再做固定的完整 Train 轨迹检查，观察工具反馈
之后的动作、终止、交易与组内结果差异。现在直接追加 M1/M2 训练缺少依据。本轮已按 48 请求
边界停下，不把 C 设为正式提示词，也未自动重启主 screening。

CPU 证据目录：`runs/m2-hold-diagnostic-20260909/`，包含 `mechanism_cpu_evidence.json`、
`schema_prompt_delta_cpu.json`、`runtime_sampling_cpu_probe.py` 及对应结果与只读复核。
旧 R5 结果见 [工程报告](2026-09-09_M2_R5_ENGINEERING_REPORT.md)，保持原执行身份。
