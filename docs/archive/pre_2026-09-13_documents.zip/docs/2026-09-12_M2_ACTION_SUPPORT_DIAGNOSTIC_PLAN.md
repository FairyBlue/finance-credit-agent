# M2：4B 固定状态动作概率与采样覆盖诊断

登记时间：2026-09-12 SGT（UTC+8），模型请求开始前冻结。

用户已授权按交易转移报告的下一步推进。本批检查同状态下交易动作的概率支持、自然采样频率及真实环境接受情况；完成报告后停止，不自动启动探索训练、初始化、主 screening 或追加模型请求。

使用上一批四个条件 features、features_defined、features_objective、features_defined_objective 和两个原 Train 窗口的 session4 全现金状态。八个输入直接绑定上一批 manifest，并以原环境四次脚本 hold 重新构造核对。保留全部 20 股票，不选事后出现交易的日期或股票，不改提示。

固定 Qwen3-4B revision `1cfa9a7208912126459214e8b04321603b3df60c`、non-thinking、temperature1、top_p1、top_k−1、n1、响应上限4096、原 EOS、8192/12288 输入/context、BF16、原32并发及缓存/graph设置。自然采样额外返回所采样 token 的 logprob，不改变分布。vLLM 0.9.2 本地源码表明请求 prompt_logprobs 时跳过前缀缓存；评分请求沿用同一引擎，登记此差别。

**自然采样：1024 次单步请求。** 每输入128个固定身份，rollout_n=0..127，seed42、step1、sample_index=窗口0/1、env_step0、validate=false；同窗口跨条件使用同一 seed 规则。前8个身份与上一批初始请求相同，但不声称不同批次逐 token 相同。按128个 sibling 分成四个32条 batch；窗口、条件、batch依次固定。所有128个分母保留，不在看到足够交易或零交易后提前停止。

每个完整输出在独立重置到同一session4的真实环境中只执行一次，记录完整/截断、请求工具、参数、invalid原因、现金/持仓变化和成交。无效动作原样记录，无修复、补抽或后续回合。输出上限记INCOMPLETE且不执行。这里的完整仅指一次响应，不是完整轨迹；不生成终局收益或评分。

**预先指定文本的概率：384 次评分请求。** 每个输入使用42个合法完整动作：hold `{}`、abstain `{}`、按原symbol顺序20个 buy `target_weight=0.1`、20个 compute `metric=volatility, lookback=5`。固定字段顺序、JSON空格、tool_call换行和末尾EOS；prepare逐个在真实环境验证合法，脚本成交不计模型成交。现金状态没有合法sell，故没有完整sell候选。

另每输入给出六个固定工具名路径，顺序 buy/sell/hold/abstain/compute/retrieve：`<tool_call>\n{"name": "NAME",`。读取指定token序列的 prompt_logprobs，分别报告从完整原prompt出发的路径logprob，以及在固定格式前缀后的名字路径logprob；不将限定候选重归一化为整个动作类别概率，不做长度平均后冒充序列概率，不假设其他JSON格式/理由/仓位的概率为零。sell的名字概率只表示文本支持，不表示当前状态下合法。

**评分一致性：最多8次固定核对。** 每输入仅核对预先指定的 sibling0 自然输出，把其原token IDs（含EOS）重新作为评分后缀，比较逐token生成logprob与teacher-forced prompt_logprob。不挑选其它样本替代不完整的sibling0。预先容差：最大逐token绝对差≤0.1、整条logprob和差≤0.5；不满足则概率测量记未通过，保留自然采样及失败证据，不调容差重跑。

评分通过原prompt_ids后直接追加独立编码的指定后缀ids；核对decode及前缀边界，完整候选加EOS151645。prompt_logprobs=1包含实际目标token，max_tokens=1产生的尾部辅助token仅为引擎完成请求，不执行、不计自然动作。对评分保存实际输入IDs、目标token logprob及rank、返回辅助token、边界、logprob总和；校验有限数值及缺失位置。自然响应保存所有原token/终止原因及采样token logprob。

总上限1416次引擎请求（1024自然＋384候选/名字＋最多8核对），生成token上限4,194,696。没有模型被强制选择候选动作；评分的指定文本不是采样输出。CPU脚本前缀、候选合法性验证和自然输出的事后单步执行分别计数。

先验证新代码的固定总体、概率边界/缺失值/求和、截断不执行、身份保留及负例；真实CPU预检与上一批八个输入完全一致。冻结计划、代码、数据/模型身份、请求总体和候选文本。systemd user service、Linger=yes、stdin=null、Restart=no、KillMode=control-group、三小时上限，日志留在服务器；不注入真实断网、不删除文件。

完成后独立读回所有请求映射、tokens、seed、EOS、候选合法性和单步账本，重算概率统计，报告每输入固定分母及局限。1024个随机身份仍只覆盖两个市场状态，不视为1024个独立市场样本；不以收益挑提示、动作、股票或仓位。未经这个诊断，低交易概率、参数错误、探索不足都仍是待区分的解释。
