# M2：信息准备、观察消融与奖励核验计划

登记：2026-09-09，新加坡时间 SGT（UTC+8）。用户已授权继续此前讨论的三项排查，并明确优先使用H100加速；用户已澄清“GPT”指GPU，本轮不调用外部GPT服务。结果另写报告，本计划在模型请求前冻结。

## 目的与已有证据

上一批32条观察诊断保留25条完整、7条STEP_CAP失败；所有轨迹没有买卖或持仓。4B新旧观察各8/8完整；1.7B新增历史提示与记忆后仅1/8完整，出现1009次真实历史不足错误与大量重复计算。所有成功compute只涉及AAPL。响应最长68 tokens，问题已经超出输出截断范畴。

本轮分别检查：4B是否利用准备好的多股票信息；1.7B循环与历史提示/记忆哪个因素相关；共同奖励是否按已登记的收益、成本和风险正确计算。保留此前结论，使用新身份，不合并旧样本，不重抽失败直至成功。

## A：4B的信息准备对照，共32条

固定fresh Qwen3-4B（原revision），原 `pilot_train.parquet` 两个Train窗口（formal-train-0001/0005，source index 0/4）。每个窗口先通过真实环境执行4次hold，构造相同的session_index=4、全现金状态。四次hold只用于构造固定状态，完整记录为非模型前缀，不能统计为模型选择。

两种条件各2窗口×8个固定rollout，共32条：

- `raw`：原模型可见状态，不展示新增历史数量或工具记忆。
- `features`：同一状态，附带冻结股票顺序中全部20只股票的原始PIT计算结果。固定指标price_change、mean_return、volatility，lookback=5，不筛选股票，不按指标或收益排序。

特征由当前as_of下真实 `_compute` 求得，保持原值和实际lookback_used。不访问未来数据、不改变窗口或数据源；原工具不满足条件时保留失败，不填造数值。计算特征不调用env.step、不推进会话、不改变recent_events、账本或工具结果记忆。允许每个环境独立缓存同一as_of结果；日期推进后重新计算，无跨环境共享状态。

每次实际观察都展示当前as_of的完整表，证据中明确这是诊断提供的信息，不能冒充模型主动调用工具获得的结果。task文本、single_tool_v1和工具定义完全相同，不加入要求交易的目标文本。

每条最多128次模型请求；若达到真实终局，必须包含4次前缀推进和16次后续推进，总计20次，21个sessions。否则在已登记的有限观察范围结束，记录HORIZON_REACHED，不能声称完整训练轨迹。主要观察信息使用、不同股票访问、重复计算、有效推进、动作与真实成交；hold本身不是错误标签。

## B：1.7B的历史与记忆消融，共64条

固定fresh Qwen3-1.7B（原revision），同两个窗口，从原session_index=0开始，无人为前缀。四种观察条件各2窗口×8个rollout，共64条：

| 条件 | 可见历史数量 | 可见工具结果记忆 |
|---|---|---|
| raw | 无 | 无 |
| history_only | 有 | 无 |
| memory_only | 无 | 有 |
| both | 有 | 有 |

历史字段和记忆字段完全沿用已实现的 `history_memory_v1`，不同时改写措辞或容量。新诊断子类可在底层维护同一记忆，再仅控制字段展示；raw输出必须通过CPU对照证明与原legacy模型可见状态一致。该子类仅用于诊断，不修改正式环境默认配置。

每条最多64次模型请求。记录真实COMPLETE、HORIZON_REACHED、输入/输出截断及其他失败，保留全部64个身份。有限观察结束不等于旧256步门禁失败，也不能与旧批完成率直接混为同一指标。逐步记录调用时实际可见历史数量、错误、相同参数重复次数、是否推进时间、结果是否被保留及访问了哪些股票。

首窗只有一条历史这一事实保留。compute不推进时间，不能通过降低历史要求、自动替模型推进、禁用hold或强制买卖来获得完成结果。

## 共同生成、资源与停止规则

| 项目 | 本批登记 |
|---|---|
| 总人口 | 96条，A 32条+B 64条 |
| 种子 | base seed=42；每窗口每条件rollout index=0..7 |
| 请求seed | 复用生产derive_request_seed，step=1、sample_index=原窗口索引、validate=false、env_step=本条模型请求序号 |
| 输入/输出/context | 8192 / 4096 / 12288 tokens |
| 采样 | non-thinking；temperature=1、top_p=1、top_k=-1 |
| GPU memory utilization | 0.50 |
| max_num_seqs / max_num_batched_tokens | 32 / 16384 |
| CUDA graph capture sizes | [1,2,4,8,16,32] |
| 其余引擎 | 沿用固定vLLM 0.9.2、BF16、prefix caching、chunked prefill和原EOS合同 |
| 模型请求总上限 | 32×128+64×64=8192 |
| response token总上界 | 33,554,432 |

rollout index 0..7是本次独立诊断的样本身份，不代表改变M2训练n=4。相同状态/条件对照用相同seed规则；不同输入及活动批次不承诺token级复现。

4B的32条组成同一固定cohort；1.7B按窗口各组成32条（四条件×8）cohort。在cohort内并发生成，无补位新样本。每个模型只加载一次，先4B后1.7B；独立CPU工作并行进行。旧20% GPU和8并发设置不限制本次加速，但新推理资源方式不继承任何训练资源门禁。

原始输入不静默截短；超8192输入或不满足原4096/EOS合同的响应终止该条并保留证据，此身份不再提交。引擎、请求对应关系、数据或来源身份异常时停止模型与控制器，不重试、不补抽。全部未开始、未完成身份保留。自然完成只认真实会话推进和done标志，不能以请求数代替。

## C：CPU共同奖励核验，固定12条

在同两个原Train窗口，各运行下列六项预先固定的策略，全部各20次有效推进：

1. 全现金；
2. 首次买入AAPL至目标权重0.1，随后hold；
3. 首次买入AAPL至目标权重0.3，随后hold；
4. 按冻结symbols原顺序，前五个session依次买前五只股票至各0.1，随后hold；
5. 首次买入AAPL至0.1，下一session卖至0，其余hold；
6. 首次买入AAPL至0.6，随后hold（有意检查原软仓位风险项）。

统一legacy、finance_trajectory、capture_interactions=True。所有结果公开，不按收益选策略。独立根据真实fills、开盘成交与收盘mark重建cash/NAV、成本、drawdown、turnover、position risk与冻结benchmark分母，核对终局得分和逐步奖励时点。目标0.3不等于实际最大权重始终不超过0.3，按真实路径计算。检查冻结公式对收益/成本/风险的方向，不修改系数、不惩罚hold来制造交易。

这些脚本策略不属于模型决策或M2训练样本。真实市场结果允许全现金优于某些基线，不据此宣称最优策略；数学一致性与策略表现分开判读。不做Dev策略评估、formal Valid或Final OOS。

## 证据与交付

新代码：`scripts/diagnostics/m2_decision_conditions.py`、`m2_decision_probe.py`、`m2_reward_probe.py`；新目录：`runs/m2-decision-diagnostic-20260909/probe-v1/`和`reward-v1/`。旧脚本和产物保持原样。

prepare冻结本计划、源码、包版本、模型、两Train窗口以及实际初始输入；所有条件用真实tokenizer验输入预算。逐请求保存完整messages/tools/token IDs、原始响应、有效采样参数、环境动作、错误、前缀/模型推进与终局metrics，指标不按收益筛选。终局metrics只作逐轨迹审计，不构造M2 advantage/residual。

长作业使用服务器systemd user service，Linger=yes、stdin=null、Restart=no、KillMode=control-group、文件日志，GPU控制器最多三小时。它独立于客户端网络连接；不声称已实际注入断网测试。有限作业结束后核验身份、计数、EOS、关键PIT/记忆关联与终局账本；采用已通过的组件及批量读取，避免低效重复初始化或重复全量审计。

结果形成独立报告和机器汇总，并更新 `runs/M2_SCREENING_LATEST.md`（时间一律SGT）。本轮不启动M1/M2更新、checkpoint训练门禁或主screening。
