# M2：R5 全现金行为诊断与工具接口修复

登记时间：2026-09-09，新加坡时间（SGT，UTC+8）。本计划在新模型请求前登记。

用户已授权诊断当前问题并修改代码。本轮只做代码修复、CPU 验证及下面固定的首步诊断，
不重启训练或主 screening。旧 R5 的 76 条工程轨迹和失败证据保留原身份。

## 问题与已有证据

R5 工程完整性通过，但 4B M1 的 360 次请求全为 hold，4B M2 为 360 次 hold 加 1 次 compute；
全部 76 条轨迹没有成功买卖或持仓，M2/plain 的实际 residual 为 0。
这表示当前样本没有覆盖需要检验的机制，不能据此判断 M2 相对 M1 有效或无效。

CPU 排查已确认：

1. 数据 prompt 只有 `Manage the portfolio using only point-in-time tools.`；
   `single_tool_v1` 补充格式、PIT 和交易规则，没有说明资金增长、成本和风险目标。
   这是行为假设，尚未证明它导致 hold。
2. 上游 schema 类型只保留部分字段，实际传给模型的工具 schema 丢失数值界、字符串长度、
   默认值和禁止额外参数等约束；存在 schema 接受、真实环境拒绝的调用。这是确定的接口缺陷，
   但历史 4B 没有 invalid，不能把它直接认定为 4B 全 hold 的原因。
3. 成功响应只留 hash，环境返回的 `info` 没有进入轨迹证据，无法从旧 R5 日志还原 1.7B 的
   131 次 invalid 原因。本轮补充可选诊断记录，不反向补造历史原文。
4. 当前观察只包含当前行情、最近三次调用摘要和最近一次工具结果，不能积累全部历史计算结果。
   首个 pilot 窗口首步仅有一根可见 close，compute 至少需要两根；第二个窗口首步有五根。
   这是现有数据/观察限制，本轮不改变窗口或加入未来行情。
5. 逐请求 seed 重算正确，没有发现训练被切成 greedy 或响应被缓存复用。
   实际上游方法的 CPU stub 交接验证能检查参数传递，但不能替代历史服务端采样收据。
6. 同一真实环境在合法 buy 后能够 next-open 成交。因此并非 buy 分支完全不可执行。

旧 4B 首 prompt 已由真实 tokenizer 重建：2382 tokens，SHA-256
`703619cbcebf82b52557c82eade1d66e9c3ce44b13b307f5724619978451e8c9`，
与 R5 M1/M2 第一条请求一致。CPU 证据位于 `runs/m2-hold-diagnostic-20260909/`。

## 本轮代码修改边界

- 在本项目工具适配层保留真实参数 schema，并与 `_ARG_MODELS` 对齐；不修改 Agent-R1 子模块。
  这会改变模型可见工具描述，因此后续执行必须使用新的代码/输入身份，不能接续为旧 R5 的样本。
- 增加显式 `capture_interactions: true` 设置，经 launcher 传给
  `data.screening_capture_interactions`。省略时保留原来的成功响应 hash-only 行为。
  开启后记录有界 prompt/response token IDs、管理器请求 ID、该边界实际转发的采样参数、
  环境实际收到的响应文本、返回观察、工具错误和成交信息。
- 管理器转发参数不是 vLLM 引擎收据。未转发的默认值不得伪装成现场实测值。
  首步独立诊断另保存原生 vLLM 参数和请求/输出映射。
- 诊断记录不进入模型观察、奖励或 credit 计算。CPU 测试验证开启前后的完整轨迹行为相同，
  并覆盖失败响应尚未进入环境的情况。
- 本轮不改变奖励、M2 residual、共同 non-thinking 设置、4096 cap、执行成本、观察历史、
  Train 窗口和正式提示词默认值。下面的目标文本 C 仅是诊断候选。

## 固定首步诊断：最多 48 个请求

模型使用原 revision 的 Qwen3-4B 与 Qwen3-1.7B **fresh base**。
R5 的成功权重已按既定归档规则移除，因此本实验不声称重放 R5 更新后的模型。
先 4B 后 1.7B，每个模型只加载一次。

固定两个 R5 pilot Train windows：`formal-train-0001`、`formal-train-0005`。
每个条件使用相同的 step=1、sample_index=0/1、rollout_n=0..3、env_step=0 派生 seed。
每个窗口四个 siblings，每个条件八个请求，每个模型二十四个，两模型合计四十八个。

| 条件 | 工具 schema | 消息与目标 |
|---|---|---|
| A | 从旧代码真实导出并冻结的 R5 schema | 原 `single_tool_v1` |
| B | 修复后完整 schema | 与 A 完全相同 |
| C | 与 B 完全相同 | 原 `single_tool_v1` 后附下面固定目标文本 |

C 的唯一新增文本为：

> Your objective is to grow the portfolio's value after commission and slippage over the episode, while managing drawdown, turnover and concentration. Use the available point-in-time evidence to decide whether a trade is justified. Holding cash is allowed; there is no requirement to trade.

目标文本不要求买卖，不奖励交易次数，也不根据某个 arm 的收益挑选。
三个条件使用同一真实环境验证输出；A 的旧 schema 只影响输入模板，不放宽环境参数校验。

共同设置：原生 `enable_thinking=False`，temperature=1、top_p=1、不截 top-k、n=1/request，
response cap=4096、prompt cap=4096、context=8192；每条件一批八个请求。
同 seed、不同输入或独立引擎批次不保证逐 token 重放 R5。

每个响应保存原始 tokens、解码文本、EOS/finish reason、输入 hash、有效采样设置。
完整响应只执行一次真实 `TradingEnv.step`，保存环境错误和结果；触 cap/abort 的响应保留证据，
不进入环境。每个请求都是独立的初始环境，不把八条首步拼接为轨迹。

观察指标预先限定为：完整性、动作族、参数/环境合法性、具体错误、响应长度，及配对条件之间
动作是否改变。不计算完整轨迹收益，不用未完成轨迹生成 Y/residual，不做显著性或胜负判断。
每条件只有两个固定初始状态、各四次采样，结果仅作描述。A→B 同时包含完整 schema 的字段与
序列化变化；B→C 检查修复 schema 下的目标文本，不识别 schema 与目标之间的交互效应。
首步 compute/retrieve 的返回值不会再交给模型做第二次决定，因此不能据此解释后续交易行为。

## 运行与停止规则

CPU prepare 冻结计划、源码、旧 schema、两个窗口、tokenizer/模型 revision、输入 token IDs、
seeds 和请求表的哈希；加载 GPU 前检查身份与预算。目录为
`runs/m2-hold-diagnostic-20260909/probe-v1/`，只创建新输出文件。

GPU 作业采用服务器的 systemd 用户服务、文件日志、stdin=null、Restart=no、独立进程组；
保持 Linger，避免客户端 SSH 断开终止作业。启动前检查空闲 GPU、内存和磁盘。
不删除缓存或环境。系统时间收据可保留 UTC，人工进展统一 SGT。

- 个别 length/invalid 是已登记的负结果，继续剩余固定请求，不补抽。
- 身份漂移、引擎异常或资源失败停止该模型并保留证据；不以同配置重试掩盖失败。
- 48 个请求结束即停判读，不自动追加 prompt、seed、thinking、训练或完整轨迹。
- 两个窗口的首步结果只能帮助定位接口/提示词行为，不能验收完整轨迹、学习效果或 M2 机制。
  如果 hold 仍持续，报告未解决的覆盖问题，并基于证据提出下一项独立诊断。

本轮不运行 Dev 策略评估、formal Valid 或 Final OOS，也不比较 A2/M1/M2 的性能。
