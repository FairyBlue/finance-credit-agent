# M2：固定输出 logprob 数值路径诊断

登记日期：2026-09-12，SGT（UTC+8），GPU执行前冻结。

用户授权继续处理动作概率诊断中的一致性失败。固定上一批8个输入及各自sibling0的完整输出（含EOS，共234tokens），不重新采样交易，不改变输入、输出、阈值或历史失败身份。只评分这些指定token，不执行环境动作，不训练，不追加候选交易。

比较四个预先固定的执行条件，依次各运行一次：

1. `vllm_common`：原4B BF16、原缓存/graph/32并发资源配置。对8条输出分别进行一次8条批量完整评分、一次逐条完整评分，以及逐token前缀评分（每请求只提取末尾目标token的概率）。共8+8+234=250请求。
2. `vllm_serial`：同一模型与BF16，关闭prefix caching、chunked prefill和CUDA graphs，max_num_seqs=1；其余模型/温度参数保留。仍执行同样250个请求。此条件同时改变数个执行因素，是组合检查，不能单独归因于其中一个开关。
3. `hf_bf16`：Transformers同一checkpoint、BF16、eager attention、batch1，eval/inference_mode。每条固定输出比较完整teacher-forced前向与KV cache逐token前向。
4. `hf_fp32`：与hf_bf16相同，仅模型计算dtype为FP32，关闭TF32，最高float32 matmul精度。原BF16权重转换为FP32，不训练、不换checkpoint。仅作为数值参考，不宣称等于历史vLLM BF16采样分布。

HF每条件8次完整前向，另8次初始prompt前向和226次带KV的单token前向，共242次模型forward。全部使用因果mask、明确位置与原token IDs，完整评分选prompt最后一位置到EOS之前的位置，避免一位偏移；log_softmax在FP32计算。不得把目标token约束后再归一化的概率当作原始概率。不得以teacher-forced输入为模型采样经验。

总预算：500个vLLM评分请求（每请求最多1个辅助生成token，共500；辅助token不执行），484次HF固定前向。无新自然生成决策、无新市场状态、无环境动作。每条件独立进程退出后再启动下一条件；已有数值失败不改变后续固定条件，基础设施异常保留部分证据并停止队列，不自动重试。

原门槛保留：每条最大逐token绝对差≤0.1，整条logprob和差≤0.5，8/8才算该对照通过。vLLM各路径与历史自然生成logprob比较；HF分别比较完整与KV逐token路径，并额外描述与历史记录的差异。通过HF内部一致性不等于修复旧采样器概率。原1/8失败不会被覆盖。

报告全部条件、全部8条结果和最大误差位置；有限固定输出上的通过不外推为所有交易动作的精确概率。若有vLLM路径满足8/8，作为限定范围的测量候选，优先更少请求的完整评分，再考虑逐token路径；正式采用仍需说明本批覆盖范围。若都未通过，保留失败，不能通过改阈值、重抽输出或更换概率定义宣布修复。

先做CPU单元测试、token边界/历史来源核对、源码/库版本冻结，再使用服务器独立systemd user service（Linger=yes、stdin=null、Restart=no、KillMode=control-group、3小时上限）。日志与进度持久化，不依赖客户端网络；不注入断网、不清理文件。结束后核对原始概率、逐token位置、资源与来源，写最终报告和SGT进展。本批之后不自动启动策略探索或训练。
