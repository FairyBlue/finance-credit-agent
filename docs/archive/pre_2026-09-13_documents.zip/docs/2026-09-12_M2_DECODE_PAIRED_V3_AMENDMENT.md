# M2 decode配对诊断：V3命名扩展启动修正

2026-09-12 SGT，V3执行前冻结。

V2已加载模型，但在安装观察回调时停止。vLLM 0.9.2文档接口接受callable，实际V1跨进程msgpack默认不序列化函数对象；因此尚未安装回调或发出任何生成/评分请求。V2失败收据和冻结源码保留，不覆盖原身份。

人工核对当前worker_base及serial_utils实现后，V3使用公开worker_extension_cls字符串注册本项目DecodeObserverExtension，collective_rpc仅传字符串方法名。扩展只委托原只读PyTorch观察回调，不替换vLLM方法，不改依赖源码，不启用VLLM_ALLOW_INSECURE_SERIALIZATION。新增CPU测试直接覆盖当前V1编码器对命名RPC的支持、对函数对象的拒绝，以及EngineArgs/扩展名称解析。

算法、模型、精度、缓存/graph、输入、seed及原阈值不变。引擎配置只新增观察扩展的登记字段，并保存实际配置。继承[原配对计划](2026-09-12_M2_DECODE_PAIRED_PLAN.md)的8次自然生成＋8次评分，V1/V2均0模型请求，仍无补抽输出。不得把前两次启动错误隐去；记录两次人工检查后的项目启动修正，不是成功输出筛选。

V1冲突来源的早期归因以[来源更正](2026-09-12_M2_DECODE_IMPORT_ATTRIBUTION_CORRECTION.md)为准。所有旧失败继续保留；本批不执行环境动作，不训练、不修改正式默认。新目录新service，无自动重试。V3结束后写出最终报告及全部限制。
