# M2 decode配对诊断：V2启动修正

登记日期：2026-09-12 SGT，V2 GPU执行前冻结。

V1独立服务按计划在基础设施错误处停止：23:17:40 SGT，创建LLM实例之前导入`scripts.diagnostics`失败。Agent-R1引入的顶层`scripts`命名空间与本项目路径冲突；V1没有创建LLM、没有模型请求、没有采样人口。失败源码、manifest、日志和[failure_receipt](../runs/m2-decode-paired-20260912/failure_receipt.json)保留，不覆盖为成功。

人工检查启动错误后，V2仅修正本项目诊断模块的导入路径，并增加外部scripts命名空间存在时的CPU回归测试。使用独立m2_decode_paired_v2.py、独立运行目录与独立service；不修改冻结V1源码，不修改已安装vLLM，不自动重试原服务。

[原计划](2026-09-12_M2_DECODE_PAIRED_PLAN.md)的8固定输入、8原seed、采样配置、只读观察回调、8次生成＋8次配对评分、原阈值和停止条件全部保留。只读观察回调源码不变。V1没有模型请求，因此本任务仍最多16次模型请求，不是重新抽取失败输出。V2完成或遇到新基础设施错误后停止并报告，不追加候选条件。
