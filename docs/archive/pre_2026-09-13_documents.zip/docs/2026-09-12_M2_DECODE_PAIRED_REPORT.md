# M2：真实decode原始概率核对最终报告

报告时间：**2026-09-12 23:42 SGT（UTC+8）**。本轮停止执行，以下分别记录已验证结果和未完成部分。

**234个实际输出token的原始logprob与vLLM公开返回值完全一致，最大差为0。** 其中8个首token来自prompt prefill，226个后续token已核验为带KV缓存的decode。没有在这些记录中发现生成概率拿错token或读取受约束概率的问题。

**已安装vLLM源码未修改；目前没有证据证明vLLM导致大量hold。** 本轮只使用公开worker扩展和本项目只读观察代码。

| 项目 | 最终状态 |
|---|---|
| 真实decode原始概率与公开API核对 | **通过**：8条、234 tokens，最大差0 |
| 原计划的同worker生成/完整评分配对 | **INCOMPLETE**：生成后项目后处理错误，评分未执行 |
| 异进程补充评分 | **INCOMPLETE**：8个返回对象已取得，但结果序列化失败，原始评分数值未落盘 |
| 当前decode与此前已保存同文本评分的CPU参考比较 | **7/8在原阈值内**，最大差0.194178；这是历史参考，不是本次新评分结果 |

不能把原始概率观测通过写成整轮校准通过。旧校准失败仍保留，两项INCOMPLETE也未改成成功。

**有效结果的来源**

保持原8个固定Train session4输入和各自原sibling0 seed，使用Qwen3-4B revision `1cfa9a7208912126459214e8b04321603b3df60c`、BF16、non-thinking及vLLM0.9.2。temperature1、top_p1、top_k−1、并发上限32、缓存/graph和4096输出上限均沿用原配置。

8条自然请求一次提交，没有补抽，全部完整；新token序列恰好全部与旧sibling0一致，这是运行结果，未用来筛选样本。新旧生成身份和调度仍分开保存。

观察器通过公开worker_extension_cls和字符串collective_rpc安装PyTorch前后回调。前回调复制logits，后回调仅在副本上计算FP32 log_softmax，记录实际选中token的原始概率、logit、归一化常数、rank、请求ID、已有输出prefix、KV已计算长度、调度长度和输入位置。回调返回None，不替换vLLM方法、不修改输入/输出token或随机数状态，不开启pickle回退。回调会增加同步开销，因此不保证与历史无观察运行的调度一致。

独立CPU审计核对全部234个token和EOS。31次sampler调用中有1条未完成prompt prefill的临时观察，原样保留但不计入输出；226个后续token均满足单token调度及正确KV边界。目标logit−logsumexp与记录logprob的最大残差为 **2.04146e-06**，小于预设1e−5；原始logprob与公开API返回值的差为0。

**历史评分参考：不代替缺失的新评分**

由于全部8条的输入和输出token均与历史完全相同，可以在CPU上将本次已核验decode概率与此前已保存的teacher-forced评分进行参考比较。历史来源为上一批冻结manifest中的完整评分记录，哈希已核对；没有重算或补造缺失的GPU结果。

保留每条最大逐token绝对差≤0.1、整条logprob和差≤0.5阈值。位置为从0计数的响应token索引。

| 固定输入 | 首token差 | 后续decode最大差 | 整条和差 | 最大差位置 | 在原阈值内 |
|---|---:|---:|---:|---:|---|
| 0：features / w0 | 0 | 0.063607 | 0.0972598 | 19 | 是 |
| 1：features_defined / w0 | 0 | 0.194178 | 0.193451 | 19 | 否 |
| 2：features_objective / w0 | 0 | 0.00498141 | 0.00678744 | 24 | 是 |
| 3：features_defined_objective / w0 | 0 | 0.0359724 | 0.0248902 | 19 | 是 |
| 4：features / w1 | 0 | 0.0246701 | 0.0473259 | 23 | 是 |
| 5：features_defined / w1 | 0 | 0.0101685 | 0.00851648 | 6 | 是 |
| 6：features_objective / w1 | 0 | 0.0723213 | 0.0484168 | 21 | 是 |
| 7：features_defined_objective / w1 | 0 | 0.0776102 | 0.0484595 | 19 | 是 |

case1仍在abstain理由的data token处出现约0.194差异。这个参考比较支持“返回的原始decode概率读取正确，但与完整输入评分存在数值路径差异”；不能据此认定具体内核有bug或推断交易能力下降。结合上一批BF16/FP32对照，精度与执行路径仍是解释方向，尚未完成因果定位。

本轮没有执行任何环境动作，所以不更新hold比例、成交率、持仓或收益。之前1024次自然采样的真实动作/成交记录仍有效；未校准候选文本评分仍不能当作可靠的动作类别概率。训练loss中的概率比值/KL链路也未由本次核验覆盖。

**工程错误与代码修复**

诊断代码出现了四处适配问题，原始源码、日志及身份全部保留：

1. V1创建LLM前遇到顶层scripts包冲突，0模型请求。实际冲突来自已安装verl发布的scripts包；早期Agent-R1归因有误，见[来源更正](2026-09-12_M2_DECODE_IMPORT_ATTRIBUTION_CORRECTION.md)。改为唯一诊断模块路径。
2. V2加载模型后，默认V1 msgpack拒绝函数对象，安装观察器之前停止，0模型请求。改为公开命名worker扩展和字符串方法，增加当前编码器及EngineArgs回归测试。
3. V3完成8次自然生成并保存观察记录后，后处理读取`finish_reason`；共享序列化器实际字段为`raw_finish_reason`。评分请求尚未发出，进程退出，所以同worker配对无法恢复。
4. 恢复进程对8条已保存输出发出评分并取得8个返回对象，但评分序列化helper要求`selected_suffix_indices`，调用方却传入`suffix_indices`，因此原始评分未写入文件。该阶段不能提供新概率结果，也未据此重复请求。

前期单元测试未覆盖这两处共享接口的实际组合，这是诊断工具测试覆盖的缺口。现已在[修正后的配对入口](../scripts/diagnostics/m2_decode_paired_checked.py)修正两个字段，并新增[完整CPU接口测试](../tests/test_m2_decode_contracts.py)：模拟引擎返回值，但实际调用本项目共享生成与评分序列化器，走完整个配对入口。该测试通过；既有观察路径14项测试、完成状态恢复6项测试及相关Ruff/mypy也通过。

**修正入口未再次上H100运行。** 这些CPU测试不能替代真实GPU端到端验收，不能把未完成状态改写为通过。本轮到此停止，不追加自然生成或评分请求。

**请求、资源和证据收据**

总计8次自然生成请求，已验证234个输出tokens；另提交8次补充评分请求，返回对象数8，但数值证据保存失败。评分每请求max_tokens1，辅助token上限8，实际数量未由持久化原始输出核验。0环境动作、0训练、0完整交易轨迹、0 Dev/OOS。控制器无自动重试；每次项目启动修正均在检查失败、保留证据后单独登记，没有筛选成功输出。

| 阶段 | SGT时间 | 结果 | 显存采样峰值 | 容器OOM增量 |
|---|---|---|---:|---:|
| V3生成与观察 | 23:26:55–23:28:18 | 8条生成完整；后处理错误停止 | 46.0GiB | 0 |
| 异进程补充评分 | 23:34:12–23:37:00 | 返回后序列化失败 | 64.0GiB | 0 |

表中是相应阶段的采样峰值；已退出服务的独立cgroup计数不可读。服务均已停止，GPU已释放。使用systemd user + Linger、stdin=null、Restart=no及一小时上限，不依赖客户端网络；未注入真实断网或清理文件。

V3冻结99个源码/计划文件，恢复评分冻结102个；相关框架源码执行前后哈希一致。独立核验上一批1140个绑定文件和前两次失败收据未变。新修正但尚未GPU运行的入口单独保存，不覆盖冻结失败源码。

[原始decode审计](../runs/m2-decode-recovery-20260912/decode_audit.json) · [历史评分参考审计](../runs/m2-decode-recovery-20260912/archive_reference_audit.json) · [原始生成](../runs/m2-decode-paired-20260912-v3/paired/natural.raw.json) · [观察记录](../runs/m2-decode-paired-20260912-v3/paired/observer.jsonl) · [补充评分失败状态](../runs/m2-decode-recovery-20260912/score_saved/state.json) · [最终机器汇总](../runs/m2-decode-recovery-20260912/final_readout.json)。

[原计划](2026-09-12_M2_DECODE_PAIRED_PLAN.md) · [V2修正](2026-09-12_M2_DECODE_PAIRED_V2_AMENDMENT.md) · [V3修正](2026-09-12_M2_DECODE_PAIRED_V3_AMENDMENT.md) · [恢复分析登记](2026-09-12_M2_DECODE_RECOVERY_AMENDMENT.md)。

**下一步建议，尚未启动**

保持现有推理框架，结束这轮底层数值路径的扩展排查，回到Train内共同探索/初始化设计。优先以实际生成、合法执行、股票覆盖、仓位集中度和完整轨迹作为读数，不用未校准候选概率筛选提示或动作，也不只追求买入次数。

如果后续实验需要精确的配对评分，修正入口还必须经过一次独立登记的GPU验收；当前不能视为可直接使用。正式训练前另行核对真正进入loss的概率链路及其与rollout的对应关系，共同配置公平用于A2/M1/M2。本轮未启动训练门禁或主screening。
