# 共同 SFT / M1 / M2 四轮对照：seed43 最终结果与两 seed 对照

当前进展：**2026-10-05 22:41 SGT（UTC+8）**。
最终服务于 **20:10:20 SGT** 完成，状态 **COMPLETE / PASS**，退出码 0；
训练服务与占位服务均已退出，holder 关闭且零持有，复查 GPU 使用 527 MiB、利用率 0%。

**164/164 条轨迹完整：共同 SFT 零 RL，M1/M2 各四次 actor 和四次 critic 更新，最终模型已保存。**
seed43 的最终两种解码收益均高于共同 SFT；M2 的 greedy 高于 M1，sampled 几乎持平。
结合 seed42，RL 相对 SFT 与 M2 的 greedy 增量均出现重复的正向读数；
sampled 增量大小未稳定重复，合法性与金融评分也没有全面改善。

## 收益与学习曲线

净收益包含交易成本，未年化。四个事前固定的 Train 评估窗口等权汇总，
greedy 每窗 1 条、sampled 每窗 4 条；第 4 轮为固定终点，没有事后择优 checkpoint。

| 模型 / 轮次 | Greedy 平均净收益 | Sampled 平均净收益 |
|---|---:|---:|
| 共同 SFT，零 RL | 1.6187% | 1.1089% |
| M1，第 2 轮 | 1.6655% | 0.8342% |
| M2，第 2 轮 | 1.6655% | 0.9468% |
| M1，第 4 轮 | 1.7018% | 1.4229% |
| M2，第 4 轮 | **1.9529%** | **1.4261%** |

| seed43 第 4 轮比较 | Greedy 差额，百分点 | Sampled 差额，百分点 |
|---|---:|---:|
| M1 − SFT | +0.0832 | +0.3139 |
| M2 − SFT | +0.3343 | +0.3172 |
| M2 − M1 | **+0.2511** | **+0.0033** |

sampled 的 +0.0033 个百分点约为 **0.33 个基点**，本批应视为近乎持平。
第 2 轮两臂 sampled 都低于 SFT，第 4 轮才提高；不能称为每轮均有改善。

| seed43 评估窗口 | 第 4 轮 Greedy M2−M1，百分点 | 第 4 轮 Sampled M2−M1，百分点 |
|---|---:|---:|
| 0113 | +0.4194 | +0.3297 |
| 0117 | +0.5850 | −0.2113 |
| 0121 | 0 | +0.3157 |
| 0125 | 0 | −0.4210 |

sampled 为两窗提高、两窗降低，差额相互抵消；greedy 为两窗提高、两窗持平。

## 与 seed42 对照

两个 seed 分别从相同共同 SFT v3 起点执行相同四轮预算。
除 seed、运行身份及修复只读验收的 seed 参数检查外，公式、η、学习率、窗口、奖励与生成设置相同。
seed42 的原结果见[四轮最终报告](2026-10-05_M2_SFT_FOUR_ROUND_COMPARISON_REPORT.md)。

| 第 4 轮比较 | seed42 greedy | seed43 greedy | seed42 sampled | seed43 sampled |
|---|---:|---:|---:|---:|
| M1 − SFT，百分点 | +0.1518 | +0.0832 | +0.1701 | +0.3139 |
| M2 − SFT，百分点 | +0.2294 | +0.3343 | +0.3767 | +0.3172 |
| M2 − M1，百分点 | +0.0777 | +0.2511 | +0.2067 | +0.0033 |

两批固定终点均为 M2 > M1 > SFT 的平均净收益排序，但 seed43 sampled 的 M2/M1 差距很小。
当前支持保留训练设置继续检验，尚不足以得出稳定的 sampled 优势或样本外提升。
不将两个 seed 合并均值掩盖这次近乎持平的结果。

## 风险、成本与合法性

| seed43 第 4 轮 / 基线 | Greedy 平均最大回撤 | Sampled 平均最大回撤 | Greedy 非法请求 | Sampled 非法请求 | Sampled 平均交易成本，账户美元 |
|---|---:|---:|---:|---:|---:|
| SFT | 1.6316% | 1.4737% | 0/80 | 6/326（1.84%） | 5,517.40 |
| M1 | 1.6316% | 1.3553% | 0/80 | 13/333（3.90%） | 5,503.31 |
| M2 | 1.3999% | 1.3388% | 0/80 | 16/336（4.76%） | 5,485.77 |

M2 平均回撤略低于 M1，但 sampled 非法请求更多；训练累计非法步骤也更多，
M1 为 **56/696**，M2 为 **62/702**。seed42 sampled 非法请求则是 M1 11/331、M2 7/327，
合法性改善没有跨 seed 重复。完整率 100% 表示轨迹最终走完，并不表示每个请求合法。

最终金融评分 Y：greedy 为 SFT −4.9265、M1 −4.7597、M2 −4.3182；
sampled 为 SFT −5.8918、M1 −5.3005、M2 **−5.3316**。
M2 sampled 净收益略高于 M1，但包含风险与归一化的金融 Y 略低，不能称为风险调整表现全面领先。
三组净收益仍低于四窗平均等权 benchmark **4.2216%**。

## 执行与故障恢复

原服务于 16:27:48 SGT 启动，17:40:10 在 M1 成功训练后的验收中误报失败。
原因是我在 seed 泛化时漏改了下游 `run_seed == 42` 检查；训练数据实际为正确的 seed43。
修复只读验收后，原 SFT/M1 的 92 条轨迹、四次更新、奖励与导出复验通过。
**原 FAILED 状态与日志保留；新目录导入已有 SFT/M1 证据，只新执行原定 M2 的 72 条。**
没有重训或重新采样 SFT/M1，也没有增加 seed、窗口、轮数或总预算。
详见[验收修复报告](2026-10-05_M2_SEED43_VALIDATION_RECOVERY_REPORT.md)。

剩余 M2 服务于 19:07:53 启动，20:10:20 完成，约 **62 分钟**，其中 M2 worker 约 60.3 分钟。
原 SFT worker 约 11.4 分钟、M1 约 60.9 分钟；中间修复时间不计作训练耗时。
M1/M2 真实初始 critic head 相同，均为 seed43；共同罚项、原 Y residual、更新预算与完整网格验收通过。
本次报告复查再次通过原始轨迹网格和封存合同验收，收益表与最终状态一致；
导入 SFT/M1 的原始轨迹文件哈希与原目录相同，原 summary 未修改。
两臂最终 actor 为 BF16 HF 导出，每份约 8.22 GiB；成功臂临时 moments 已按原流程退休，证据和清单保留。
导出不含 optimizer/critic/RNG 训练状态，不能原状态续训。
训练 worker 峰值约 **69.44 GiB allocated / 72.55 GiB reserved**，仍不能视为严格 60 GiB 已验收。
服务独立运行，`Linger=yes`、`Restart=no`，本批无自动重试；未注入真实网络中断测试。

## 当前结论与下一步建议

优先保留共同 SFT、现有公式、η=0.25 与四轮设置，增加原 Train 内的日期覆盖，
继续观察相对 SFT/M1 的收益、金融 Y、回撤和非法率，而不是立即加轮或调整多项参数。
sampled 优势是否可重复仍需检查；本次结果没有表明必须修改 M2 分配公式。
下一批未启动，A1/A2 尚未比较。

限制：只有两个训练 seed，四个 21-session 评估窗口彼此重叠且均来自原 Train；
没有正式 Valid / Final OOS。请求 seed 包含 policy step，SFT0 与 RL 第 2/4 轮 sampled
不共享完全相同的随机数；跨 seed 的 SFT sampled 读数本身也不同。

服务器原始证据（`runs/` 未随 Git 上传）：
[服务完成](../runs/m2-sft-four-round-comparison-seed43-20261005-recovery/service_completion.json) ·
[完整读数](../runs/m2-sft-four-round-comparison-seed43-20261005-recovery/comparison_readout.json) ·
[逐轮曲线](../runs/m2-sft-four-round-comparison-seed43-20261005-recovery/evaluation_curve.csv) ·
[收益差表](../runs/m2-sft-four-round-comparison-seed43-20261005-recovery/comparison_summary.csv) ·
[完成复查](../runs/m2-sft-four-round-comparison-seed43-20261005-recovery/completion_review.json) ·
[恢复来源合同](../runs/m2-sft-four-round-comparison-seed43-20261005-recovery/recovery_contract.json)。
