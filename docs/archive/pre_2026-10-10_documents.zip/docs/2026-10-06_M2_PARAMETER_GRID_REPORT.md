# M2 参数网格：执行记录与性能诊断入口

当前进展：**2026-10-07 20:55 SGT（UTC+8）**。
**R1 已于 10月6日 18:23:32 SGT 因 CUDA OOM 停止，当前没有本批训练进程。**
seed42 的共同 SFT 基线和首个 M1 / actor LR=1e-7 四轮任务已完成执行验收；
首个 M2 / LR=1e-7 / η=0.125 完成两轮训练及第二轮评估后，在第三轮生成前唤醒推理引擎时失败。
其余 10 个 RL 配置和 seed43 基线未启动，尚不能判断稳定参数范围。
R1 共落盘 **288 条：282 COMPLETE + 6 INCOMPLETE**，其中 48 条训练全部完整。
原失败批次另有 50 条保留；没有自动重跑、重新抽样或恢复未同步的 optimizer 状态。
详见[本次状态复核](../runs/m2-parameter-grid-20261006-r1/status_review_20261007.json)。
[R1 实时状态](../runs/m2-parameter-grid-20261006-r1/LIVE_STATUS.md) ·
原[最终状态](../runs/m2-parameter-grid-20261006/FINAL_RESULTS.md)保留。

本轮目的：定位收益提升较稳定的参数/日期条件，检查尚存问题，并形成下一轮提升方案。
固定两 seed、12 次 RL 训练，每臂四轮，合计 **1,944 条**；预算与判读见
[事前网格计划](2026-10-06_M2_PARAMETER_GRID_PLAN.md)。
Actor LR 为 1e-7 / 2e-7；各 LR 对照 M1 与 M2 η=0.125 / 0.25，critic LR 固定 1e-6。
第 0/2/4 轮同时记录 greedy 与 sampled，评估扩到原 Train-dev 的 12 个不重叠窗口，覆盖 252 个交易日。

## 停止时的结果与问题

| seed42 配置 | 实际 actor/critic 更新 | 完整 Train | Eval 完整/尝试 | 模型 |
|---|---:|---:|---:|---|
| 共同 SFT | 0/0 | — | 59/60 | 原共同模型保留 |
| M1，LR=1e-7 | 4/4 | 32/32 | 116/120 | 第四轮模型已无损归档 |
| M2，LR=1e-7，η=0.125 | 2/2 | 16/16 | 59/60 | 未到第四轮导出，无 actor checkpoint |

`grid_readout.json` 只纳入已验收的 SFT 与 M1，共 212 条；
失败 M2 的 76 条原始轨迹另行保留，没有混成已完成的四轮臂。
全部 6 条 INCOMPLETE 都是 greedy 评估中的买入方向拒单循环，失败金融收益为空。

M1 与 SFT 按共同完整窗口配对，收益已计入交易成本：

| 轮次/解码 | 共同完整窗口 | M1 平均净收益 | 同窗 SFT 平均净收益 | M1−SFT（百分点） |
|---|---:|---:|---:|---:|
| 第二轮 greedy | 9/12 | 0.3710% | 0.2499% | +0.1212 |
| 第二轮 sampled | 12/12，48条 | 0.4197% | 0.4828% | −0.0631 |
| 第四轮 greedy | 10/12 | 0.5805% | 0.4914% | +0.0891 |
| 第四轮 sampled | 12/12，48条 | 0.4693% | 0.4828% | −0.0135 |

greedy 表只比较双方都完整的窗口；SFT 有 1/12 失败，M1 第二轮、第四轮各有 2/12 失败，
不能把排除失败后的均值当作全覆盖收益改善。支持数据见
[配对收益表](../runs/m2-parameter-grid-20261006-r1/paired_comparisons.csv)。
M1 第四轮 sampled 非法请求率从 SFT 的 5.882% 降至 4.667%，平均费用从 5,335.74 降至 5,257.03；
但金融 Y 从 −2.9601 降至 −3.0250，平均最大回撤从 1.4688% 升至 1.5063%，未形成一致提升。

失败 M2 的第二轮**仅作部分诊断**：sampled 平均净收益 0.5039%，较同期 M1 高 0.0842 个百分点；
greedy 在双方共同完整的 9 窗为 −0.0119%，较同期 M1 低 0.3830 个百分点。
没有第四轮或 seed43 读数，不能据此挑选 η 或判断 M2 优势。

行为方面，完整轨迹仍主要交易 GS/HD/MSFT 三股，平均约 60% 现金。
最明确的弱点是遇到“buy target_weight must be above the current weight”反馈后反复提交相同买入，
而不是恢复合法决策。greedy 失败前缀另含 241/253 次连续非法请求，不能只看完整轨迹的非法率。

## 停止原因与后续方向

M2 第二轮的 actor/critic 更新及 60 次评估均已结束；下一次训练生成在
`vLLM wake_up → resume weights → CuMem create_and_map` 报 CUDA OOM，见
[失败日志](../runs/m2-parameter-grid-20261006-r1/seed42/m2_lr1e7_eta0125/trainer.log)。
已发生的 1,872 次模型请求全部正常结束，最长回答 22 tokens、最长输入 4,797 tokens；
这次停止没有触及 4,096-token 响应上限，也不是训练轨迹不完整。

18:22:50 SGT，worker 分配约 48.10 GiB、缓存约 48.20 GiB，全卡空闲约 23.66 GiB；
18:23:17 SGT，worker 分配/缓存相同，全卡空闲却降至约 13.61 GiB。
唤醒失败时全卡仅余约 5 MiB。记录支持共享显存可用容量突然下降，但未识别具体占用者。
host 的 OOM/OOM-kill 累计计数从任务开始到结束未增加，不能把旧累计值当成本次 host OOM。

10月7日 20:50 SGT 复查，GPU 全卡占用约 44.54 GiB、空闲约 48.55 GiB、利用率 100%；
本批 systemd 服务已失败退出，控制组为空，这些占用不能当作本批仍在训练。
磁盘约 78 GiB 可用，没有进行新的文件删除。

下一步优先处理共同执行路径的显存切换容量检查，并评估能否降低峰值，再承接剩余固定网格。
保留已有 M1/SFT 验收和原失败证据；M2 未导出同步 checkpoint，不能从现存 moments 拼成续训起点。
算法层面的后续改进线索是拒单恢复、股票覆盖和现金/持仓使用，暂不凭这组不完整结果改变 M2 公式。

## 启动验收

R1：**607 项集成测试加 78 项补充证据测试，共 685 项通过**；Ruff、diff 检查及 40 个完整 CPU 回放通过；
最大 prompt 4,593 tokens，train/dev/calibration 与原批次逐字节相同，源码与输入重新封存。
[R1 验收收据](../runs/m2-parameter-grid-20261006-r1/implementation_validation.json) ·
[补充校验](../runs/m2-parameter-grid-20261006-r1/supplementary_validation.json) ·
[R1 启动收据](../runs/m2-parameter-grid-20261006-r1/launch_receipt.json) ·
[实际启动复核](../runs/m2-parameter-grid-20261006-r1/startup_verification.json)。

实际运行复核：60 个预定评估槽位全部落盘，无新增请求或补抽；未完成前缀无终局金融结果，
传输占位分数已单独命名，未混入收益表。全部 86 个封存源码/配置文件与当前运行文件哈希一致；
首个 M1 进程的实际命令与保存命令一致，LR、seed、η=0、四轮预算核对通过。
模型已加载，真实初始 critic head 与共同基线完全一致，见
[critic 初始化复核](../runs/m2-parameter-grid-20261006-r1/critic_startup_verification.json)。

以下为首次协议的前置验收：

- 250 项集成测试、Ruff 与 diff 检查通过，包括 14 条真实 Hydra 命令的 LR/η/seed/预算核对。
- 两 seed 共 40 个完整 CPU 窗口回放通过，最大 prompt 4,593 tokens；训练与评估日期完全隔离。
- 输入与源码已封存，两个 seed 的 train/dev/calibration 文件逐字节相同；所有臂从共同 SFT fresh 开始。
- 真实 4B 无损归档与完整恢复通过，原模型精确分片 SHA 保持；8.22 GiB 归档约 119 MiB。
- 本批新模型验收后逐臂归档、退休临时 moments，旧模型与实验记录保留，基座必须持续保留。
- 独立 systemd 用户服务，Linger=yes、Restart=no、标准输入关闭、最长 48 小时；客户端断开不结束运行。

归档实现初次前置检查发现：共享 SFT 保存 398 个张量，RL 导出含独立 head 共 399 个张量。
双方 tied embeddings 配置与维度一致，已加入明确映射并在新目录通过真实模型完整回放。
这是存储布局兼容修复，未改权重或训练；首次检查失败证据保留。

## 首次扩展日期评估发现的问题

`formal-train-0399` greedy 在 2024-08-08 的 MSFT 当前权重为 20.137266% 时，
连续 253 次要求买到 20%，错误反馈可见但不恢复，最终达到 256 交互 cap。
每次响应 22 tokens，全部正常结束，未触及单响应 4096 cap；这是交易状态/错误恢复弱点。
同窗 sampled 四条均完整，但各自前置状态不同。49 条完整轨迹共 48/1,028 次非法请求，
其中 44 次为同类 buy 方向错误。未完成轨迹没有终局金融收益，不计成零收益。
原失败保留，详见[诊断收据](../runs/m2-grid-preparation-20261006/failure_analysis.json)。

R1 同样记录了这条 greedy 失败，但完成剩余全部基线尝试，进入原定训练。
以下只是**未 RL 的共同 SFT、完整轨迹部分**，用于后续同窗对照：

| 解码 | 完整/尝试 | 完整轨迹平均净收益 | 完整轨迹金融 Y | 完整轨迹非法请求 |
|---|---:|---:|---:|---:|
| greedy | 11/12 | 0.2394% | −3.0658 | 8/228 |
| sampled | 48/48 | 0.4828% | −2.9601 | 60/1,020 |

greedy 表中的非法请求另有失败前缀的 253 次拒单，单列在失败/全部尝试行为表中。
尚无本轮 M1/M2 收益；不同日期覆盖不能直接与上一批四窗均值作模型优劣比较。

## R1 自动读数与判读安排

每完成一臂保存部分读数；R1 会分别核对全部尝试、训练完整性和金融评估覆盖。
若存在未完成评估，不标记性能 PASS。文件尚未生成时表示相应阶段未完成。

| 文件 | 用途 |
|---|---|
| `LIVE_STATUS.md` / `progress.json` | 当前 seed/配置、落盘数量、验收臂数与粗略 ETA |
| `evaluation_curve.csv` | 逐 seed/LR/η/轮次/解码的收益、Y、风险、费用、合法性 |
| `paired_comparisons.csv` | 同 LR 的 M2−M1，以及各 RL−共同 SFT |
| `window_comparisons.csv` | 检查收益差额集中在哪些日期窗口 |
| `behavior_summary.csv` | hold/买卖、真实成交、拒单、现金与持仓覆盖/集中度 |
| `training_diagnostics.csv` | 实际优化器 LR、critic 拟合、actor advantage/概率漂移和 residual 强度 |
| `failure_summary.csv` | 未完成评估、重复拒单、非推进和受影响窗口 |
| `grid_readout.json` | 完整网格或 PARTIAL 状态、输入证据哈希与全部表格 |

完成后重点检查：收益/Y 的改善是否在两 seed、两种解码和更多日期上重复；
退化是否随轮次、更新幅度、拒单、现金比例或持仓集中度共同变化；
问题是否同时出现在 M1/M2，还是仅出现在某种 M2 信号设置。
保留所有候选结果，不用最好配置遮盖其他条件，也不单凭一个训练指标认定原因。
本轮没有自动追加 η=0.5、训练轮数、seed44、A1/A2 或正式 Valid/OOS。

R1 固定 1,944 次尝试加原失败批次 50 次，总计划 1,994 次；仍无新增 SFT 训练。
原启动估算为 **20–26 小时**；目前已失败停止，旧 ETA 不再表示剩余运行时间。
本次只复核状态、诊断和更新文档，没有启动新的恢复训练。

[启动收据](../runs/m2-parameter-grid-20261006/launch_receipt.json) ·
[封存合同](../runs/m2-parameter-grid-20261006/run_contract.json) ·
[验收收据](../runs/m2-parameter-grid-20261006/implementation_validation.json) ·
[R1 运行目录](../runs/m2-parameter-grid-20261006-r1/)。
