# M2 参数网格 R5：推理就绪，等待共享 GPU 容量

登记：**2026-10-08，新加坡时间（UTC+8）**。用户已明确要求启动训练，旧优化器约 80 GiB
未转为可用空间的存储原因留待后查。本文件记录新的执行身份与资源方式，实验参数沿用
[参数网格计划](2026-10-06_M2_PARAMETER_GRID_PLAN.md)和
[未完成评估处理规则](2026-10-06_M2_PARAMETER_GRID_EXECUTION_R1.md)。

当前进展：**2026-10-08 16:52 SGT（UTC+8）**。
**R5 后台服务 16:42:15 SGT 启动，16:43:44 SGT 容量门禁通过，16:43:58 SGT 网格进入 RUNNING。**
新目录为 `runs/m2-parameter-grid-20261008-r5/`，服务名 `m2-parameter-grid-20261008-r5.service`。
源码与输入合同于 **16:41:46 SGT** 封存。门禁实测 holder 保留 **76 GiB**、空闲加占位 **92.53 GiB**，
连续稳定 **60.36 秒** 后通过，由同一 PID **3553547** `exec` 原参数网格入口。
门禁要求 holder 完整保留 76 GiB、可用容量至少 76 GiB、没有其他认领，连续稳定 **60 秒**；
仅执行一次，先评估 seed42 共同 SFT 基线，再进入 M1/M2。
启动门禁最长排队配置为 **12 小时**，该门禁已通过；失败不自动重试，门禁通过也不构成 GPU 独占保证。

R5 的 critic、reference、actor 已分别于 **16:47:04、16:47:14、16:47:23 SGT** 完成初始化。
vLLM 引擎于 **16:49:45 SGT** 完成初始化（46.07 秒）：KV cache 可用预算 **10.34 GiB**、容量 **75,296 tokens**，
CUDA graph 捕获 2 秒、约 0.09 GiB。R4 的缓存初始化失败在本次没有重现。
但随后 `rollout_mode` 容量检查进入 **`waiting_for_capacity`**，尚未开始生成：
按 76 GiB 峰值预算，当前 worker 已知物理驻留约 **30.14 GiB**，所需驱动空闲约 **45.86 GiB**，
实测空闲约 **33.00 GiB**，相差约 **12.86 GiB**。已 sleep 的 private 池约 18.02 GiB 虚拟记录不计为物理驻留。
**服务仍 RUNNING，但等待共享 GPU 容量，零交易轨迹、零 RL 更新**。
此次 phase 首次等待为 **16:49:48 SGT**，默认最多等待 **1,800 秒**，约至 **17:20 SGT**；
仍无容量则停止，不自动重试，超时时刻以实际进程记录为准。
此等待与已经通过的启动门禁分开记录，不把推理就绪写成已经生成或训练。
日志另有 `_report_usage_worker` 使用统计线程中的 cpuinfo `JSONDecodeError`，未阻止引擎初始化，
不是当前容量等待条件；没有为此修改 vLLM。

R4 于 **16:25:39 SGT** 启动，**16:30:39 SGT FAILED**，零交易轨迹、零训练更新。
其生产 worker 的 **critic、reference、actor 初始化及对应显存交接均已通过**，
完成时间分别为 **16:28:57、16:29:06、16:29:16 SGT**，资源检查失败数为 0。
随后 vLLM 推理服务于 **16:30:34 SGT** 报 `No available memory for the cache blocks`，未能完成缓存初始化。
这是新的推理服务资源失败，不能抹去三模型初始化已通过的事实，也不能把本批算成成功训练。
R4 失败后复查另有 GPU 进程占用 **19,186 MiB**，当时可用容量约 74 GiB，低于启动时 92.57 GiB；
是否在 profiling 期间增长并影响缓存预算仍在核对，**尚未证明这一因果关系**。
控制组退出后持久 holder 正常补回，16:39 SGT 已恢复 76 GiB、另有约 16.53 GiB 空闲。
R5 保留现有推理设置，新增启动前稳定容量门禁，并仅为交接模块启用 INFO 日志，便于核对后续实际容量。
资源检查仅计入当前 worker 已知物理映射的 native 默认池显存，其他使用者均通过驱动全局空闲量反映，
已删除依据设备文件直接拒绝其他 CPU 进程的条件，**76 GiB 预算不变**。

R3 于 **16:17:20 SGT** 启动，**16:20:48 SGT** 初始化 FAILED，零交易轨迹、零训练更新。
其 `init_critic` 分配前的设备文件检查误拒绝 CPU 控制器、trainer 和 Ray 进程；打开设备文件不等于持有显存。
R3 尚未开始共同 SFT 基线生成；不是磁盘不足或 CUDA OOM。R4 修复误拒绝条件后使用新目录执行。

R2 于 **15:57:01 SGT** 启动，**16:00:28 SGT** 在初始化阶段 FAILED，零交易轨迹、零训练更新。
critic 初始化成功后，`init_reference` 检查报 `driver accounting cannot identify this worker's GPU residency`。
原因是驱动报告宿主机 PID，而容器内是另一套 PID，导致本项目的资源检查无法确认 worker 显存占用；不是磁盘不足。
R2 失败后持久占位已自动恢复 76 GiB。R3 修复资源检查后使用新目录执行，保留 R2 原始失败状态、源码身份与日志。

## 执行范围

- 从同一个 Qwen3-4B 共同 SFT v3 fresh 初始化；保持 non-thinking，不重新训练 SFT。
- seed42/43，每 seed 一个未 RL 的 SFT 基线和六个四轮 RL 臂，共 **1,944 次预定尝试**。
- Actor LR `1e-7` / `2e-7`；每个 LR 对照 M1、M2 η=`0.125` / `0.25`；共同 critic LR `1e-6`。
- 训练窗口、12 个原 Train 开发评估窗、greedy + sampled、奖励及成本口径均保持既定设置。
- 真实未完成评估保留为 INCOMPLETE，收益为空；训练或工程失败停止，不自动重试。

旧 R1 没有可续训的失败 M2 checkpoint，当前入口也不支持导入已完成的旧臂，因此本次完整重新执行。
旧成功 SFT/M1、失败 M2 的部分结果、原 FAILED 状态和日志保留，不拼成新批结果。
10月6日原批 **50 次**、R1 **288 次**，共 **338 次历史尝试**另列；本批预算仍为 1,944。
R2、R3、R4 失败各新增尝试 **0 次**。后续新批若执行完全部槽位，跨批累计尝试为 **2,282 次**，
不能写成只有 1,944 次。
沿用 v2 模板中 `preceding_*`、`cumulative_planned_attempts=1994` 等字段描述的是原批与 R1 的登记口径；
R5 的跨批账目以本说明及新目录 `execution_context.json` 为准，不改变原合同或历史收据。

## 资源与断线持续运行

使用已验证的 `persistent_gpu_memory_coordinator_v1`，绑定
`fca-gpu-reservation-persistent-20261007.service`。准备阶段持有 76 GiB；
控制器认领后，由 worker 在模型加载前释放占位并检查真实可用容量。
任务运行期间占位暂停且持有量为零；任务控制组全部退出后自动补回。
这减少显存交接竞争，仍不构成 GPU 独占保证。

R5 后台服务启动前磁盘约 **110.87 GiB 可用**，超过 **107 GiB** 门槛约 3.87 GiB。
保留逐臂检查、约 90 GiB moments 替换峰值、9 GiB 导出和 8 GiB 余量，不跳过空间检查。
成功臂只在证据与导出验证后退休自产 moments，并逐臂无损归档 actor；失败数据保留。
旧 80 GiB 未回收的问题不作为阻塞条件，也不假定它已经回收。

R5 使用独立 systemd 用户服务，`Linger=yes`、`Restart=no`、`KillMode=control-group`、标准输入关闭、
`MemoryMax=64G`、服务总时限 48 小时（含最多 12 小时门禁等待）。服务由服务器管理，SSH、IDE 或客户端断线不会结束排队或训练。
R2、R3、R4 均已失败退出，没有自动重试；原状态、日志和源码身份保留。
完整新批的原粗估为 **20–26 小时**，应从后续实际启动计算；目前没有新的完成时间。

## 启动检查与证据

R5 的资源检查不再依赖宿主机 PID 和容器 PID 相等，也不将其他 CPU 进程打开 GPU 设备文件直接视为显存驻留。
自身显存只计入 native 默认池快照中已映射的段（含已映射 expandable 段），排除全部 private/CuMem 池；
避免将 vLLM sleep 后仍有虚拟分配记录的内存误算为实际驻留。实验公式、奖励、采样和训练参数均未修改。
最终资源模块 **78 项测试通过，Ruff 通过**；网格与 INFO 日志相关 **62 项测试通过，Ruff 通过**，学习参数未变。
此前 v2 模块回归为 75 项，v1 修复与持久交接集成回归为 89 项，
R2 启动前回归为 114 项；它们是不同阶段的记录，不相加声称互不重复的测试总数。

此前 v1 的真实 CUDA 验证中，同一 worker 保持 **72 GiB** native 分配，连续通过两个 phase 的容量检查；
R5 保留同一物理驻留计入逻辑，不将这条记录冒称为最终 v3 又执行了一次 CUDA probe。
probe 控制器只等待 30 秒恢复占位，因等待时限过短退出码为 1；不能将整个 probe 服务写成成功退出。
holder 随后继续正常增长，并已另行核验恢复到 76 GiB，见[退出后补回记录](../runs/gpu-residency-probe-20261008/post_exit_refill_verification.json)。

R2 新执行的 **40 个 CPU 完整窗口回放全部通过**，最大 prompt 4,593 tokens。
R5 的两 seed 六份输入逐字节哈希、模型身份和 settings 均与 R2 精确一致；源码变化为资源模块与入口 INFO 日志，
CPU 回放相关 AST 不变。因此明确附来源复用 R2 的 CPU 回放记录，**没有声称 R5 又回放了 40 窗**。
R5 源码和输入封存及检查通过；容量门禁持续核对当前可用量，不使用 R4 启动前 92.57 GiB 代替实测。
上述资源验证不替代生产 worker 初始化和完整训练验收。

[容量门禁状态](../runs/m2-parameter-grid-20261008-r5/LAUNCH_GATE_STATUS.md) ·
[网格实时状态](../runs/m2-parameter-grid-20261008-r5/LIVE_STATUS.md) ·
[后台服务启动收据](../runs/m2-parameter-grid-20261008-r5/launch_receipt.json) ·
[实际启动与门禁核验](../runs/m2-parameter-grid-20261008-r5/startup_verification.json) ·
[当前资源等待快照](../runs/m2-parameter-grid-20261008-r5/resource_wait_snapshot.json) ·
[检查记录](../runs/m2-parameter-grid-20261008-r5/implementation_validation.json) ·
[输入预检复用来源](../runs/m2-parameter-grid-20261008-r5/input_validation_reuse.json) ·
[跨批执行账目](../runs/m2-parameter-grid-20261008-r5/execution_context.json) ·
[R4 初始化核验](../runs/m2-parameter-grid-20261008-r4/startup_verification.json) ·
[R4 原始失败状态](../runs/m2-parameter-grid-20261008-r4/state.json) ·
[R3 原始失败状态](../runs/m2-parameter-grid-20261008-r3/state.json) ·
[R2 原始失败状态](../runs/m2-parameter-grid-20261008-r2/state.json) ·
[旧 R1 失败记录](2026-10-06_M2_PARAMETER_GRID_REPORT.md) ·
[持久交接报告](2026-10-07_GPU_RESERVATION_HANDOFF_REPORT.md) ·
[磁盘清理记录](2026-10-08_DISK_CLEANUP_AUDIT.md)。
