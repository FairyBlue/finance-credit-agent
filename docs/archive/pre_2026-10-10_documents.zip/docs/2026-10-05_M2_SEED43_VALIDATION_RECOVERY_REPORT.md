# seed43：验收误报与剩余 M2 的继续执行

当前进展：**2026-10-05 22:41 SGT（UTC+8）**。
**继续执行已于 20:10:20 SGT 完成，164/164 条完整，最终验收 PASS；服务退出、GPU 释放。**
seed43 最终 M2−M1 为 greedy +0.2511、sampled +0.0033 个百分点（近乎持平）。
收益、风险及两 seed 对照见[最终报告](2026-10-05_M2_SEED43_REPLICATION_REPORT.md)。
以下保留故障、复验与继续执行过程。

原服务于 **17:40:10 SGT** 停止；原因已定位、修复并复验。
SFT/M1 的 **92/92 条轨迹完整**，M1 的 actor/critic 各四次更新及模型导出已成功。
原控制器仍记录 `FAILED`，新目录只执行尚未启动的 M2，不恢复旧训练状态。
M2 的继续服务于 19:07:53 SGT 启动，并于 20:10:20 SGT 正常完成。
实际 M2 worker 的 seed43、GPU 交接及初始 critic head 已核对；
head 与原 M1 相同，启动核对见[收据](../runs/m2-sft-four-round-comparison-seed43-20261005-recovery/startup_verification.json)。

## 原因与修复

`common_validity_penalty.validate_common_penalty_evidence` 的验收函数仍要求 `run_seed == 42`。
首个 seed43 训练批的真实记录为 43，因此在训练进程退出码 0、四轮全部结束后被误判。
错误消息把 seed、罚项与完整步骤数量合并描述，实际失败项是 seed。
这是 seed 泛化时漏掉的下游验收检查；启动前的实际 Hydra seed 检查没有覆盖此调用。

修复仅将该检查改为显式 `expected_seed`，由共同控制器传入 `profile.seed`。
默认 42 保持；新增 seed42/43 正例、错误 seed 拒绝及控制器传参的回归检查。
不修改奖励、M2 residual、GAE、优化器、推理框架、学习率、窗口或请求预算。
**110 项相关回归及 9 项继续执行检查通过，Ruff 通过。**

## 原数据复验

原 8 项封存输入和冻结源码副本完整；当前源文件仅包含两处已核对的验收修改及继续执行入口。
逐项复验了真实 seed43、轨迹网格、actor/critic 更新、critic 拟合记录、配对解码、
共同拒单罚、奖励守恒、罚后 critic returns、GPU 资源交换及最终 actor 完整哈希。
SFT/M1 的真实初始 critic head 相同，均为 seed43。

M1 训练有 **56/696** 个非法步骤，罚项总量 **2.80**；
M1 residual 保持零，金融 Y 未被替换为罚后总分，所有守恒和 critic 目标检查通过。
模型、样本和金融结果不需要重训或重采集。

| 原 seed43 已完成模型 | Greedy 平均含成本净收益 | Sampled 平均含成本净收益 |
|---|---:|---:|
| 共同 SFT | 1.6187% | 1.1089% |
| M1，第 2 轮 | 1.6655% | 0.8342% |
| M1，第 4 轮 | 1.7018% | 1.4229% |

最终 M1−SFT 为 greedy **+0.0832**、sampled **+0.3139 个百分点**。
M1 第 4 轮非法请求为 greedy 0/80、sampled 13/333，SFT sampled 为 6/326。
这张表是 M2 启动前的部分结果；最终 M2 与跨 seed 对照见上方最终报告。

## 继续执行边界与存储

原目录 `runs/m2-sft-four-round-comparison-seed43-20261005/` 中的原失败状态、错误日志、
M1 失败验收 summary、原模型、轨迹和冻结输入保持可追溯。
复验结果另存于 `runs/m2-seed43-revalidation-20261005/revalidation.json`。

新目录 `runs/m2-sft-four-round-comparison-seed43-20261005-recovery/` 封存修复后源码。
SFT/M1 的已有证据复制导入，明确标记来源和复验，不发出新的模型请求；
actor safetensors 以硬链接保留相同不可修改权重，避免重复占用 8.22 GiB。
新任务只执行 fresh M2 的 **32 条训练 + 40 条评估 = 72 条**，
与导入的 92 条共同形成原定 164 条比较，不追加 seed、窗口、siblings 或轮数。

原磁盘仅约 86 GiB 可用，M1 因误报留下的临时 moments 尚未退休。
复验确认 M1 已完整成功后，将其专属暂存目录移到新验收目录，
按原成功臂流程检查 owner/manifest、进程退出、逐块哈希和完整模型后退休临时 raw。
模型、原始轨迹和失败记录保留，清单与移动/退休收据保留；不支持恢复原优化器状态。
失败的训练或未通过复验的臂不适用这一处理。
此项已完成：退休 1,104 个临时 raw 文件，保留清单和收据，
实际可用空间从约 86 GiB 回到 **142.75 GiB**。

继续任务由新的独立 systemd 用户服务执行，`Linger=yes`、`Restart=no`；
运行前使用新有界 holder，首次加载前释放，期间不回补，结束关闭。
原服务不重启，新服务只尝试剩余 M2 一次，实际约 **62 分钟**。
实际服务为 `m2-sft-four-round-comparison-seed43-recovery-20261005.service`，
命令、封存哈希和预算见[启动收据](../runs/m2-sft-four-round-comparison-seed43-20261005-recovery/launch_receipt.json)。
现已按 seed43 的第 0/2/4 轮与 greedy/sample 汇总，并与 seed42 的差额方向比较。
这仍是两个 seed、四个重叠 Train 窗口的研发结果，不是正式样本外结论。

[原计划](2026-10-05_M2_SEED43_REPLICATION_PLAN.md) ·
[原失败状态](../runs/m2-sft-four-round-comparison-seed43-20261005/FINAL_RESULTS.md) ·
[复验记录](../runs/m2-seed43-revalidation-20261005/revalidation.json) ·
[新实时状态](../runs/m2-sft-four-round-comparison-seed43-20261005-recovery/LIVE_STATUS.md)。
