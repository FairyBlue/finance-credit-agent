# 持久显存占位与任务交接

当前进展：**2026-10-08 12:55 SGT（UTC+8）**。

**持久占位已补足 76 GiB，状态 HOLDING；空闲约 16.57 GiB，显存准入检查通过。**
10 月 7 日晚最初持有 71 GiB，之后无需人工重启即自动补足目标。
正常任务交接、重复交接和控制器退出后仍有子进程的情况均已通过真实 CUDA 测试。
本次只处理资源占位和交接，没有恢复 RL，也没有新增模型或交易轨迹。
10 月 6 日参数网格 R1 仍为原来的 FAILED，失败模型、日志和轨迹保留。

## 当前占位

服务为 `fca-gpu-reservation-persistent-20261007.service`，于 **10月7日21:16:44 SGT** 启动，
PID `3533487`。它通过独立 systemd 用户服务运行，`Linger=yes`，客户端断线不结束进程。
本次明确使用持久模式，没有此前六小时的到期释放；服务停止或服务器重启仍会释放。

- 空闲目标 76 GiB、上限 80 GiB；每次补入 1 GiB，至少保留 2 GiB 空闲余量。
- 只分配并持有空张量，不运行模型、推理、训练或算术计算。
- 达不到目标时保留已经申请的块，继续等待新空间，不操作其他人的进程。
- 10月8日12:55 SGT，实测持有 **76 GiB**，驱动空闲约 **16.57 GiB**，可回收占位加空闲约 **92.57 GiB**，
  高于生产任务 76 GiB 准入预算。整卡监控占用 78,353 MiB，约 76.52 GiB，包含张量之外的 CUDA 开销。
  本次未启动训练；磁盘仅约 77.91 GiB 可用，低于新 RL 的 107 GiB 预检要求，仍需腾出约 29.1 GiB。
- 历史记录：10月7日21:30 SGT 实测持有 **71 GiB**，实际 CUDA 空闲约 **2.92 GiB**，两者之和约 **73.92 GiB**。
  当时仍低于生产任务的 76 GiB 准入预算，所以不能称已经确保下一次训练可立即启动。

[占位实时状态](../runs/gpu-reservation-persistent-20261007/LIVE_STATUS.md) ·
[启动收据](../runs/gpu-reservation-persistent-20261007/launch_receipt.json) ·
[当前服务绑定](../runs/GPU_RESERVATION_CURRENT.json) ·
[10月8日容量复查](../runs/gpu-reservation-persistent-20261007/status_check_20261008.json)

## 交接方式

1. 没有训练任务时持续占位。训练排队时也保持增长，容量未满足前不提前释放。
2. 控制器检查实际空闲加已持有的张量容量，达到预算后认领租约、暂停增长，再检查一次。
3. worker 在模型初始化、推理引擎唤醒、计算、更新和保存前检查实际容量；释放自己的占位后再核查。
   若容量被其他进程拿走，等待容量恢复，不直接继续大额分配。
4. 一条训练任务运行期间，占位进程保持暂停且持有量为零，避免与生成和反向传播争抢。
   本版不在每次推理引擎睡眠期间补入占位。
5. 任务之间仅在控制器为该服务控制组唯一进程、已无 GPU 驻留时补回。
   整个控制组退出后，后台服务自动恢复空闲占位。
   不能只看主控制器 PID：Ray 或另起进程组的子进程仍活着时，继续保持暂停。

容量只抵扣**当前已验证 worker PID**已有的 GPU 驻留，同控制组残留的其他 GPU 进程阻止启动，
不会把上一臂模型占的显存当作下一臂可用的容量。无法核实进程身份、控制组或显存时停止交接。
跨进程释放与接手之间仍存在竞争窗口，因此这是尽可能保留容量的工程措施，不是 GPU 独占保证。

## 接入与验证

新的 `low_memory_pilot`、四轮对照和 `parameter_grid` **CLI prepare** 会自动读取当前服务绑定，
将占位服务身份、租约和资源预算写入新目录的 `gpu_coordinator_config.json`，随输入一同封存。
Ray worker 收到明确的配置路径和 SHA256。绑定失效时会报错，不静默回退到禁用占位。
程序直接调用 `prepare(...)` 时仍应明确传入 `coordinated_reservation_directory`。
运行控制器必须使用独立 systemd service，以便可靠检查全部子进程的存活状态。
旧的封存任务不会自动改变资源合同，不能直接恢复原 R1 来使用这套代码。

例如，下一批新目录可显式准备：

```bash
.venv/bin/python -m src.agents.parameter_grid prepare \
  --directory runs/<新的运行目录> \
  --coordinated-reservation-directory runs/gpu-reservation-persistent-20261007
```

资源配置没有改变 actor/critic 学习率、M2 公式、奖励、生成参数、训练窗口或轨迹预算。
实际 Hydra 参数逐项比较和配置传递测试通过；占位核心 105 项、最终集成回归 179 项及 2 项子测试通过，
Ruff 和 diff 检查通过。

| 真实 CUDA 验证 | 结果 |
|---|---|
| 正常接手、持有 2 GiB、退出、补回，连续两次 | PASS |
| 当前最终协调器源码重复上述两次交接 | PASS |
| 控制器先退出，另一个进程组的子进程仍持有 2 GiB | 占位保持暂停且零持有，PASS |
| 上述子进程结束，完整控制组变为空 | 自动恢复增长，PASS |

这些测试没有加载模型、没有训练更新；诊断阶段预算为 8 GiB，生产预算仍为 76 GiB。
它们验证占位与交接，不代表新的 4B 训练资源合同已经验收。

[验收收据](../runs/gpu-reservation-persistent-20261007/verification_receipt.json) ·
[最终源码正常交接](../runs/gpu-reservation-persistent-20261007/normal-probe-v2/controller_complete.json) ·
[子进程存活检查](../runs/gpu-reservation-persistent-20261007/orphan-probe/orphan_live_verification.json) ·
[子进程结束后补回](../runs/gpu-reservation-persistent-20261007/orphan-probe/orphan_exit_verification.json)
