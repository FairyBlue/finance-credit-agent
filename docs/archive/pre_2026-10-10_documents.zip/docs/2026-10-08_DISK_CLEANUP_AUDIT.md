# 磁盘组成与清理候选

检查时间：**2026-10-08 13:04 SGT（UTC+8）**。

后续执行（**2026-10-08 16:52 SGT**）：R5 后台服务 **16:42:15 SGT** 启动，
**16:43:44 SGT** 容量门禁通过，**16:43:58 SGT** 网格进入 RUNNING。
门禁实测 holder 完整 76 GiB、空闲加占位 92.53 GiB、无其他认领，稳定 60.36 秒后同 PID 执行原网格一次。
R5 三模型初始化通过，vLLM 引擎 **16:49:45 SGT** 就绪；随后 `rollout_mode` 等待共享 GPU 容量，**零交易轨迹、零 RL 更新**。
当前驱动空闲约 33.00 GiB，所需约 45.86 GiB；本次 phase 最多等待 1,800 秒，约至 17:20 SGT，无容量则停止。
这是显存容量等待，未发现磁盘阻塞；服务总时限 48 小时，断线独立，不自动重试。
R4 于 16:25:39 SGT 启动、16:30:39 SGT FAILED；三模型初始化通过，但推理服务缓存初始化失败，零轨迹/零更新。
未发现本次磁盘不足；其他 GPU 进程变化是否影响 profiling 仍未证明，R2/R3/R4 原始证据保留。
R3 此前于 16:17:20 SGT 启动，16:20:48 SGT 初始化 FAILED，零交易轨迹、零训练更新。
原因是资源检查误拒绝了打开 GPU 设备文件的 CPU 进程，**不是磁盘不足**；该误拒绝条件已删除。
显存预算暂保持 76 GiB，R2/R3/R4 原失败证据保留；固定实验参数和 1,944 次预算不变。
R5 后台服务启动前磁盘约 **110.87 GiB** 可用；本次没有继续删除文件。
此前 R2 于 15:57:01 SGT 启动，16:00:28 SGT 初始化 FAILED，零交易轨迹、零训练更新。
原因是驱动宿主机 PID 与容器 PID 差异触发资源检查，**不是磁盘不足**；R2 原失败证据保留。
见[M2 参数网格重启记录](2026-10-08_M2_PARAMETER_GRID_RESTART.md)。旧优化器空间问题留待后查。
[R5 资源等待快照](../runs/m2-parameter-grid-20261008-r5/resource_wait_snapshot.json) ·
[R5 容量门禁](../runs/m2-parameter-grid-20261008-r5/LAUNCH_GATE_STATUS.md) · [网格状态](../runs/m2-parameter-grid-20261008-r5/LIVE_STATUS.md)。

**最新执行：2026-10-08 14:32 SGT。按用户追加清理要求，失败 M2 的临时 Adam 张量中
共删除约 33.00 GiB，可用空间已实际增至 110.88 GiB，超过 107 GiB 的训练磁盘门槛。**
先试删不超过 1 GiB，确认可用量同步增加，再从同一候选中有界清理不超过 32 GiB；已停止清理。

| 本次追加清理 | 文件分配空间 | 删除后实测可用量 |
|---|---:|---:|
| 清理前 | — | 77.88 GiB |
| 先试删 78 个 `.raw` | 约 1.00 GiB | 78.88 GiB |
| 再清理 637 个 `.raw` | 约 32.00 GiB | **110.88 GiB** |

仅处理 `m2-parameter-grid-20261006-r1/seed42/m2_lr1e7_eta0125/artifacts/placement/moment_scratch/3527526/`
中已审计的失败运行暂存文件；两批共 715 个，剩余 **389 个，约 24.08 GiB** 保留。
该运行原 worker 已退出、状态 FAILED、无模型 checkpoint，原本就不支持续训；删除会失去相应
原始 Adam 张量的事后复查能力。actor/critic 原 `manifest.json`、`owner.json`、原失败状态、轨迹和日志保留，
新增部分清理标记；原有模型及元数据属性、受保护元数据哈希与剩余 raw 属性核对未变。

本次已用约 **419.01 → 386.01 GiB**，`df` 总量基本保持 **496.89 GiB**，
实际可用量增加约 **33.00 GiB**。这证明这批近期暂存文件可以回收；**不证明此前旧优化器的
80.41 GiB 已回收，也不能单凭两批差异就确认快照是根因**。旧文件可能涉及不同的快照引用或其他
存储限制，宿主机只读查询仍有意义。两批结果均已同步并重复检查。
GPU 持久占位仍为 **HOLDING / 76 GiB**；本次没有启动新训练，磁盘通过不替代其他启动检查。

[约 1 GiB 试删收据](../runs/disk-audit-20261008/recent_scratch_cleanup_probe_20261008.json) ·
[后续有界清理收据](../runs/disk-audit-20261008/recent_scratch_cleanup_bounded_20261008.json)。

以下保留此前两阶段的执行与诊断记录，时间和当时容量分别列明。

**执行更新：2026-10-08 13:17 SGT。用户确认的四份旧优化器已于 13:13:16 SGT 删除，
分配空间合计 80.41 GiB。** 四份文件均已不存在，四份对应 actor/critic 模型的文件属性、
原有元数据哈希未变；另核对了盘点中的其余 1,128 个大文件，inode、大小和修改时间均未变。
两处 checkpoint 新增 `optimizer_pruned.json` 和保留说明，明确不再支持原 Adam 状态续训。
后续统一推进 4B，不再安排 1.7B 实验；历史模型和记录仍保留。

**截至 13:17，旧优化器实际存储回收尚未确认：**已用空间从约 499.42 GiB 降至 419.00 GiB，但 `df` 可用量仍约
**77.89 GiB**，没有变成预计的 158.31 GiB，仍低于训练要求的 107 GiB。已完成 `sync -f` 并重复复查，
不能把“文件已删除”当作“可用容量已增加”。当前文件系统是 ZFS；容器内无法查看宿主机的
快照、配额和存储池属性，原因尚未确定。ZFS 的可用量还受存储池、配额与 reservation 等因素限制，
快照也可能保留数据块，这是需要核查的方向，尚非本次已确认的根因。
依据：[OpenZFS 属性文档](https://openzfs.github.io/openzfs-docs/man/v2.3/7/zfsprops.7.html)。

[实际清理收据](../runs/disk-audit-20261008/optimizer_cleanup_receipt.json) ·
[删除后的存储复查](../runs/disk-audit-20261008/post_cleanup_storage_review.json)。
本次没有恢复训练。

## 13:54 SGT 排查：文件占用减少，可用空间为何不增加

本节是 13:54 的诊断；14:32 新增临时文件清理的回收结果见文首。

**确认删除成功；尚未确认宿主机为何没有将这部分空间变成容器可用量。**
不是可用空间从约 158 GiB 降成了 77.8 GiB，而是删除前已有的约 77.9 GiB 基本没有增加。
此前将文件分配大小直接加到可用量、预计达到 158.31 GiB，没有验证 ZFS 快照和父级限制，
不能作为实际容量承诺。最新检查距删除已约 **41.5 分钟**。

| `df` 口径，GiB | 删除前 | 13:54 复查 | 变化 |
|---|---:|---:|---:|
| 已用 `Used` | 499.42 | 419.01 | 减少约 80.41 |
| 可用 `Avail` | 77.90 | 77.88 | 基本不变，另有约 17 MiB 日常写入差异 |
| 显示总量 `Size` | 577.32 | 496.89 | 减少约 80.42 |

### 已解释的部分：`df Size` 不是固定的物理磁盘容量

当前文件系统为 `tianmingS/containers/tianmingC`，内核 ZFS 版本为 `2.2.2-0ubuntu9.4`。
对应 OpenZFS 2.2.2 的 `zfs_statvfs()` 使用以下统计关系，忽略块大小舍入：

```text
df Used  ≈ 当前数据集 referenced
df Avail ≈ 受数据集、父级及存储池限制后的 available
df Size  ≈ referenced + available
```

因此，当前文件占用减少约 80 GiB、可用量不变时，`Used` 与 `Size` 就会一起下降约 80 GiB。
这与实测吻合；**不能据此说管理员把物理磁盘缩小了 80 GiB，也不能将原 577 GiB 当作已验证的固定配额**。
依据：[`zfs_statvfs()`](https://github.com/openzfs/zfs/blob/zfs-2.2.2/module/os/linux/zfs/zfs_vfsops.c#L1036-L1071)、
[`dsl_dataset_space()`](https://github.com/openzfs/zfs/blob/zfs-2.2.2/module/zfs/dsl_dataset.c#L2685-L2709)和
[`dsl_dir_space_available()`](https://github.com/openzfs/zfs/blob/zfs-2.2.2/module/zfs/dsl_dir.c#L1128-L1190)。

### 当前证据与未确定的原因

- 四份优化器路径均不存在；此前四份模型及原元数据、其余 1,128 个大文件的属性核对通过。
- 扫描了容器可见的 39 个进程，在可读取的文件句柄中没有发现被删除的优化器，也没有其他超过
  64 MiB 的已删除但仍打开的普通文件。部分系统进程不可读取，宿主机进程不在此检查范围内。
- inode 实际使用率约 0.31%（`df -i` 显示 1%），不是 inode 耗尽；已同步且多次复查，自有池可见的事务提交仍正常推进。
  经过 41.5 分钟仍未增加，不能仅以通常几秒的统计刷新延迟解释。
- 需要优先核查删除前的 **ZFS 快照或克隆是否仍引用旧数据块**。若保留旧数据，当前目录占用会下降，
  但池或包含快照的配额占用未必下降。另需核查父级配额、reservation 和存储池可分配空间。
  **这些是待验证原因，目前没有读到属性，不能直接认定“就是快照”。**

为读取属性，已将官方 Ubuntu ZFS 查询工具及依赖解包到本次审计目录，校验包哈希，
没有安装系统软件或启动服务；仅运行 `zfs get/list` 与 `zpool get`，禁用模块加载。
实际结果为：

```text
zfs get ... tianmingS/containers/tianmingC
  cannot open 'tianmingS/containers/tianmingC': dataset does not exist
zfs list -H -o name
  成功退出，但列表为空
zpool get ... tianmingS
  cannot open 'tianmingS': no such pool
```

挂载记录明确显示该数据集已挂载；容器根目录是其中的 `/rootfs` 子目录，
所以容器内看不到 `/.zfs/snapshot` 也不能证明宿主机没有快照。
OpenZFS 对未委派到当前用户命名空间的数据集会直接返回 `ENOENT`，与上述结果相符。
因此，文件能访问不代表容器能读取 ZFS 管理属性；需要在宿主机查询。
依据：[ZFS 读取权限检查](https://github.com/openzfs/zfs/blob/zfs-2.2.2/module/zfs/zfs_ioctl.c#L369-L380)和
[Linux 命名空间可见性](https://github.com/openzfs/zfs/blob/zfs-2.2.2/module/os/linux/spl/spl-zone.c#L264-L329)。

### 给管理员的三项只读查询

在 **H100 宿主机** 执行并返回输出即可，以下命令不会删除快照或改变配额：

```bash
zfs get -p used,available,referenced,usedbydataset,usedbysnapshots,usedbychildren,usedbyrefreservation,quota,refquota,reservation,refreservation,origin \
  tianmingS tianmingS/containers tianmingS/containers/tianmingC

zfs list -p -t snapshot -o name,used,refer,creation,clones -r tianmingS/containers/tianmingC

zpool get -p size,allocated,free,freeing,capacity tianmingS
```

这些结果可以区分快照保留、数据集或父级配额、存储池容量限制，并检查是否仍有待释放空间。
发现快照后仍需结合创建时间和引用关系判断，单有快照不证明本次 80 GiB 全由它保留。
本轮没有继续删除其他文件或修改存储配置；GPU 持久占位仍为 **HOLDING / 76 GiB**，没有恢复 RL。
当前可用量 **77.88 GiB** 仍低于 **107 GiB** 训练磁盘门槛。

[本轮诊断收据](../runs/disk-audit-20261008/storage_diagnosis_20261008.json) ·
[已删除文件句柄检查](../runs/disk-audit-20261008/open_deleted_file_review.json) ·
[数据集查询原始结果](../runs/disk-audit-20261008/zfs_dataset_properties_query.json) ·
[命名空间与池查询](../runs/disk-audit-20261008/zfs_namespace_visibility_query.json)。

## 删除前的盘点与候选评估

以下保留 **13:04 SGT 删除前** 的组成与评估。四份首选优化器已删，失败 M2 暂存文件后续又清理约 33 GiB；
空间收益数字是原估计，
**实际可用空间并未按该估计增加**，不能继续据此承诺清理其他文件就能通过训练准入。

## 磁盘组成

当前文件系统约 **577.32 GiB 总量、499.42 GiB 已用、77.90 GiB 可用，使用率 87%**。
新参数网格运行器要求至少 **107 GiB** 可用，当前缺约 **29.10 GiB**。

| 组成 | 占用约 | 说明 |
|---|---:|---|
| 项目 `runs/` | **458.91 GiB** | 约占已用空间的 92%，主要是模型、优化器和训练临时状态 |
| Python 环境、编译器及 micromamba 包缓存 | 18.12 GiB | 保留当前环境；占位服务正在使用 `finance-credit` 环境 |
| 用户 `.cache/` | 18.12 GiB | 其中 Hugging Face 约 11.30 GiB、uv 约 6.76 GiB |
| 编辑器、源码、系统等其他内容 | 约 4.26 GiB | 单项较小，不是本轮重点 |

`runs/` 的文件类型构成：

| 文件类型 | 分配空间约 |
|---|---:|
| checkpoint 模型权重 `.pt` | 193.88 GiB |
| HF 模型与 adapter 权重 `.safetensors` | 125.24 GiB |
| 剩余 checkpoint 优化器 `.pt` | **80.41 GiB** |
| 磁盘 Adam 临时张量 `.raw` | **57.08 GiB** |
| 无损 actor 归档 | 0.18 GiB |
| 日志、轨迹、源码副本、配置及其他 | 2.11 GiB |

较大的实验目录：

| 目录（`runs/` 下） | 总占用约 | 主要内容 |
|---|---:|---|
| `m2-learning-restart-20260913` | 90.44 GiB | 共同 SFT 前的三个 checkpoint；9月17日已删优化器，现在主要是模型权重 |
| `m2-screening-20260907-v9` | 87.48 GiB | 旧 4B A2 step8 模型与优化器 |
| `m2-common-sft-short-rl-20260914` | 60.24 GiB | 共同 SFT 后早期两轮 M1/M2 模型权重 |
| `m2-parameter-grid-20261006-r1` | 57.24 GiB | 几乎全是失败 M2 留下的 Adam 临时张量 |
| `m2-screening-20260906-v4` | 36.31 GiB | 旧 1.7B 模型与优化器 |
| `m2-training-tuning-20260914` | 24.72 GiB | 三臂 tuning 模型 |

## 优先候选：旧优化器，保留模型

| 优先顺序 | 范围 | 预计释放 | 删除影响 |
|---|---|---:|---|
| 1 | 旧 4B A2 step8 的 actor、critic 优化器 | **57.08 GiB** | 失去该旧 checkpoint 的原 Adam 状态续训能力；actor/critic 权重仍保留 |
| 2 | 旧 1.7B M2 step1 的 actor、critic 优化器 | **23.33 GiB** | 同上；该批属于旧 R1 工程失败样本，后续已有新的工程验收 |
| 合计 | 四个文件 | **80.41 GiB** | 当前共同 SFT v3 和新训练入口不受影响 |

具体文件均名为 `optim_world_size_1_rank_0.pt`：

```text
runs/m2-screening-20260907-v9/screening-a2-s42/checkpoints/global_step_8/actor/optim_world_size_1_rank_0.pt
runs/m2-screening-20260907-v9/screening-a2-s42/checkpoints/global_step_8/critic/optim_world_size_1_rank_0.pt
runs/m2-screening-20260906-v4/wiring-m2-s42/checkpoints/global_step_1/actor/optim_world_size_1_rank_0.pt
runs/m2-screening-20260906-v4/wiring-m2-s42/checkpoints/global_step_1/critic/optim_world_size_1_rank_0.pt
```

只清理第一项，预计可用空间增至 **134.98 GiB**；两项都清理，预计增至 **158.31 GiB**。
两批另有历史 BF16 actor 导出及来源收据，但它们不等同于原 FP32 模型或完整训练状态；
本建议仍保留原 actor/critic 权重，不将导出当作原精度备份。
执行删除时应另存清理收据、标记 checkpoint 已裁剪，原完成记录作为历史证据保留。

## 其他可选候选

| 候选 | 预计释放 | 判断 |
|---|---:|---|
| 10月6日失败 M2 的 `moment_scratch` 中 1,104 个 `.raw` | **57.08 GiB** | 可作为第二阶段清理。它们不是模型 checkpoint，现存状态不能续训；删除会失去原始优化器张量的事后复查能力 |
| 9月13日共同 SFT 前三个 checkpoint 的六份模型权重 | **90.39 GiB** | 已被当前路线替代，最终无交易且 critic seed 存在已披露缺口；可以讨论退休，但删除后无法重评这些具体权重 |
| uv 缓存 | **约 0.15 GiB 可回收** | 表面约 6.76 GiB，但其中约 6.60 GiB 与缓存之外的环境共享硬链接，不能把它全部算成释放量 |

失败 M2 临时张量目录：

```text
runs/m2-parameter-grid-20261006-r1/seed42/m2_lr1e7_eta0125/artifacts/placement/moment_scratch/3527526/
```

若后续清理这一项，仅退休原始 `.raw`，保留 `owner.json`、`manifest.json`、失败日志、交易轨迹、
更新探针和原 FAILED 状态。owner 明确记为 `fresh-run Adam moment scratch; not a restart checkpoint`；
失败 M2 没有导出同步 actor checkpoint，不能用这些 moments 拼成续训起点。

90.39 GiB 的旧权重是 9月17日删除六份优化器后**剩下的模型**，不能误称优化器还未清理。
删除前曾预计首选优化器清理就能满足准入；实际未通过，不能据此继续删除历史权重或近期失败张量。

## 保留内容与检查边界

保留当前共同 SFT v3、近期成功 M1/M2 模型、原始行情和评估证据、基座模型缓存、Python 环境及占位服务。
其中 `runs/m2-coldstart-v3-20260914/merged_model/` 同时是新训练的共同起点，以及现有无损 actor 归档的
解码基座，**不能删除**。已有网格 M1 归档只有约 81 MiB，清理价值很小且会丢失成功模型。
旧 `agentr1` 环境继续保留，沿用此前用户偏好。

本次核对了目录分配空间、文件类型、inode、硬链接计数、历史来源收据和当前入口依赖，未加载大型张量。
候选四个优化器、六个旧权重及 1,104 个临时张量都是普通文件，硬链接计数为 1。
当前唯一运行的项目服务是 GPU 占位，没有本批训练进程；失败 M2 控制器和 worker PID 已不存在。
可读取的本用户进程中未发现打开候选文件的句柄；两个受限 `/proc` 进程是 `sd-pam` 和 `sshd`，
没有把部分进程检查写成全系统保证。`runs/` 唯一符号链接指向普通汇总 JSON，与候选无关。

空间按 `stat.st_blocks × 512` / `du` 估计，硬链接去重；实际释放量仍以删除后的 `df` 为准。
完整文件列表和 inode 信息见[候选清单](../runs/disk-audit-20261008/candidate_inventory.json)，
另有[目录与类型盘点](../runs/disk-audit-20261008/run_inventory.json)、
[缓存与进程检查](../runs/disk-audit-20261008/liveness_and_cache_audit.json)和
[来源复核](../runs/disk-audit-20261008/provenance_review.json)。
