# 共同 SFT 起点的四轮 M1/M2 学习对照

当前进展：**2026-10-05 15:00 SGT（UTC+8）**。
**本批已于 03:03 SGT 完成，164/164 条轨迹完整，两臂各四轮。**
第 4 轮 M1/M2 两种解码平均净收益均高于 SFT，M2 均高于 M1；
完整结果与限制见[最终报告](2026-10-05_M2_SFT_FOUR_ROUND_COMPARISON_REPORT.md)。
没有启动下一批，A1/A2 暂缓。以下保留事前计划及启动时的执行记录。

启动记录（2026-10-05 00:53 SGT）：用户已确认优先完成本对照，A1/A2 暂缓。
代码与输入已准备；**426 项 CPU 测试、2 个子测试及 12/12 窗完整回放通过**，Ruff 通过。
用户已批准清理并开始运行。旧临时状态清理完成，实际释放 **114.16 GiB**，
启动前可用 **168.37 GiB**。新 holder 已配置，输入和源码已封存；
独立服务于 **2026-10-05 00:50 SGT** 启动，控制器当前为 `RUNNING / sft0`。
正在准备/评估未 RL 基线，尚无本批收益结果。预计整批约 2–3 小时，取决于共享 GPU 负载。

## 目的

先回答两个问题：从相同共同 SFT 出发，M1/M2 的 RL 更新是否提高收益；
在相同训练条件下，M2 的额外 step credit 是否带来相对 M1 的增量。
本批固定当前 M2 公式、η 和学习率，使用原定四轮预算，不根据中途收益追加轮数或换设置。

本批是原 Train 内的研发对照，不包含 A1/A2、正式 Valid 或 Final OOS。
报告同时给出原始含成本净收益、金融评分 Y、风险、成本、非法请求、完整率和交易行为。
不能用罚后训练总分替代金融结果，也不以买入次数作为成功标准。

## 固定实验

| 项目 | 设置 |
|---|---|
| 共同起点 | 已验收的 Qwen3-4B SFT v3，actor/reference/critic backbone 相同 |
| 初始化 | 独立 fresh 训练臂；critic `cpu_seed_v1`，seed42；核对真实初始 head |
| 实验臂 | SFT0：零 RL 更新；M1：η=0；M2：η=0.25 |
| 训练预算 | M1/M2 各 4 轮；每轮 2 windows × 4 siblings，共各 32 条训练轨迹 |
| 训练日期 | 沿用既有日期覆盖的前八窗：0001、0065、0009、0073、0017、0149、0025、0157 |
| 评估日期 | 固定四个日期隔离的原 Train 窗口：0113、0117、0121、0125 |
| 评估预算 | SFT 第 0 轮及两臂第 2/4 轮；每窗 1 greedy + 4 sampled |
| 总预算 | 64 条训练 + 100 条评估 = **164 条**，完成即停止 |
| 学习率 | actor 2e-7；critic 1e-6 |
| 奖励 | 两臂共同 `Y/N − 0.05 × invalid`，末步保留原守恒余差；M2 residual 仍按原 Y |
| 推理 | 共同 non-thinking、现有生成参数和单工具交易接口 |
| 导出 | 两臂最终 actor BF16 HF；SFT0 不训练、不重复导出共同模型 |

窗口统一前缀为 `formal-train-`。两轮工程小试及历史四/八轮结果保留作为历史参照，
不拼接其轨迹或恢复其优化器；本批以新身份完整执行所有臂。
greedy、sampled 分开汇总，按相同窗口报告相对 SFT 和相对 M1 的差值。

## 资源与存储

沿用已通过两轮验收的 `chunked_adam_disk_v1`：全参数训练、64 MiB GPU 分块缓冲，
活跃 Adam moments 在 pageable CPU，非活跃角色 moments 在专用磁盘暂存。
reference BF16 CPU、vLLM sleep、microbatch 1、gradient checkpointing 等共同设置保持。
不修改 vLLM，不改 LoRA 或量化优化器。

上一批实测约 69.5 GiB allocated / 72.6 GiB reserved，放行时有约 75.7 GiB 空闲。
本批仍需检查实际资源，不把两轮通过解释为严格 60 GiB 可运行。
GPU 占位与加载前交接沿用有租期的独立服务：首次加载前释放，训练和臂间不自动回补。
占位不能保证对其他用户的原子交接，不停止其他用户进程。

准备时磁盘可用 **53.4 GiB**，不足训练暂存预算。已完成两轮运行的两处
`artifacts/placement/moment_scratch/` 分配占用共 **114.2 GiB**；
用户于 10 月 5 日确认后，只清理了这两处临时 Adam 文件。
模型权重、完整轨迹、配置、报告和状态清单保留；两份模型完整哈希复验通过。
限定清理清单已保存于
[`scratch_cleanup_inventory.json`](../runs/disk-audit-20261004/scratch_cleanup_inventory.json)：
只列 2,208 个 manifest 已记录的数据块，不包含 owner/manifest 或模型文件。
实际删除及延迟空间回收核验见
[`scratch_cleanup_receipt.json`](../runs/disk-audit-20261004/scratch_cleanup_receipt.json)，
全部数据块不存在，8 份 owner/manifest 哈希保持原样。

本新批次不支持续训；每臂成功且导出/证据验收全部通过后，退休本批自产的临时 moments，
保留 manifest、owner、交换事件和清理收据。失败臂暂存完整保留。
这样避免成功臂的临时状态累计占满磁盘；每臂启动前仍检查暂存、剩余模型导出及余量。

## 验收与运行

- 输入回放覆盖全部训练和评估窗口，确认均来自原 Train、日期隔离、prompt/context 完整。
- 核对两臂初始 critic head、相同训练更新预算、拒单罚与金融奖励的分离、M2 residual 定义。
- SFT0 必须只有 20 条评估、零 actor/critic 更新；两训练臂各 32 条训练、40 条评估、4 次各类更新。
- 资源交换与模型导出验收通过后，按第 0/2/4 轮及两种解码分别报告读数。
- 收益提高若伴随成本、风险或拒单恶化，一并报告；单 seed 小试不作正式优势结论。

入口预定为 `python -m src.agents.low_memory_comparison`，新目录
`runs/m2-sft-four-round-comparison-20261004/`。
由 `systemd --user` 独立服务运行，`Restart=no`，断网不结束服务；失败停止且保留证据。
状态页以新加坡 UTC+8 刷新，不自动重试、不恢复旧 checkpoint。
实际服务为 `m2-sft-four-round-comparison-20261005.service`，最长 8 小时；
holder 为 `fca-gpu-reservation-20261005.service`，租期 6 小时，结束后关闭。
`Linger=yes` 已核对；未做实际网络断连注入测试。
启动命令及封存哈希见[启动收据](../runs/m2-sft-four-round-comparison-20261004/launch_receipt.json)，
当前轨迹数与阶段见[实时状态](../runs/m2-sft-four-round-comparison-20261004/LIVE_STATUS.md)。
完成后使用 `scripts/diagnostics/m2_low_memory_comparison_readout.py` 生成收益差表、
按轮次和解码方式的完整均值表及 JSON。既有请求 seed 包含 policy step，
SFT0 与第 2/4 轮 sampled 不共享完全相同的采样随机数，不将其称为同随机数配对。

依据：[两轮最终报告](2026-10-04_M2_GPU_HANDOFF_PILOT.md)、
[原四轮共同拒单罚计划](2026-09-17_M2_COMMON_VALIDITY_PENALTY_PLAN.md)。
