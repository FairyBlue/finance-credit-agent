# Blocked framework changes

If a required feature cannot be implemented through Agent-R1's public `ToolEnv` / `BaseTool`
plugin interfaces, add an entry below with:

- the required feature;
- the exact blocking file and symbol under `third_party/agent-r1/`;
- why composition or a plugin cannot solve it;
- the upstream issue or proposed extension point.

Do **not** fork, patch, or edit files under `third_party/`.

## Entries

None recorded. The current research limitation is not an upstream framework blocker:
the completed Train comparison has not established a pooling advantage. Next work is CPU
validation of state-conditioned concrete-order credit, gates and baselines; see the
[latest mechanism result](docs/2026-10-14_M2_CREDIT_ORACLE_PROBE_REPORT.md) and
[current handoff](docs/EXPERIMENT_HANDOFF.md).
