# finance-credit-agent

**Current evidence — 2026-10-14 (UTC+8):** the Qwen3-4B action-pooling comparison is complete:
**1,336/1,336 trajectories** (256 Train, 1,080 evaluation), two seeds, four updates per RL arm.
On the fixed fourth-round sampled endpoint, M2−plain was **−0.0381 / −0.0930 percentage points**
for seeds 42/43; M2 also trailed both M1 learning-rate controls. These are Train development
results and do not establish a pooling advantage. Formal Valid and Final OOS remain closed.

The subsequent mechanism audit and CPU oracle probe are also complete. Pooling can reduce
independent disturbance when concrete actions have the same effect, but grouping different orders
under buy/sell can introduce bias and erase rankings. The next task is to define credit for a
**specific order in a fixed state**, then test order grouping, disagreement gates and state baselines
separately on Train states. Keep reporting four-sibling singleton coverage; defer larger RL grids
until a candidate passes these mechanism checks.

Start with the [experiment handoff](docs/EXPERIMENT_HANDOFF.md) and [document index](docs/README.md).
The current evidence is in the [completed comparison](docs/2026-10-12_M2_ACTION_POOLING_COMPARISON_REPORT.md),
[mechanism audit](docs/2026-10-14_M2_ACTION_POOLING_MECHANISM_REPORT.md) and
[CPU oracle probe](docs/2026-10-14_M2_CREDIT_ORACLE_PROBE_REPORT.md).
Installation is in [SETUP.md](SETUP.md); day-to-day collaboration is in
[COLLABORATION.md](docs/COLLABORATION.md).

## Research question and implemented mechanism

This project tests whether finance-native **step-level credit assignment** improves a tool-using
trading agent over outcome-only GRPO and terminal-outcome StepPO. It composes with the locked
[Agent-R1](https://github.com/AgentR1/Agent-R1) submodule through local extensions.
The [research brief](RESEARCH_BRIEF.md) remains a draft; the [evaluation protocol](EVAL_PROTOCOL.md)
and [M2 screening specification](M2_V1_PREREGISTRATION.md) define their respective boundaries.
The screening specification is not a final preregistration.

The proposed formal ladder is:

| Arm | External training reward | Role |
|---|---|---|
| A1 | Terminal net return | Outcome-only GRPO reference |
| A2 | The same terminal net return | Critic + GAE + GSPO StepPO control |
| A3-M0 | Terminal financial score `A_fin` | Terminal-objective control |
| A3-M1 | Conserved immediate rewards `A_fin / T` | Reward-timing control and required M2 baseline |
| A3-M2 | The same M1 base rewards, plus actor-only post-GAE `eta * S` | Candidate credit method |

This is a proposed formal comparison, not a completed five-arm result. Current Train screening
uses the separately calibrated `benchmark_scale_v2` score `Y`, not the formal ladder's original
`A_fin`. Terminal-only A2 and M1/M2 screening are implemented; legacy dense A2 is a separate
supplementary baseline. State/regime conditioning and counterfactual M3 remain research proposals.

**Implemented M2 pools session-aligned siblings by action family.** Four trajectories from the
same episode occurrence and policy snapshot are aligned by advancing session, then grouped by
`buy`, `sell`, `hold` or `abstain`:

```text
S_t = mean(Y of siblings choosing action family a_t) - mean(Y of all four siblings)
A_t = Whiten_step(GAE(M1 base rewards, critic values) + eta * S_t)
```

The disagreement gate requires at least two legal advancing action families. Residuals are zero on
retrieve, compute, invalid and no-disagreement steps; their base GAE signal remains. `S` enters
neither rewards nor critic targets and is not passed through GAE again. The current plain control
uses centered individual `Y` under the same gate and StepPO stack; it is not standard GRPO.
See [sibling_credit.py](src/rewards/sibling_credit.py) and
[screening_runtime.py](src/agents/screening_runtime.py).

The grouping matches neither portfolio state nor concrete stock/target-weight orders. Its relative
terminal-outcome signal is not an identified causal contribution. The latest CPU probe additionally
shows that credit rankings depend on the evaluation horizon and fixed continuation rule; one-day
returns cannot replace the original financial `Y` without changing the target.

## Completed stages and limits

- Historical G1 and A3-M1 wiring smokes passed; they establish real rollout/optimizer wiring,
  not formal performance. See the [H100/M1 summary](docs/history/01_H100_AND_M1.md).
- Common initialization and early M1/M2 development comparisons are summarized in
  [common initialization and learning](docs/history/05_COMMON_INITIALIZATION_AND_LEARNING.md).
- Four-round 4B comparisons, seed replication, resource recovery and pre-R5 failures are summarized
  in [4B comparison and runtime](docs/history/06_4B_COMPARISON_AND_RUNTIME.md).
- The [R5 grid](docs/2026-10-11_M2_PARAMETER_GRID_R5_REPORT.md) completed training but retained
  29 incomplete greedy evaluations. The subsequent
  [common recovery SFT acceptance](docs/2026-10-11_M2_ORDER_RECOVERY_SFT_REPORT.md) passed
  1,200/1,200 fixed acceptance trajectories. It resolved the tested rejection loops, not all invalid
  requests or general performance issues.
- The latest pooling comparison used the new common SFT/observation version. Its results cannot be
  spliced with R5, and its complete execution does not imply a method advantage.

Dated backup snapshots remain under [September 17](docs/results/2026-09-17-backup/README.md) and
[October 4](docs/results/2026-10-04-backup/README.md). Most `runs/`, data and model artifacts are
local evidence and are not included in a source checkout. Historical capacity and service statuses
are snapshots; check actual resources and the selected run's receipts before execution.

## Reproducibility and data boundaries

- Agent-R1: `b124aa46534cbf2fb8bc8af11405774984c42ac7`; verl: exactly `0.7.0`.
  Do not edit `third_party/` or upgrade the GPU stack independently.
- StepPO method reference: [arXiv:2604.18401v4](https://arxiv.org/abs/2604.18401v4).
  The paper pin does not replace the executable commit pin.
- New engineering and training use **Qwen3-4B**. Earlier 1.7B smokes remain historical evidence.
- Train/Valid use frozen daily-history snapshots; Final OOS uses the pinned StockBench source.
  `StockBenchAdapter.get_observations(as_of)` enforces `available_at <= as_of`.
- Shared `PortfolioLedger` accounting applies next-open execution, commission and slippage to
  agents and baselines alike. News and unaudited current-fundamentals caches remain disabled.
- The reviewed formal manifest contains 441 Train, 60 Valid and one indivisible 83-session Final
  OOS episode. T2 v2 passed on history Train/Valid; this does not prove absence of leakage or
  authorize formal training. Legacy OOS probes remain disabled.
- Training records model/data/code identity and structured evidence under `runs/<run_id>/`.
  A run's exact frozen sources and receipts govern its identity; a later `main` commit is not
  automatically validated. Formal training requires clean code and complete preflight.

Full identities, scorer semantics, review requirements and OOS rules remain in
[EVAL_PROTOCOL.md](EVAL_PROTOCOL.md), [SETUP.md](SETUP.md) and
[H100_COMPATIBILITY.md](docs/H100_COMPATIBILITY.md).

## Local setup and project map

```bash
git submodule update --init --recursive
uv sync --frozen
uv run --no-sync pytest
```

The default environment is CPU-only. Use [SETUP.md](SETUP.md) for the frozen GPU environment.
Current jobs must use their own frozen 4B plan and contract; old 1.7B smoke commands are historical.
`scripts/run_queue.sh` remains fail-closed disabled.

| Path | Purpose |
|---|---|
| `configs/` | Arm configs, frozen data assumptions and flow recipes |
| `src/data/`, `src/env/` | Point-in-time adapters, observations and shared trading ledger |
| `src/rewards/` | Formal/scoped screening scores, M1 rewards and sibling residuals |
| `src/agents/` | Training, acceptance, resource coordination and evidence |
| `src/evaluation/` | Shared metrics and baselines |
| `tests/` | Leakage, accounting, mechanisms and runtime checks |
| `docs/` | Current reports, phase summaries and retained frozen contracts |
| `runs/` | Ignored local execution evidence |

Before formal training, freeze the selected main method, matched controls, resource accounting and
M2−M1 superiority statistic under the existing protocol. Beating A1/A2 without beating M1 cannot
establish a credit-assignment contribution. M3 requires its own preregistration and schedule-matched
sham control. The current next step remains CPU validation of state/order credit; see the
[next-step plan](docs/2026-10-11_M2_NEXT_STEPS.md).
