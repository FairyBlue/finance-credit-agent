# 共同 SFT / M1 / M2 四轮对照：seed43 复跑

当前进展：**2026-10-05 22:41 SGT（UTC+8）**。
**已于 20:10:20 SGT 完成，164/164 条完整；M1/M2 各四轮更新，最终模型已保存，GPU 已释放。**
seed43 M2−M1 为 greedy +0.2511、sampled +0.0033 个百分点（近乎持平），
详见[最终结果与两 seed 对照（阶段汇总）](history/06_4B_COMPARISON_AND_RUNTIME.md)。
原服务于 17:40 SGT 因验收函数残留 seed42 检查而停止。
SFT/M1 的 92 条轨迹及 M1 四轮更新已完整，修复只读验收后复验通过。
新目录继续尚未启动的 M2，共 72 条；不重训或重采样 SFT/M1，原失败记录保留。
剩余 M2 的独立服务于 **19:07 SGT** 启动，并于 **20:10 SGT** 正常完成。
执行边界见[修复及继续执行报告（阶段汇总）](history/06_4B_COMPARISON_AND_RUNTIME.md)。
以下保留原启动时的记录和事前固定设置。

启动记录：**2026-10-05 16:32 SGT（UTC+8）**。
用户已批准用另一 seed 复跑。**独立服务已于 16:27:48 SGT 启动，当前 `RUNNING / sft0`。**
82 项 CPU 测试、Ruff、12/12 窗完整回放及输入/源码封存检查通过。
训练与评估数据、奖励校准文件与 seed42 逐字节一致，共同模型身份未变。
当前为共同 SFT 的准备/评估阶段，尚无本批金融结果。
首个 worker 的真实 critic head 已确认为 seed43；GPU 交接验收通过，
占位释放后空闲约 91.04 GiB。vLLM 的实际启动日志显示 seed43，已进入第 0 轮评估批次。
核对收据见 [startup_verification](../runs/m2-sft-four-round-comparison-seed43-20261005/startup_verification.json)。
本批 seed **43** 在训练开始前固定，不根据收益更换 seed 或增加轮数。

目的：检查[seed42 四轮结果（阶段汇总）](history/06_4B_COMPARISON_AND_RUNTIME.md)是否可重复。
保留相同共同 SFT 起点，重新执行 SFT0 / M1 / M2；与旧批分别报告，再比较收益差方向。

| 项目 | 本批固定设置 |
|---|---|
| Seed | **43**，作用于请求采样、vLLM、数据 RNG、actor RNG 和共同 critic head 初始化 |
| 共同模型 | Qwen3-4B SFT v3，actor/reference/critic backbone 相同 |
| 实验臂 | SFT0 零 RL；M1 η=0；M2 η=0.25 |
| 训练 | M1/M2 各四轮，各 32 条训练轨迹、actor/critic 各四次更新 |
| 训练窗口 | 0001、0065、0009、0073、0017、0149、0025、0157，前缀 `formal-train-` |
| 评估窗口 | 0113、0117、0121、0125，原 Train 内预留日期，与训练日期隔离 |
| 评估预算 | SFT 第 0 轮，M1/M2 第 2、4 轮；每窗 1 greedy + 4 sampled |
| 总预算 | **164 条**，完成即停止，无自动重试、无恢复旧训练状态 |
| 学习率 | actor 2e-7；critic 1e-6 |
| 奖励 | 两臂共同 `Y/N − 0.05 × invalid`；M2 residual 仍按原 Y |
| 推理与资源 | 原 non-thinking 单工具接口；全参数 `chunked_adam_disk_v1`，64 MiB GPU 缓冲 |
| 导出 | 两臂最终 actor BF16 HF；成功臂临时 moments 按既定流程退休，证据保留 |

除了 seed 和运行身份，本批不调整模型、公式、η、学习率、窗口、罚项、采样参数或预算。
代码修改仅使共享控制器使用明确的 profile seed，默认 seed42 保持；
真实 Hydra 命令检查须覆盖 actor/critic FSDP seed、vLLM seed、数据 seed 和请求 seed 环境变量。
运行后继续验收实际 critic head、更新次数、轨迹完整性和金融奖励与拒单罚的分离。
新三臂的真实初始 critic head 应互相一致；不要求其与 seed42 的新建 head 相同。

原始运行目录 `runs/m2-sft-four-round-comparison-seed43-20261005/`，
入口 `python -m src.agents.low_memory_comparison_seed43`。
训练由独立 systemd 用户服务执行，`Linger=yes`、`Restart=no`、最长八小时。
实际服务为 `m2-sft-four-round-comparison-seed43-20261005.service`；
启动命令、时点和封存哈希见[启动收据](../runs/m2-sft-four-round-comparison-seed43-20261005/launch_receipt.json)。
bounded holder 最长六小时，首次加载前释放；训练期间和臂间不回补，整批结束关闭。
客户端断开不结束独立服务；未注入真实网络中断测试。

预算约 **2–3 小时**，以实际共享 GPU 负载为准。
沿用上一批成功臂退休临时 moments 的存储方式，本批开始前仍检查空间余量。
旧 seed42 模型、轨迹、冻结源码、报告均保留；不清理额外历史模型。

验收按 seed / 第 0、2、4 轮 / greedy、sampled 分开。
报告原始含成本净收益、金融 Y、回撤、成本、非法请求、完整率及相对 SFT/M1 的差额。
请求 seed 包含 policy step，SFT0 与后续 RL 不共享完全相同的采样随机数。
四个评估窗口彼此重叠，两个 seed 的正向结果也不替代正式样本外验证。
本批不包含 A1/A2、正式 Valid 或 Final OOS，不因复跑结果追加训练。

实时状态见 [LIVE_STATUS](../runs/m2-sft-four-round-comparison-seed43-20261005/LIVE_STATUS.md)。
完成后独立服务自动生成 `comparison_readout.json`、`evaluation_curve.csv`、`comparison_summary.csv`。
