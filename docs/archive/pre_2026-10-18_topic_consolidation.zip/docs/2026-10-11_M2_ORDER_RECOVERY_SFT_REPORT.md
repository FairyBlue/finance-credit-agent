# 共同恢复 SFT：执行与验收

2026-10-11，SGT（UTC+8）。**第一步共同拒单恢复已完成，以本批固定验收范围为限。**共同SFT完成72次更新、CPU合并及400条独立验收；同初始化新M1/M2的一轮检查272条原生轨迹全部完整。最终all-v2于22:12—23:21完成1200/1200条、6579次真实请求，独立raw审计、行为门禁及严格完成回执均PASS。首批编排失败及此前两版反馈失败全部保留。

此前[两版反馈复评](2026-10-11_M2_ORDER_RECOVERY_V2_REPORT.md)全部结束：方向解释版拒单短测166/180，正常60/60，完整回合238/240；反馈修复单独仍不足。随后按[训练前固定的计划](2026-10-11_M2_ORDER_RECOVERY_LEARNING_PLAN.md)完成共同恢复SFT及新初始化验收。本轮未启动plain性能对照。

## 第一步最终验收

[原轨迹诊断](2026-10-11_M2_ORDER_RECOVERY_REPORT.md)确认：`0399`、`0441`等窗口实际可见权重已大于0.2，模型仍反复提交`buy target_weight=0.2`；基础提示原本已有总仓位及买卖方向规则，舍入不是这29条旧循环的主要解释。修复先补充共同拒单上下文、精确权重和合法方向反馈，单独反馈复评仍失败，再训练一份共同恢复SFT。成交、成本和奖励计算未改变，模型仍自行选择动作。

最终合同覆盖六个旧拒单窗口、两个正常窗口及24个未参与本次恢复SFT的新状态；greedy与sampled配额全部保留。四个新RL臂均从同一新SFT初始化、使用v2观察，seed42/43的M1/M2各完成一次actor及critic更新，再统一验收。

| 方法，两seed请求身份合计 | 历史拒单短测 | 正常短测 | 新状态方向/股票/总目标 | 完整回合 | 合计 |
|---|---:|---:|---:|---:|---:|
| SFT | 60/60 | 20/20 | 240/240 | 80/80 | 400/400 |
| M1 | 60/60 | 20/20 | 240/240 | 80/80 | 400/400 |
| M2 | 60/60 | 20/20 | 240/240 | 80/80 | 400/400 |
| 全部 | 180/180 | 60/60 | 720/720 | 240/240 | 1200/1200 |

960条短测全部首个请求合法推进，低于固定四次上限。[实际动作核对](../runs/m2-order-recovery-acceptance-all-20261011-v2/short/known_recovery_actions.json)确认180条历史拒单恢复全部为原股票的`sell 0.2`，都有真实卖出和费用，零hold/abstain逃避。960条模型可见提示与普通render_prompt精确重建一致，没有追加离线teacher字段；通用v2反馈本身提供方向及API示例，因此证明的是利用反馈恢复。

240条完整回合均到达真实终点，最长28次请求，固定总上限256未增加。完整回合仍发生819次拒单（818次方向错误、1次symbol越界），全部在第一次后续请求恢复，低于四次后续请求门槛；206/240条回合有多次恢复事件。SFT/M1/M2分别272/277/270次恢复；这是消除本批卡死，不能写成不再发生拒单。完整回合含8次模型自行选择的合法hold恢复，没有脚本代选动作。

[独立raw审计](../runs/m2-order-recovery-acceptance-all-20261011-v2/raw_audit.json)覆盖全部1200条、6579次请求，验证请求映射、拒单不改账本、合法推进一个session和真实终局财务；[最终读数](../runs/m2-order-recovery-acceptance-all-20261011-v2/readout.json)为`OBSERVED / behavioral_gate PASS / acceptance PASS`。raw审计SHA为`b5b7c635f28ccd6d973e7f39905a535bfd71ac39ceb5253d37b88ab73c5bc69d`，readout SHA为`48ea200507bc576d5f1c0a1bd21dcdb4dc2e690fcc084ffc7967b1251802326d`。

[严格完成回执](../runs/m2-order-recovery-acceptance-all-20261011-v2/completion_runtime_receipt.json)为PASS：129份运行源码与封存一致，控制器COMPLETE，ExecStopPost记录本次真实退出码0，holder已恢复76GiB且无租约。新批与失败all-v1的manifest逐字节相同，未重新训练、未挑选性重试或丢弃模型失败；失败批400条前缀及退出码1保留。

## 正常成交与成本核算

[最终240条财务描述](../runs/m2-order-recovery-acceptance-all-20261011-v2/financial_activity_description.json)保留全部轨迹、采样及配对身份，未完成数0。两个正常窗口各组20条均完整，每条均有真实买入、卖出和正交易费用；零成交轨迹均为0。

| 正常窗口，两seed身份合计 | 实际buy/sell成交数 | 佣金与滑点合计 | 均换手 | 均净收益 |
|---|---:|---:|---:|---:|
| 本次SFT重复验收 | 207 / 169 | 83096.88 | 2.74996 | 1.7111% |
| M1一次更新后 | 212 / 169 | 82001.74 | 2.71493 | 1.6779% |
| M2一次更新后 | 209 / 172 | 83674.93 | 2.77014 | 1.7114% |

同动作旧版/v1/v2的[48条完整账务审计](../runs/m2-order-recovery-audit-20261011/accounting_recovery_v2.json)继续适用：412次逐步比较、32次终局比较、96次真实费用检查及48次拒单状态不变检查通过，相关执行和成本源码未改。这支持正常成交链路和成本核算无回退，不等同于一般收益或策略表现无回退。

财务配对参考是此前共同SFT的400条门禁，其中正常20条均净收益1.7018%；相对它，本次SFT重复、M1、M2变化分别为+0.0093、−0.0239、+0.0096个百分点。重复SFT不算新训练样本；费用变化伴随换手变化。这些仅为选定Train窗口的一次更新后描述，不能作为M2优势、一般收益保证或四轮稳定性证据。正式Valid/FinalOOS未打开。

第一步验收结束，下一阶段才比较M1两档LR、M2-plain和M2。由于共同SFT及观察已改变，四臂必须从新共同初始化重做四轮，不能与旧R5拼接；本轮未启动第二步。

## 数据与训练

[数据清单](../runs/m2-order-recovery-sft-20261011-v1/dataset_manifest.json)固定384条：192条新接口恢复示范（80buy、80sell、32容差内hold），加192条原正常示范的逐字节回放。新恢复标签只用当前仓位与请求目标，不用未来收益；原回放保留既有财务教师先验。

另留24个不同日期、权重及目标组合的Train状态，未混入本次训练，并与训练及六个已知失败窗口按日期隔离。数据生成时的123份源码已独立[封存并核验](../runs/m2-order-recovery-sft-20261011-v1/dataset_runtime_sources_receipt.json)；最长5196 token、零截断。

从原共同SFT初始化，只训练一份：seed42、LoRA16/alpha32、3epochs、micro1、累积16、LR5e-5、completion-only，共72次更新。实际[训练合同](../runs/m2-order-recovery-sft-20261011-v1/training_contract.json)、源码快照、逐次更新记录和合并权重回执均保留。控制器核对384条示范每epoch覆盖一次、真实参数变化、优化器及adapter哈希，全部通过后才进行CPU合并。

启动前新训练流程的100项专项CPU测试通过；此前158项训练组合检查也已通过，其中部分与专项重叠。独立raw审计已使用400/1200条真实CPU环境轨迹验证编排和账务，这些使用模拟引擎的测试不证明真实模型的恢复能力。

实际[训练证据](../runs/m2-order-recovery-sft-20261011-v1/training_evidence_readout.json)验证72次真实更新、384条各覆盖3次、1152次样本呈现及全部artifact哈希；[合并证据](../runs/m2-order-recovery-sft-20261011-v1/merge_evidence_readout.json)通过。结束时129份源码与快照一致，服务成功退出，见[完成回执](../runs/m2-order-recovery-sft-20261011-v1/completion_runtime_receipt.json)。新共同权重的指纹为`083ad9e7f56d02a3e7dd376571656d1e3af05c1ec62ba7b2467a59c36d637fa5`；这只表示初始化已完成，不表示恢复验收通过。

18:21首次验收准备被seed身份唯一性检查阻止：fresh24的原始`step=0/sample_index`与四个历史case相撞。尚未创建验收目录或发出模型请求，见[准备失败回执](../runs/m2-order-recovery-sft-20261011-v1/acceptance_preparation_failure_1.json)。保留原数据、bank及训练源码快照，只为fresh请求新增确定的`request_seed_identity`（sample24–47），原来源身份及known/full种子不变。生产与独立审计从原bank哈希重算映射，枚举全部21760次预定63bit seed派生并拒绝不同payload碰撞；320次短测/完整回合同payload重用保留。这在任何模型响应前固定，没有选择推理seed或更改行为门槛。

编号修复的52项相关CPU测试和Ruff通过，含真实历史身份、旧种子不变、篡改和常量seed拒绝启动负测，见[修复验证](../runs/m2-order-recovery-sft-20261011-v1/request_seed_fix_validation.json)。18:34冻结修复版本并重新准备400条验收。`probe.grid`以外AST与原账务版本相同，其余账务源码全相同，[原账务审计继续适用](../runs/m2-order-recovery-sft-20261011-v1/accounting_applicability_after_seed_fix.json)。

18:39—18:53完成独立service推理：[400条验收合同](../runs/m2-order-recovery-sft-acceptance-20261011-v1/manifest.json)，SHA-256 `2e697e9664bcd1addedf6b4b4ff27d28cdede3273279aedef14c0e4278af73c6`。冻结源码、审计脚本、模型lineage及全部父子清单；[独立raw审计](../runs/m2-order-recovery-sft-acceptance-20261011-v1/raw_audit.json)通过，最终[门禁读数](../runs/m2-order-recovery-sft-acceptance-20261011-v1/readout.json)为`OBSERVED/PASS`。129份运行源码与快照一致，服务成功退出，holder恢复76GiB且租约解除，见[结束回执](../runs/m2-order-recovery-sft-acceptance-20261011-v1/completion_runtime_receipt.json)。

## SFT门禁结果

| 验收项 | 结果 |
|---|---:|
| 六个历史拒单状态 | 60/60恢复，每条一次请求 |
| 两个正常状态短测 | 20/20合法推进，每条一次请求 |
| 24个新状态短测 | 240/240恢复且保持正确方向、symbol与原总目标 |
| 从现金起跑的完整回合 | 80/80到达真实终点 |
| 完整回合实际拒单恢复 | 288/288，最多一次后续请求 |
| 全部预定观测及raw审计 | 400/400，2208次真实请求，PASS |

[实际动作核对](../runs/m2-order-recovery-sft-acceptance-20261011-v1/short/known_recovery_actions.json)确认六个历史case的60条恢复全部将原`buy 0.2`改为同股票`sell 0.2`，真实产生卖出成交；无hold或abstain逃避。320条提示均由普通render_prompt和真实takeover state精确重建，未追加离线teacher字段。通用v2反馈本身提供方向说明和API示例，本结果证明模型学会利用此接口反馈恢复，不证明无辅助的方向计算或一般策略最优。

正常策略的[80条配对财务读数](../runs/m2-order-recovery-sft-acceptance-20261011-v1/financial_retention.json)保留全部身份、采样和逐窗分层；两正常窗口的20条新旧轨迹均完整且每条都有买卖，零成交轨迹均为0。原/新分别buy219/209、sell160/169，成交总数379/378；费用合计107628.86/82926.03，均换手3.56295/2.74515，均净收益1.2945%/1.7018%（配对变化+0.4073个百分点）。这仅为选定开发窗口的描述，费用下降伴随换手下降，不能延伸为一般策略保真或性能优势。

## 执行前固定的验收门禁（已执行）

先以新SFT完成320条短测和80条完整回合。原六个失败状态须四次请求内合法推进；新24状态还须保留最后请求的合法方向与总目标，容差内由模型选择hold。完整回合总请求256、首次invalid后四次后续请求内恢复。全部400条行为通过且独立原始审计通过后，才启动新RL。

新M1/M2各两个seed，统一新SFT与v2观察，从头各训练一轮、actor/critic各一次更新，检查恢复能力是否经一次RL更新保留；不作为四轮性能证据。最后统一执行960条短测、240条完整回合及原始审计。SFT重复验收及两个请求身份不算独立训练样本。

同动作成交与费用的48个完整回合审计已通过，环境代码此后未改；另如实呈现真实模型的成交、费用和收益变化，不能从账务一致推出策略表现一致。旧失败保留，不增加请求上限、不替选动作；正式Valid/FinalOOS保持关闭。

正常策略的配对财务脚本已通过13项CPU检查；不完整侧不产生终局均值或配对差值。本批80条全部完整，未丢弃任何轨迹。

## 同初始化的一轮RL检查

SFT门禁通过后，首个[准备目录](../runs/m2-order-recovery-learning-stage1-20261011-v1/)已完成输入预检与封存，但启动前发现两seed之间缺少磁盘异步回收等待，故保留为[零请求、零更新的准备记录](../runs/m2-order-recovery-learning-stage1-20261011-v1/superseded_before_launch.json)，不覆盖重用。统一新SFT指纹与v2观察，seed42/43各新M1/M2，固定32条训练及240条原生评估。原生成功不替代最终1200条严格恢复验收，不将一轮结果当作四轮稳定性证据。

磁盘交接修补只允许核验本批成功退役的临时moments后，在seed边界最多等待300秒、每5秒读取真实可用空间；满足原56GiB子批门槛才首次启动下一seed，超时即停止。首批74GiB及通用多轮门槛不变，不把已删除字节当作已归还容量，不触碰旧临时文件，也不重试训练。修补后的新批次重新预检、封存。已完成SFT400只通过其原始PASS回执、全部归档源码及原始轨迹校验历史版本；活跃验收仍严格核验当前源码，旧验收文件不改写。

修补后的[新批次目录](../runs/m2-order-recovery-learning-stage1-20261011-v2/)已完成两seed的市场数据预检（各16窗口、最长4593 token）与合同封存，19:27启动独立service，见[启动回执](../runs/m2-order-recovery-learning-stage1-20261011-v2/launch_receipt.json)。两处工程源码之外，SFT400的129份运行源码有127份保持字节一致，见[版本适用核验](../runs/m2-order-recovery-learning-stage1-20261011-v2/engineering_changes_after_sft_gate.json)。[114项不同的相关CPU测试及Ruff](../runs/m2-order-recovery-learning-stage1-20261011-v2/engineering_validation.json)已通过；未改变SFT权重、观察、反馈、交易执行、费用或行为门槛。

20:05阶段读数：seed42的SFT0完整40/40，M1训练8/8、评估40/40完整，actor/critic各一次真实更新、参数哈希变化、HF导出通过；当前M2初始化中。M1本批552份临时moments共32179765256字节已严格核验退役，模型、原始轨迹及所有权清单保留。

20:29阶段读数：seed42整批136/136完成（训练16、评估120），M1/M2各一次actor及critic更新，SFT0/M1/M2的critic初始head哈希一致；两份HF保留，两臂本批临时moments已核验退役。seed43继续相同预算，执行顺序为SFT0→M2→M1。最终1200条严格验收仍未执行。

21:06阶段读数：seed43的SFT0评估40/40、M2训练8/8及评估40/40全部完成，actor/critic各一次真实更新，HF及临时moments退役核验通过。累计224/224条原生轨迹完整，最后一个seed43/M1臂启动中；原生总预算272及最终1200条严格验收门槛不变。

21:31原生检查全部结束：32条训练及240条评测共272/272完整，四个RL臂各一次actor及critic真实更新，每个seed内三臂critic初始head一致，四份HF与lineage完整保留。[独立完成核验](../runs/m2-order-recovery-learning-stage1-20261011-v2/completion_runtime_receipt.json)通过全部产物、300份源码副本及holder归还检查，状态明确为`PASS_ARTIFACTS_WITH_SERVICE_EVIDENCE_LIMIT`：临时systemd服务已被回收，未持久记录数值退出码；仅依据真实CLI的run/PASS、完整产物、同invocation无失败的manager日志推断正常退出，不能声称直接核验了退出码。旧审计器对此拒绝的记录与脚本均保留，没有重跑训练。

21:43最终[1200条验收合同](../runs/m2-order-recovery-acceptance-all-20261011-v1/manifest.json)准备及校验完成，manifest SHA-256 `c4f539da964e511bc6bb7e08b8f01522a86a2b80741fc25bbb1a23f00efcdb0a`。五个引擎、六个请求身份、960短测与240完整回合；观察、权重、seed、四次恢复门槛与256总上限均固定。该批将另记录控制器实际返回码，不能只凭被回收unit的默认字段签PASS。

21:45独立service已[启动](../runs/m2-order-recovery-acceptance-all-20261011-v1/launch_receipt.json)，实际[start回执](../runs/m2-order-recovery-acceptance-all-20261011-v1/service_start_receipt.json)绑定manifest、129份源码及wrapper SHA。wrapper仅等待原controller子命令并记录真实返回码，不改推理参数或请求预算；14项CPU检查通过，未用模拟返回码代替本次实测。

21:59首批停止：SFT短测320/320、完整回合80/80已观察，2195次请求；冻结审计器的`--model-key sft`只读部分审计PASS，但整批`acceptance_pass=false`，其余800条未启动。新增wrapper作为控制器的等候parent留在同一cgroup，违反协调器“组内仅控制器PID”的idle条件；[真实退出回执](../runs/m2-order-recovery-acceptance-all-20261011-v1/service_exit_receipt.json)记录返回码1，不能算通过。保留[失败记录](../runs/m2-order-recovery-acceptance-all-20261011-v1/orchestration_failure_receipt.json)及全部前缀，改为服务结束后的ExecStopPost取证；将在新目录以相同模型、source、seed和上限完成全1200条复评，不重跑训练、不选择性剔除模型失败。

SFT0的[原生轨迹活动核对](../runs/m2-order-recovery-learning-stage1-20261011-v2/analysis_scripts/native_sft42_activity.json)记录953次决策：153次invalid、合法buy439/sell354/hold7。152个拒单事件全部恢复，其中151个用一次后续请求、1个用两次，恢复动作无hold。两正常窗口10条全部有真实买卖与正费用，逐笔佣金/滑点、现金及持仓链核对一致。原生路径只施加256总上限，没有施加四次后续响应门禁；该事后统计不替代最终严格验收。

22:12新批[all-v2](../runs/m2-order-recovery-acceptance-all-20261011-v2/launch_receipt.json)已启动，manifest与all-v1逐字节相同，129份运行源码不变。控制器直接作为唯一主进程运行，ExecStopPost仅在它退出后记录systemd的SERVICE_RESULT/EXIT_CODE/EXIT_STATUS；真实CPU主进程0/7两次[集成验证](../runs/m2-order-recovery-acceptance-all-20261011-v2/analysis_scripts/exec_stop_post_smoke/validation.json)证明准确记录且不与主进程重叠。新launcher10项、完成核验7项检查通过；尚无本次真实退出收据和最终行为PASS，旧批没有被覆盖。

22:55阶段读数：all-v2已观察640条短测合法推进、160条完整回合到达真实终点，共800/1200。已完成SFT、seed42/M1和seed42/M2；seed43两臂尚待验收。独立只读抽查SFT与seed42/M1的90条known恢复，全部由模型首个请求选择原股票`sell 0.2`，有真实卖出、现金增加及非零佣金/滑点，零hold逃避；其30条normal完整回合每条都有真实买卖。此处是局部结果，不能代替全1200条raw审计和最终PASS。

## 资源与当前状态

使用既有holder租约、独立service、64GiB容器内存上限，单次训练最长1小时、CPU合并最长30分钟。新训练child在模型加载前固定native allocator、可扩展segment及60GiB缓存分配上限；外层仍按设备总体显存80GiB停止，仅停止本任务子进程。缓存上限不包括CUDA上下文或其他进程，实际启动还核验至少60GiB空闲和不超过16GiB既有使用量。

旧还原模型副本退役后，文件系统曾异步归还到约108GiB可用空间。保留通用多轮磁盘门槛；新鲜单轮的专用74GiB门槛已通过CPU optimizer交换实证和真实模型参数预算验证，四份新actor全部保留。最终验收结束后实时可用约67GiB；本批临时moments按所有权核验退役，旧约24GiB暂存未动。

最终[验收目录](../runs/m2-order-recovery-acceptance-all-20261011-v2/)已完成，无本批运行中的训练或推理；holder为HOLDING、76GiB、无claim、无error。第二步尚未启动。

[运行目录](../runs/m2-order-recovery-sft-20261011-v1/) · [控制器状态](../runs/m2-order-recovery-sft-20261011-v1/controller_state.json) · [逐次训练记录](../runs/m2-order-recovery-sft-20261011-v1/training/steps.jsonl)。
