# 历史原文归档

更新：2026-10-17。日常阅读使用[文档导航](../README.md)与[六份阶段总结](../README.md#10-月-10-日前的阶段汇总)。本目录保存整理前原文，用于追溯原判断、失败、精确身份及旧哈希。

| 原文包 | 范围 | 文件映射与 SHA-256 |
|---|---|---|
| [10 月 10 日前原文 ZIP](pre_2026-10-10_documents.zip) | 本次整理前仍在顶层的 53 份日期文档（日期早于 2026-10-10），加两份旧跳转交接；包含尚未提交的本地原文 | [本次 manifest](pre_2026-10-10_manifest.json)，逐文件记录原路径、大小、哈希、保留/合并去向与 `read_now` |
| [9 月 13 日前原文 ZIP](pre_2026-09-13_documents.zip) | 上次整理保存的 49 份原文；包括更早已合并、不在当前目录中的过程文件 | [原 manifest](manifest.json)，保留原有映射及当时保护文件哈希 |

本次将 9 月 12 日—10 月 8 日的 26 份报告、运维记录和重复规划合为[阶段五](../history/05_COMMON_INITIALIZATION_AND_LEARNING.md)与[阶段六](../history/06_4B_COMPARISON_AND_RUNTIME.md)，2873 行压为 212 行。`CODEX_HANDOFF.md` 和 `H100_COMPATIBILITY_HANDOFF.md` 的引用分别直达[实验接手指南](../EXPERIMENT_HANDOFF.md)与[H100 兼容性说明](../H100_COMPATIBILITY.md)，原路径不留跳转文件。

历史方案保留其规则、预算及代码所需路径；指向合并报告的导航已最小修订。**旧身份核验使用 ZIP 原文字节或对应 `runs/.../plan.md`，不能拿整理后的工作副本哈希替代旧 SHA。** 需要按原路径重算 SHA 的历史工具，应在隔离的历史 checkout 中恢复原文，不能把最新代码和旧合同拼成同一执行身份。10 月 11 日以后的封存执行方案未因整理修改。

查找原文件名时，先按 manifest 的 `original_path` 定位；`read_now` 给出当前阅读入口。ZIP 内保留仓库相对路径，并含同一份 `MANIFEST.json`。例如将本次原文解压到临时目录：

```bash
python3 -m zipfile -e docs/archive/pre_2026-10-10_documents.zip /tmp/finance-credit-docs-before-20261010
```

包内是文档，不包含模型、行情、optimizer 或运行日志。原 `runs/` 收据、历史来源路径与哈希没有改写；两次 `docs/results/` 的 manifest 绑定有效载荷也保持原字节。它们的历史相对链接可能指向当时未备份的文件，查缺失原文使用上述归档，当前导航不依赖这些旧链接。

本次阅读入口已更新到截至 10 月 14 日的完成证据；历史文中的“当前”“下一步”、GPU 占位和磁盘容量只在原记录时点有效，不能作为新任务或实时状态。
