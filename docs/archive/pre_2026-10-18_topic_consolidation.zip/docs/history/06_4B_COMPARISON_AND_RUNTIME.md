# 阶段六：4B 四轮对照与资源工程（9 月 30 日—10 月 8 日）

整理日期：2026-10-17。合并低显存工程、两 seed 四轮对照、参数网格早期失败及磁盘记录；原文见[历史归档](../archive/README.md)。冻结方案作为历史数据合同保留，不表示待执行任务。本文中的容量、PID、服务状态均为注明日期的历史记录；`runs/` 路径相对仓库根目录，完整产物主要在服务器。

**4B 全参数训练在实际约 75.7 GiB 空闲下跑通，两 seed 四轮对照获得局部正向结果，但 sampled 的 M2 增量没有稳定重复。** 扩展日期后的首轮网格先后遇到 greedy 拒单和共享显存 OOM，由此加入未完成评估隔离及持久显存协调。10 月 8 日启动记录只覆盖当时的等待状态；R5 后来完成的结果单独见[10 月 11 日最终报告](../2026-10-11_M2_PARAMETER_GRID_R5_REPORT.md)，不混作当时已知结果。

## 低显存路径：从初始化 OOM 到 72/72 完成

资源实现 `chunked_adam_disk_v1` 保持 actor/critic FP32 全参数、原全局裁剪和学习率调度；活跃 Adam FP32 moments 在 pageable CPU，GPU 临时分块最大 64 MiB；非活跃 moments 经长度、SHA256、fsync 验证后暂存磁盘，再释放主存。reference BF16 CPU、vLLM sleep、microbatch1、gradient checkpointing 等共同保留，没有改成 LoRA 或量化 optimizer。

| 日期/身份 | 实际结果 | 能支持什么 |
|---|---|---|
| 9/30 低显存 pilot | 队列 62.43 GiB 空闲时放行，随后外部占用增加；reference FSDP 初始化申请 194 MiB 时仅余 84.75 MiB，CUDA OOM；0/72、零更新 | 没有运行到分块 Adam，不能判断其稳定 60 GiB 训练能力；无新增 host OOM |
| 10/02 占位试验 | 独立 holder 从 30 GiB 增到 59 GiB、OOM 0；有界六小时租期，release 先暂停增长 | 仅空张量占位，尚无训练；释放后对所有进程开放，非独占预留 |
| 10/04 handoff pilot | 72/72 完整；M1/M2 各 16 条训练、20 条评估、actor/critic 各两次更新，导出成功 | 首次加载前实际交接空闲 75.7156 GiB；峰值约 69.5 GiB allocated、72.6 GiB reserved，不能称严格 60 GiB 已验收 |

10/04 全部八次分块更新成功（每次 993 块、6.7—18.2 秒），有 moments 的磁盘切换 131—190 秒，第二轮恢复通过；整批约 68.6 分钟。主存采样峰值 M1/M2 57.19/57.58 GiB，无新增 host OOM 或 hard-limit 事件，曾触及软限额。没有同批 stock Adam 速度对照，不能报告可靠减速倍数。

两轮收益：M1/M2 greedy 1.6874%/1.7704%，sampled 1.5063%/1.6010%，M2−M1 分别 +0.0830/+0.0948 个百分点。sampled 非法请求 M1 21/341、M2 18/338，训练为 19/339、20/340；没有重跑 SFT0，因此只作工程验收与本批两臂比较。holder 最终关闭，模型为 BF16 actor 导出，不含 optimizer，不能原状态续训。

## 四轮 SFT0/M1/M2 对照与 seed43 复跑

共同设置：Qwen3-4B SFT v3 fresh 起点，actor/reference/critic backbone 相同；同 seed 各臂真实初始 critic head 哈希一致；actor LR `2e-7`、critic LR `1e-6`，M1 η0、M2 η0.25。共同训练奖励 `Y/N−0.05×invalid`，M2 residual 仍按原金融 Y，评估使用原 Y 和含成本净收益。没有重新训练共同 SFT 或修改 vLLM。

训练八窗为 `0001/0065/0009/0073/0017/0149/0025/0157`，评估四窗为 `0113/0117/0121/0125`（前缀均为 `formal-train-`）。每 seed：SFT0 20 条评估、每 RL 臂 32 条训练和第 2/4 轮共 40 条评估，总计 164 条；最终第 4 轮事前固定，不按最高收益择点。

| 第四轮含成本净收益 | seed42 greedy | seed42 sampled | seed43 greedy | seed43 sampled |
|---|---:|---:|---:|---:|
| SFT0 | 1.6187% | 1.5094% | 1.6187% | 1.1089% |
| M1 | 1.7704% | 1.6794% | 1.7018% | 1.4229% |
| M2 | 1.8481% | 1.8861% | 1.9529% | 1.4261% |
| M2−M1（百分点） | +0.0777 | +0.2067 | +0.2511 | +0.0033 |

seed43 sampled 差只有约 0.33 基点，视为近乎持平；两 seed 的正向均值不证明稳定 sampled 优势。seed42 第二轮 M2 还低于 M1（greedy −0.1294、sampled −0.0010 个百分点）；seed43 第二轮两臂 sampled 均低于 SFT，第四轮才改善。不能描述为从开始持续领先或越训越好。

seed42 M2−M1 sampled 四窗均为正，但相对 SFT 前两窗下降，主要提升在后两窗；seed43 则两窗正、两窗负。四个滚动评估窗仅覆盖 33 个不同交易日，彼此重叠，不能按独立胜窗作显著性判断。两个 seed 的三组净收益都低于约 4.2216% 的等权 benchmark。

| 第四轮 sampled | seed42 SFT / M1 / M2 | seed43 SFT / M1 / M2 |
|---|---|---|
| 非法请求 | 6/326、11/331、7/327 | 6/326、13/333、16/336 |
| 平均最大回撤 | 1.1721%、1.3144%、1.1892% | 1.4737%、1.3553%、1.3388% |
| 平均成本（账户美元） | 5608.36、5391.80、5509.62 | 5517.40、5503.31、5485.77 |

M2 相对 M1 的回撤较低，但非法率改善未跨 seed 重复；seed43 M2 sampled 金融 Y −5.3316，略低于 M1 −5.3005。共同拒单罚没有消除非法请求，也不能据此称风险调整表现全面领先。

两 seed 各 164/164 完整、每臂各四次 actor/critic 更新。seed42 于 10/05 03:03 完成，约 2 小时 12 分钟；seed43 原服务 17:40 在 M1 已成功训练后，被残留的 `run_seed==42` 只读验收误报。修复为显式 `expected_seed` 后复验原 SFT/M1 的 92 条，不重采样、不重训；新 recovery 目录仅 fresh 执行剩余 M2 的 72 条，20:10:20 完成。原 FAILED、summary 和日志保留，恢复导入来源与哈希可追溯。

最终 BF16 actor 各约 8.22 GiB，不含 optimizer/critic/RNG。成功臂每臂 1,104 个临时 Adam raw 在导出和证据验收后退休，保留 owner/manifest/交换事件/收据。seed43 M1 因验收误报遗留的暂存，经复验、移到新验收目录后才退休；没有把临时 moments 当作可恢复 checkpoint。

## 网格扩大日期与未完成评估的处理

10/06 固定两 seed、actor LR `1e-7/2e-7`、每 LR 的 M1 和 M2 η`0.125/0.25`，共 12 次四轮 RL；critic LR `1e-6`，同共同奖励与八个训练窗。每 seed SFT 60 条评估，每 RL 臂 32 条训练 + 120 条评估，总预算 1,944 次尝试（384 训练、1,560 评估）。seed42 按 LR/η正序、seed43 反序，不按中途结果追加 η、seed 或轮数。

开发评估扩大为原 Train 内 screen-dev 的 12 个互不重叠 21-session 窗 `0210/0231/0252/0273/0294/0315/0336/0357/0378/0399/0420/0441`，覆盖 2023-11-01—2024-10-31 共 252 交易日，与训练日期隔离。奖励标定历史上已接触这些日期，仍是开发评估，非 untouched holdout 或正式 OOS。主要方法增量比较相同 LR/seed/轮次/窗口/解码的 M2−M1，不能用额外 η 搜索机会掩盖同条件消融。

原协议首批只尝试 SFT 50 条（49 完整、1 未完成）即按严格规则停止；0399 greedy 当前 MSFT 权重 20.137266%，连续 253 次 buy 到20%，256次交互耗尽，响应均22tokens正常 stop。这是拒单恢复弱点，无 M1/M2 更新。

R1 显式采用 `retain_prefix_v1`：评估触及原交互上限时保留 INCOMPLETE prefix，金融收益/Y 为空；传输用 0 单列为 transport-only，不能充当零收益。所有评估槽位仍须尝试；训练不完整、工程故障或身份异常仍停止。共同完整窗口差值须报告覆盖和排除数，完整流程带评估失败可为 `COMPLETE_WITH_EVALUATION_FAILURES`，不表示性能 PASS。

R1 于 10/06 18:23:32 在 M2 第三轮生成前 vLLM wake_up 失败，CUDA OOM：本 worker 分配基本不变，全卡空闲却在约半分钟由 23.66 GiB 降至 13.61 GiB，失败时约余 5 MiB；支持共享容量骤降，未识别占用者，无新增 host OOM。共 288 条落盘（282 完整、6 greedy 未完成），48 条训练全部完整：

| R1 seed42 条件 | 实际更新/完整训练 | 完整评估 | 停止时产物 |
|---|---|---|---|
| SFT | 0 / — | 59/60 | 共同模型 |
| M1 LR1e-7 | 4 / 32 | 116/120 | 第四轮 actor 无损归档 |
| M2 LR1e-7 η0.125 | 2 / 16 | 59/60 | 未到第四轮，无同步 actor checkpoint |

M1 第四轮 sampled 0.4693%，同窗 SFT 0.4828%（−0.0135 个百分点）；greedy 仅共同完整 10/12 窗、+0.0891 个百分点，不能概括为全覆盖改善。失败 M2 第二轮 sampled 0.5039%，较同期 M1 +0.0842；greedy 在共同完整 9 窗低于 M1 0.3830 个百分点。缺第四轮及 seed43，不能选 η 或判断稳定参数范围。部分模型仍主要交易三股、约60%现金；失败 prefix 的 241/253 次连续非法另计，不能只报完整轨迹非法率。

新网格采用绑定 SFT v3 的无损 tensor XOR 归档，保存 HF 布局/完整 SHA，逐块恢复必须精确匹配原分片后才退休展开权重；归档目录本身不能直接加载。真实 4B 回放从 8,822,893,976 bytes 压到约119MiB并精确恢复。首次398/399张量布局检查失败，补明确 tied embedding 映射后新目录通过，未改训练权重。归档依赖共同 SFT v3 完整基座；不含 optimizer/critic/RNG，不支持续训。

## 持久占位与 R2—R5 历史过程

10/07 建立持久 holder（无六小时自动到期），目标76GiB、上限80GiB、至少留2GiB驱动空闲。10/08 12:55 达76GiB，空闲约16.57GiB。协调器认领租约后暂停增长，worker模型初始化和各大分配阶段前检查真实容量、释放自有占位后复查；运行中保持零持有，控制组全部退出后才自动补回。控制器退出但Ray等子进程仍持显存时继续暂停，真实CUDA测试覆盖了这种情况。

该版本只抵扣已验证当前worker的物理驻留，其他残留GPU进程不能当作可用容量；release与接手仍有竞争窗口，非独占保证。新任务通过CLI prepare绑定当前服务并封存配置；旧封存R1不会自动获得新合同，也没有可续训的失败M2模型。

| 10/08 新身份 | 历史结果（全部零轨迹、零更新，截止各自注明时刻） |
|---|---|
| R2，15:57→16:00 | critic通过，reference前检查因宿主机/容器PID不同无法识别自身驻留，失败；不是磁盘不足 |
| R3，16:17→16:20 | GPU设备文件检查误拒CPU控制器/trainer/Ray，初始化失败；打开设备文件不等于持有显存 |
| R4，16:25→16:30 | critic/reference/actor初始化及交接通过，vLLM报无可用cache blocks；外部负载是否影响profiling未证明 |
| R5，16:42启动；16:52快照 | 新增启动前稳定60秒门禁，实测占位76GiB、总可用92.53GiB；三模型及vLLM初始化通过，随后rollout容量等待：当前物理驻留约30.14GiB、驱动空闲约33.00GiB，所需45.86GiB |

R5 对自身驻留只计已映射 native 默认池，排除 sleep 后private/CuMem虚拟记录，删除CPU进程设备文件误拒条件；实验参数和76GiB预算不变。上表最后一行只是10/08 16:52的快照，**不表示现在仍在等待**。后续最终报告确认R5于10/09 07:30完成固定网格，含29条未完成greedy评估；完整性能与10/11诊断勘误统一读[最终报告](../2026-10-11_M2_PARAMETER_GRID_R5_REPORT.md)。

跨批账目：原批50次、R1 288次，共338次历史尝试；R2/R3/R4各0次；R5另有1,944次，合计2,282次，不把旧失败轨迹拼入新批，也不把模板中的旧累计1,994当作R5总账。资源CUDA probe中控制器等补回超时曾exit1，holder随后补足另有核验；不能把整个probe服务改写为成功退出。

## 磁盘清理的已执行结果

| 时间与范围 | 实际结果及保留影响 |
|---|---|
| 10/05，两轮成功pilot的两处moment scratch | 经确认清理2,208个raw，实际释放约114.16GiB；模型、轨迹和8份owner/manifest哈希不变 |
| 10/08 13:13，旧4B A2及1.7B M2的四份optimizer | 分配空间80.41GiB，文件已不存在；模型/元数据不变，增加pruned标记，失去原Adam续训能力；可用容量仍约77.89GiB，并未增加80GiB |
| 10/08 14:32，R1失败M2暂存 | 先试删78个raw约1GiB、再删637个约32GiB，共715个，实际可用77.88→110.88GiB；保留389个约24.08GiB及owner/manifest、失败日志/轨迹，新增部分清理标记 |

80GiB旧文件删除后，ZFS `df Used` 与 `Size` 都约降80GiB，而`Avail`基本不变；`Size≈referenced+available`解释显示总量变化，不证明物理盘缩容。容器查询看不到管理数据集/存储池，快照引用、父级配额或reservation都是未验证原因；不能直接认定快照。近期33GiB回收成功也不能证明旧80GiB已经回收。历史审计保留宿主机只读查询和原始收据；没有把估计释放量当实际准入容量。

R5启动前实际约110.87GiB可用，超过107GiB门槛；运行逐臂检查约90GiB moments替换峰值、9GiB导出、8GiB余量。旧SFT v3同时是共同起点和XOR解码基座，模型清理需保留其依赖；历史盘点中的“当前保留”仅描述当时状态，后续存储变化以新收据为准。

## 证据入口与范围

| 事项 | 仓库根目录下的证据 |
|---|---|
| 失败pilot与数值探针 | `runs/m2-low-memory-pilot-20260930/FINAL_RESULTS.md`、`failure_diagnosis_20261002.json`；`m2-low-memory-preparation-20260930/optimizer_cuda_probe_v2.json` |
| 成功交接pilot | `runs/m2-low-memory-handoff-20261004/{completion_readout.json,comparison_summary.csv,state.json,reservation_cleanup.json}`；[小型结果快照](../results/2026-10-04-backup/README.md) |
| seed42四轮 | `runs/m2-sft-four-round-comparison-20261004/{comparison_readout.json,evaluation_curve.csv,comparison_summary.csv,service_completion.json}` |
| seed43复验/恢复 | `runs/m2-seed43-revalidation-20261005/revalidation.json`；`m2-sft-four-round-comparison-seed43-20261005-recovery/{recovery_contract.json,comparison_readout.json,completion_review.json}` |
| 原网格/R1失败 | `runs/m2-grid-preparation-20261006/failure_analysis.json`；`m2-parameter-grid-20261006-r1/{status_review_20261007.json,grid_readout.json,paired_comparisons.csv}`及失败M2的`trainer.log` |
| 无损归档 | `runs/m2-grid-preparation-20261006/archive-roundtrip-v2/roundtrip_receipt.json`；`src/agents/parameter_grid_archive.py`中的`restore_cell_archive` |
| 持久资源协调 | `runs/gpu-reservation-persistent-20261007/verification_receipt.json`、`normal-probe-v2/`、`orphan-probe/`；`runs/m2-parameter-grid-20261008-r5/{execution_context.json,startup_verification.json,resource_wait_snapshot.json}` |
| 清理与ZFS复查 | `runs/disk-audit-20261004/scratch_cleanup_receipt.json`；`runs/disk-audit-20261008/{optimizer_cleanup_receipt.json,storage_diagnosis_20261008.json,recent_scratch_cleanup_probe_20261008.json,recent_scratch_cleanup_bounded_20261008.json}` |

各批通过独立systemd用户服务运行，`Linger=yes`、`Restart=no`，日志和冻结源码/输入身份持久化；未做真实网络中断注入测试。工程失败、未完成评估、金融表现和服务退出分别保留，旧ETA、排队及占位快照不作为当前进度。

本阶段只有两个训练seed、原Train内开发评估，无A1/A2及正式Valid/Final OOS。共同SFT带三股/20%清仓教师先验，请求seed还含policy step，因此SFT0与RL不是完全相同随机数的配对。工程可运行和局部正向均值支持后续检验，不能替代稳定方法优势；后续研究现状以[近期文档索引](../README.md)为准。
