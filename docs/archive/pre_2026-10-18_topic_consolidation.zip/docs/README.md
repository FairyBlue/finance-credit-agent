# 文档导航

更新：2026-10-17（UTC+8）；最新多状态 CPU 验证已完成。

当前优先解决同 prefix 取样与合法具体订单菜单，暂不扩大 RL。共同恢复验收、动作池化四轮对照、CPU 机制与多状态验证均已完成；当前 Train 开发结果未建立 M2 池化收益优势，正式 Valid / Final OOS 未开启。

## 当前结果与下一步

| 阅读入口 | 结论 / 用途 |
|---|---|
| [当前进度与下一步](2026-10-11_M2_NEXT_STEPS.md) | 完成记录、当前 CPU 验证顺序及后续独立确认条件 |
| [多状态具体订单验证](2026-10-17_M2_STATE_ORDER_ORACLE_REPORT.md) | 1024 个移植 cell 完成；后期同状态与同订单同伴稀缺，原 gate 消去可区分订单，优先调整比较单位 |
| [CPU credit oracle 试验](2026-10-14_M2_CREDIT_ORACLE_PROBE_REPORT.md) | 同质平均可降独立扰动误差；同族异质可能损坏排序，原 gate 存在具体订单盲点；期限与后续策略影响 credit 目标 |
| [动作池化机制分析](2026-10-14_M2_ACTION_POOLING_MECHANISM_REPORT.md) | 残差能量下降不等于功劳更准确；量化订单、前置状态及更新信号差异 |
| [动作池化四轮对照](2026-10-12_M2_ACTION_POOLING_COMPARISON_REPORT.md) | 1336/1336 条完整；第 4 轮 sampled 中两个 seed 的 M2 均低于 plain 及两档 M1 |
| [共同恢复 SFT 与最终验收](2026-10-11_M2_ORDER_RECOVERY_SFT_REPORT.md) | SFT 72 次更新，最终 1200/1200 条验收 PASS；完整回合仍有拒单，但均在第一次后续请求恢复 |
| [参数网格 R5](2026-10-11_M2_PARAMETER_GRID_R5_REPORT.md) | 10 月 9 日完成；12 次 RL 各四轮，29 条 greedy 未完成；旧 SFT / 观察版本不能与新 plain 拼接 |

10 月 11 日的[首轮恢复](2026-10-11_M2_ORDER_RECOVERY_REPORT.md)与[反馈 v2](2026-10-11_M2_ORDER_RECOVERY_V2_REPORT.md)保留为诊断过程。封存方案：[恢复 SFT](2026-10-11_M2_ORDER_RECOVERY_LEARNING_PLAN.md)、[四轮对照](2026-10-12_M2_ACTION_POOLING_COMPARISON_PLAN.md)、[CPU 试验](2026-10-14_M2_CREDIT_ORACLE_PROBE_PLAN.md)、[多状态验证](2026-10-17_M2_STATE_ORDER_ORACLE_PLAN.md)。这些方案记录执行前约定，文中准备状态不代表当前待办；结果以上表报告为准。

## 10 月 10 日前的阶段汇总

| 阶段 | 核心内容 |
|---|---|
| [一：H100 与 M1](history/01_H100_AND_M1.md) | 8 月 27 日—9 月 2 日环境、数据与真实更新接线通过，尚非性能结果 |
| [二：screening 工程](history/02_M2_SCREENING_ENGINEERING.md) | R1—R5 的生成与内存修复；76 条工程轨迹完整，当时无交易及非零 residual 覆盖 |
| [三：行为诊断](history/03_M2_BEHAVIOR_DIAGNOSTICS.md) | schema、记忆、任务理解与动作覆盖；接口修复后仍缺稳定自主交易 |
| [四：概率排查](history/04_INFERENCE_PROBABILITY.md) | 原始生成概率读取正确，精确配对未完成；停止扩展底层排查 |
| [五：共同初始化与学习](history/05_COMMON_INITIALIZATION_AND_LEARNING.md) | 9 月 12—18 日冷启动、共同 SFT、短 RL、日期/解码诊断及罚则队列终态 |
| [六：4B 对照与资源修复](history/06_4B_COMPARISON_AND_RUNTIME.md) | 9 月 30 日—10 月 8 日低显存、两 seed 四轮、网格 OOM 与重启、占位和磁盘历史记录 |

历史流水和纯跳转交接文件已合并或移除，直接阅读上述总结。[原文 ZIP 与 SHA 清单](archive/README.md)保留未提交材料及失败原文，供核验旧执行身份；不在原路径保留跳转壳。

## 设计、协议与复现

[研究说明](../RESEARCH_BRIEF.md) · [正式评测协议](../EVAL_PROTOCOL.md) · [M2 历史筛选规格](../M2_V1_PREREGISTRATION.md) · [安装说明](../SETUP.md) · [H100 版本合同](H100_COMPATIBILITY.md) · [接手指南](EXPERIMENT_HANDOFF.md) · [协作方式](COLLABORATION.md)。

早期 [screening 设计](2026-09-05_M2_EXPERIMENT_PLAN_V2.md)与 [R1](2026-09-06_M2_SCREENING_EXECUTION_AMENDMENT_R1.md) / [R2](2026-09-07_M2_SCREENING_EXECUTION_AMENDMENT_R2.md) / [R3](2026-09-07_M2_SCREENING_EXECUTION_AMENDMENT_R3.md) / [R4](2026-09-07_M2_SCREENING_EXECUTION_AMENDMENT_R4.md) / [R5](2026-09-08_M2_SCREENING_EXECUTION_AMENDMENT_R5.md)修订保留为历史合同。被代码读取的旧方案保留其规则和预算；若导航链接有整理，旧哈希须核对 ZIP 原文或该次 `runs/.../plan.md`，不可用整理后文本替代原始身份。

[9 月 17 日](results/2026-09-17-backup/README.md)及 [10 月 4 日](results/2026-10-04-backup/README.md)的结果快照仅代表各自采集时点，历史副本和 manifest 不随最新进度更新。快照构建器依赖当时原文，重建需在隔离副本恢复相应归档，不能直接覆盖当前整理后的文档。

`runs/` 链接指向本机证据，不代表随源码上传。旧容量、占位和服务状态均为历史读数；实际资源及模型可恢复性须核对对应收据和文件，不能从旧文档推定当前状态。
