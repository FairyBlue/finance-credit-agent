# M2 动作池化对照执行记录

2026-10-12，SGT（UTC+8）。

**本批于2026-10-14 02:38:44 SGT全部完成，真实退出码0。**1336/1336条完整（256训练、1080评估），无缺失或未完成，两个seed的十个cell均COMPLETE，执行与金融覆盖均COMPLETE。八个RL臂均actor/critic各四次更新、归档和moment退役完成；旧失败及退出码保留。见[真实退出收据](../runs/m2-action-pooling-comparison-20261013-v6/service_exit_receipt.json)、[最终读数](../runs/m2-action-pooling-comparison-20261013-v6/stage2_readout.json)及[终态](../runs/m2-action-pooling-comparison-20261013-v6/LIVE_STATUS.md)。第四轮sampled中，M2相对plain和两档M1在两个seed的配对均值差均为负，当前开发结果不支持动作池化的净收益增益；不作显著性或OOS结论。

## 本批回答的问题

从第一步已验收的新共同恢复SFT重新训练M1（LR 1e-7）、M1（LR 2e-7）、M2-plain及M2（后两者LR 1e-7、η 0.25）。两个配对seed、各四轮，第2及第4轮评估，共1336条：256训练、1080评估。两个seed均先取得共同SFT参考；seed43反转RL臂顺序。

plain与M2共享推进步对齐、动作分歧gate、critic、η和whitening，只改变个体收益与同动作family平均收益的池化。主要看第4轮sampled的M2−plain配对差值，同时对照两档M1、成本、风险和完整率。第2轮只看趋势，不选checkpoint。plain不是标准GRPO。

本批使用新共同SFT、`history_features_recovery_v2`及统一0.05训练拒单惩罚；不能拼接旧R5结果。第一步已完成证据依原历史快照核验，旧失败保留。12个评估窗口仍属已接触的Train开发范围；正式Valid与FinalOOS未开启，当前没有动作池化有效性的结论。

## 启动准备

- 两seed目录准备完成，共同模型、数据窗口、四轮预算及实际Hydra配置已核对。
- v1及v2两seed输入预检均PASS，每份20个窗口、21个session完整回放及拒单反馈回放通过；最长正常提示4593、拒单提示4870 tokens，均小于8192。v2重新准备及预检后封存，[根合同](../runs/m2-action-pooling-comparison-20261012-v2/run_contract.json)SHA为`01211c736b8276f2d52ac7a068bae65656c3a3bf053d7f6dbe4b16f6c1c31592`，104份源码/运行配置封存并通过合同检查。
- 编排、plain credit、共同惩罚、critic初始化、配对评估和读数均做CPU检查；真实systemd退出码0/7均已验证。已完成臂的校验错误须立即停止，不允许被PARTIAL汇总掩盖后继续下一臂。

[工程检查证据](../runs/m2-action-pooling-comparison-20261012-v2/engineering_validation/summary.json)记录各次独立测试及源码SHA；显存监控39项、最终入口与旧流程兼容58项、服务42项、历史归档12项测试通过，读数与既有兼容检查另行记录，不把重复测试累计成独立样本。

- 启动仍要求实际可用磁盘至少107GiB。仅对六组固定旧actor做无损归档；全部原分片SHA重建一致后另行退役原分片，保留原轨迹、日志、summary、lineage、收据和模型元数据。第一步四个新actor、新共同SFT及旧moment暂存均保留。
- 持久服务直接运行controller，退出后记录真实systemd退出码；不自动重试。每个成功RL臂完成证据校验、临时moment退役及actor无损归档后，才按真实df决定下一臂能否开始。

六组旧actor全部原分片SHA重建通过，独立原分片共52937363856字节（49.3018GiB），归档706035945字节（0.6575GiB）；[归档证明](../runs/m2-action-pooling-storage-20261012-v1/pack_proof.json)已落盘。最终全量复核后退役54份独立分片、63个可见路径，[退役收据](../runs/m2-action-pooling-storage-20261012-v1/retirement_receipt.json)为COMPLETE。实际df回收后115.3494GiB可用，超过107GiB门槛，见[真实空间记录](../runs/m2-action-pooling-comparison-20261012-v2/engineering_validation/disk_admission.json)。没有把删除字节计为已释放空间。

## 未启动的v1封存

18:12 SGT启动前复查发现外部GPU占用约11GiB，与76GiB占位合计约87GiB。原生runner只有阶段容量准入及资源采样，缺少计划要求的总体80GiB停止检查。因此v1没有启动trainer、模型评估或systemd正式服务，保留[封存合同](../runs/m2-action-pooling-comparison-20261012-v1/run_contract.json)及[启动前替代记录](../runs/m2-action-pooling-comparison-20261012-v1/prelaunch_superseded.json)。旧合同SHA为`7e4704e771b45aed5600207ab9d4f9430e189e8b8be3cc6f60cbe7aad33625c0`。

v2维持同一方案、数据、模型和预算，仅补齐资源检查后重新封存。交接阶段严格核验同一controller、claim及暂停中的holder，沿用1800秒有界等待；holder的payload、allocated、reserved全部归零后，单向启用整卡实际80GiB停止线。训练阶段不扣减外部占用；超限、租约或遥测异常使本批失败，由专用service清理自己的子进程并记录真实退出码。逐次采样的停止检查不等于瞬时分配硬上界。外部进程不操作。

## 正式执行

专用unit为`m2-action-pooling-comparison-20261012-v2.service`，真实MainPID为3733368，直接运行本批controller。Restart=no、KillMode=control-group、MemoryMax64GiB、RuntimeMax48h；[启动收据](../runs/m2-action-pooling-comparison-20261012-v2/launch_receipt.json)为LAUNCHED，[实际服务观察](../runs/m2-action-pooling-comparison-20261012-v2/initial_service_observation.json)确认active/running及真实主进程命令。

先执行seed42共同SFT参考，随后四个RL臂；seed43先SFT、再反序执行四臂。服务启动不等于训练或评估完成；整批结果、退出码和方法判断须等待实际收据。目前没有M2相对plain的性能结论。

**18:38:09 SGT实际进展：**[首批运行观察](../runs/m2-action-pooling-comparison-20261012-v2/initial_progress_observation.json)记录seed42共同SFT已返回30/60条，30条原始状态均COMPLETE，观察版本、seed与arm匹配；全批已返回30/1336，整臂独立校验尚待其余轨迹。推理服务持续处理真实请求，GPU守卫已ACTIVE，活动阶段整卡采样峰值67.6123GiB，低于80GiB；unit仍active/running。四个RL臂尚待SFT参考完成后启动，不将这30条当作方法对照结果。

## 汇总读取失败与勘误

**20:04:46 SGT原v2服务结束。**[根状态](../runs/m2-action-pooling-comparison-20261012-v2/state.json)为FAILED，[真实退出收据](../runs/m2-action-pooling-comparison-20261012-v2/service_exit_receipt.json)记录数值1。原始轨迹实际落盘212条：seed42共同SFT60条，以及M1（LR 1e-7）32条训练、120条评估。M1 actor与critic各完成四次更新，两臂trainer均exit0。其余八个cell未启动。

根因是新增`action_pooling_readout._identity`将每轮两个训练窗口的编号误判为0/1；原生训练从prepared训练集传入全局0–7编号，第二轮实际为2/3。测试夹具也重复了错误假设。fail-closed门禁因此拦住后续臂；训练协议、轨迹配对和模型更新没有发现相应错配。修复仍要求窗口属于当前轮次，同时核对全局编号，不接受两种编号口径。

只读采用正确编号复核后，两个已完成cell的212条均完整，初始critic head及共同SFT一致。M1的9份HF分片已按原收据无损归档，独立流式解码后原SHA全部吻合；临时moments按原清单退役。M1 GPU守卫实际采样峰值68.46GiB，未触发80GiB停止线；停止后holder恢复76GiB、无claim。该错误属于读取器实现，不是训练OOM或模型恢复失败。

旧v2目录、冻结源码、原summary、FAILED状态及exit1均保留。[修复前只读快照](../runs/m2-action-pooling-readout-audit-20261012-v1/original_snapshot.json)记录旧目录512份文件SHA和修复前合同检查PASS。[修正读取器的实际轨迹复核](../runs/m2-action-pooling-readout-audit-20261012-v1/corrected_reader_actual_prefix.json)、[M1更新及GPU守卫回放](../runs/m2-action-pooling-readout-audit-20261012-v1/actual_m1_training_and_guard_verification.json)、[9份分片无损验证](../runs/m2-action-pooling-readout-audit-20261012-v1/completed_m1_archive_verification.json)单独保存，均未发起新模型请求或改写原证据。旧错误读数曾只计入SFT60条，不代表实际只返回60条。

## v3显式执行剩余任务

[恢复合同](../runs/m2-action-pooling-comparison-20261012-v3/recovery_contract.json)绑定原v2全目录SHA、两份完整cell副本、原执行身份与summary，以及本次工程改动。只允许读取器、根编排、服务分派三份既有源码变化及新增专用恢复入口；训练、credit、环境、观察、随机种子、GPU守卫和数据生成源码与原封存一致。两seed的prepared train/dev/calibration逐字节相同，model/settings/selection与原批次一致；原CPU输入预检原样复制并纳入新合同。原目录512份文件与修复前快照完全一致。

原seed42的SFT60条及M1低LR152条按字节导入，不重训、重评或恢复优化器。新任务顺序固定为seed42的M1高LR、plain、M2，共456条；随后seed43的SFT、M2、plain、M1高LR、M1低LR，共668条。新增1124条，累计仍1336；失败即停止，不自动重试，不挑选已完成结果。导入模型已经归档，因此复验通过流式解码原SHA完成，不重新归档或重复退役。

本次综合CPU检查145项首先通过，另1项测试的错误文字正则修正后复验通过；生产代码的拒绝行为原本正确，源码未因此改变。[最终工程收据](../runs/m2-action-pooling-readout-audit-20261012-v1/repair_integration_final_receipt.json)保留初次检查及复验链接；两个真实systemd opt-in测试未重复启动。恢复入口31项、读取器与旧读数兼容63项分别通过，计数存在重叠，不相加作为独立检验。Ruff检查通过。

[新根合同](../runs/m2-action-pooling-comparison-20261012-v3/run_contract.json)SHA为`57dac1613a079b73558034f3bb5deb67f1d934eaad3b710c759abfdb3006baeb`，封存105份源码/配置。[启动前观察](../runs/m2-action-pooling-comparison-20261012-v3/prelaunch_observation.json)记录真实空闲123537326080字节（约115.05GiB），高于107GiB；holder76GiB、无claim。新unit为`m2-action-pooling-comparison-20261012-v3.service`，直接MainPID3756088，21:14:57 SGT启动；[启动收据](../runs/m2-action-pooling-comparison-20261012-v3/launch_receipt.json)为LAUNCHED。沿用原Restart=no、control-group清理、64GiB主机内存、48h上限及真实退出码取证。

**21:19:03 SGT实际观察：**[服务及交接观察](../runs/m2-action-pooling-comparison-20261012-v3/initial_service_observation.json)确认active/running，root与seed42均RUNNING，当前`m1_lr2e7`。原生Ray已启动，守卫108份采样仍处于WAITING_HOLDER_RELEASE；holder76GiB已暂停并绑定新claim，尚未清零。新增raw为0，累计仍212/1336，不能据服务启动断言新训练或评估已经完成。

此时整卡另有约16.44GiB外部进程占用。交接前仅按原规则扣除已验证的自有可释放holder payload；holder归零后，外部占用全部计入整卡80GiB停止线。容量准入的有界等待不保证提前为80GiB线预留足够空间，后续仍可能因整卡超限而停止。原门槛不放宽，外部进程不操作；实际产出及终态以新批次原始轨迹和退出收据为准。

**21:20:11 SGT v3实际失败：**[真实退出收据](../runs/m2-action-pooling-comparison-20261012-v3/service_exit_receipt.json)记录数值1。原生worker在`critic_init_model → before_phase → TorchGpuSampler.__call__ → torch.cuda.synchronize(0)`时报告CUDA OOM。holder仍持有76GiB、外部进程约16.44GiB，整卡物理空闲仅约127MiB；错误发生于占位释放前的初始化准入采样/同步阶段，具体分配点尚未定位，尚未训练或生成轨迹。守卫始终WAITING_HOLDER_RELEASE、ACTIVE未启用，停止不是80GiB线触发。

高LR M1新增raw、rollout_seed、actor/critic更新、fit、配对评估及checkpoint均为空，导入的212条完整证据不受影响。原v3目录、源快照、失败日志、guard166份采样、FAILED及exit1保留。[零输出失败启动审计](../runs/m2-action-pooling-readout-audit-20261012-v1/v3_failed_zero_output_launch_audit.json)绑定502份原文件SHA、真实exit1及零新增科学证据；新入口还会独立复核实际文件，不能只相信审计声明的零计数。下一次显式执行拟在每个native cell启动前，先用CPU/NVML及严格核验的holder状态检查“非holder占用＋固定76GiB阶段预算≤80GiB”，最多等待1800秒；未达到预算就不启动CUDA进程，到期停止，不自动重试。不更改GPU协调器、训练设置或原80GiB停止线。

## v4启动前预算等待

恢复入口新增CPU门禁，固定76GiB阶段预算与80GiB总体上限，最多等1800秒。每次仅执行holder的status操作及`nvidia-smi`查询；前后holder状态一致、身份与allocator合法时才扣除实际payload，context及allocator余量仍计入非holder占用。连续两次新鲜采样满足预算后，重新检查实际磁盘，再交给原native runner。门禁不claim、不释放holder、不初始化CUDA，也不承诺采样后资源不会变化；原ACTIVE总体80GiB守卫保留。

每个剩余cell都执行相同门禁，包括seed43的SFT；同一controller正常回填中的holder可继续，陌生claim或异常遥测立即失败。门禁收据与采样写在seed目录中，等待时尚不创建cell目录；超时保留TIMEOUT和真实失败退出，不重试。固定八cell顺序、训练协议、moment退役、actor无损归档及读数校验不变。

21:41:39 SGT，[v4联测收据](../runs/m2-action-pooling-readout-audit-20261012-v1/v4_cpu_budget_integration_receipt.json)记录恢复入口与原编排101项CPU测试全部通过，测试前后源码SHA一致；[完整日志](../runs/m2-action-pooling-readout-audit-20261012-v1/v4_cpu_budget_integration_pytest.log)保留。独立恢复门禁测试72项及Ruff亦通过，计数有重叠，不相加。新入口源码SHA为`523666c0070cfb58c3a09503509c8785e68d49623dfa91d2dc7d71559b0faf3c`。v2/v3原目录与失败证据不改写。

v4[根合同](../runs/m2-action-pooling-comparison-20261012-v4/run_contract.json)SHA为`990a1b501b3473d89394de5ec1be4ad0629da72b8e70ac04a3a27c4a8c2d8ad4`，封存105份源码/配置；[恢复合同](../runs/m2-action-pooling-comparison-20261012-v4/recovery_contract.json)同时绑定原212条、固定余下1124条、新CPU门禁及v3零输出失败审计。21:45:26 SGT，[启动前观察](../runs/m2-action-pooling-comparison-20261012-v4/prelaunch_observation.json)确认真实可用123378728960字节（约114.91GiB）高于107GiB，holder76GiB、无claim；v2的512份及v3的502份文件仍与历史快照逐项一致，余下八cell目录均不存在。此时仅表示可启动CPU等待服务，不代表GPU预算已满足。

新unit为`m2-action-pooling-comparison-20261012-v4.service`，21:45:52 SGT启动，直接MainPID3758706；[启动收据](../runs/m2-action-pooling-comparison-20261012-v4/launch_receipt.json)为LAUNCHED。21:46:51 SGT，[CPU排队实际观察](../runs/m2-action-pooling-comparison-20261012-v4/initial_cpu_queue_observation.json)确认active/running、当前seed42高LR M1、连续两份采样仍WAITING_FOR_GPU。实测非holder占用11.7236GiB，预算总量87.7236GiB，大于80GiB，故ready=false。八个剩余cell目录均未创建，service cgroup未出现native trainer，holder保持76GiB且无claim；新轨迹0，累计212/1336。服务在等待容量，没有恢复GPU训练；到期行为以真实退出收据为准。

通用seed `LIVE_STATUS.md`中的“60GiB空闲门槛”仍是旧渲染文字，不是v4的CPU准入条件；本次等待以[实时排队读数](../runs/m2-action-pooling-comparison-20261012-v4/seed42/gpu_queue_state.json)及[门禁收据](../runs/m2-action-pooling-comparison-20261012-v4/seed42/native_budget-m1_lr2e7.json)中的76/80GiB预算为准。

## 2026-10-13进展与容量口径

实际显卡为H100 NVL，`nvidia-smi`报告95,830MiB，即93.583984GiB。80GiB是本批额外采用的保守软件停止线，源于前一步诊断及本批执行方案，不是显卡物理总容量；holder的76GiB目标及80GiB自身分配上限另有各自含义。本次不需要放宽80GiB即可重新启动。

v4后来通过了最初的等待，并完成seed42高LR M1、M2-plain，各32条训练、120条评估，actor/critic各4次更新；原始轨迹完整，无未完成评估。两组ACTIVE整卡采样峰值分别68.4971及68.4541GiB，均成功归档并退役各自临时moments。连同SFT及低LR M1，共516条（96训练＋420评估）。

停止点是下一组pooled M2启动前：00:31:37至01:01:33 SGT的347份预算采样均为非holder11.993164GiB、holder payload credit为0，加76GiB预算得87.993164GiB，持续超过80GiB，1800.004秒后TIMEOUT，01:01:38 SGT主进程实际exit1。该M2目录未创建、没有trainer或科学产出；seed43未开始。v4整次已新增304条，只有待启动的M2是零输出，不能把整次标为零输出。

[修改前完整快照](../runs/m2-action-pooling-timeout-audit-20261013-v1/v4_original_snapshot.json)绑定v4的682份文件、1,112,089,632字节及修改前合同检查PASS，旧FAILED与exit1保留。[当前资源复查](../runs/m2-action-pooling-timeout-audit-20261013-v1/current_resource_recheck.json)于13:00:42 SGT确认holder76GiB、无claim，真实空闲16.5693GiB；核验并扣除holder payload后，固定76GiB预算加其他占用为77.0146GiB，满足原80GiB。实际可用磁盘123059306496字节，高于107GiB。资源会变化，正式启动仍须重新准入。

另查明，原`run_cell`首次运行时在controller父进程直接调用`verify_gpu_runtime_and_model`，其中`torch.cuda.get_device_name(0)`初始化父CUDA；这与v4的`controller_idle`回补DEFERRED原因一致。末次11.993GiB为非holder总体占用，可能包含controller上下文，不能全部归因外部进程。新执行入口将原运行检查移入短命子进程，退出后再调用原runner，使controller保持CPU状态；训练、奖励、配对种子及GPU阈值不变。

新入口固定`cpu_budget_timeout_after_four_cells_v1`，保留原根profile及1336条科学预算，导入四cell516条、仅执行六cell820条；对比v4只允许恢复入口这一份工程源码变化，source inventory、GPU守卫、协调器及训练源码保持原样。[CPU验证收据](../runs/m2-action-pooling-timeout-audit-20261013-v1/v5_cpu_continuation_validation_receipt.json)记录恢复入口与编排联合140项测试通过、Ruff通过；[日志](../runs/m2-action-pooling-timeout-audit-20261013-v1/v5_cpu_continuation_pytest.log)保存。源码SHA为`66ecfb14dc2e007f72a3986152d507845c6143e69da1ab5e2323e54213340129`。正式准备另行全量复核四cell轨迹、更新、共同critic head及三份RL归档原SHA，不还原原始权重或优化器。

首次v5 CPU准备在模型执行前被证据比较拦住，见[原失败收据](../runs/m2-action-pooling-timeout-audit-20261013-v1/v5_prepare_receipt.json)：v4导入的低LR M1汇总仍引用原v2的actor-update绝对路径，而从v4副本核验得到相同SHA、不同绝对路径key；其余指标一致。修复对固定原PREFIX2先核对完整cell目录字节相等，再在已绑定的v2 canonical origin上执行严格validator；新两臂仍核v4。不放松SHA、不归一化任意路径、不改旧summary。[针对性验证](../runs/m2-action-pooling-timeout-audit-20261013-v1/v5_canonical_origin_validation_receipt.json)6项通过、Ruff通过，当前封存候选源码SHA为`73c157d03d320bdff483d606479fb8b388714809b39c1648b9e9763f800e6053`。首次失败日志保留，未启动GPU；第二次CPU准备结果另留收据。

13:24:21 SGT，[第二次真实CPU准备](../runs/m2-action-pooling-timeout-audit-20261013-v1/v5_prepare_attempt2_receipt.json)实际exit0，四cell轨迹/更新/head及三份RL无损归档全量验证通过；源码与针对性验证一致。v5[根合同](../runs/m2-action-pooling-comparison-20261013-v5/run_contract.json)SHA为`381825325bef6f57ab751ba1b050cb43e535e6c186ec4abb0f5debb775482bb5`，105份源码/配置封存，[恢复合同](../runs/m2-action-pooling-comparison-20261013-v5/recovery_contract.json)绑定原v4的全部682份文件、516条历史证据及固定余下820条。

13:25:25 SGT，[启动前复查](../runs/m2-action-pooling-comparison-20261013-v5/prelaunch_observation.json)确认77.0146GiB预算仍满足80GiB门槛；holder76GiB、无claim，真实磁盘122583908352字节高于107GiB，旧v4仍与快照逐字节一致。余下六cell目录不存在，尚未进行新模型请求；新服务首次启动仍会重新做CPU准入及隔离运行预检。

13:26:06 SGT，新unit `m2-action-pooling-comparison-20261013-v5.service`启动，直接MainPID3793347，[启动收据](../runs/m2-action-pooling-comparison-20261013-v5/launch_receipt.json)为LAUNCHED。13:29:52 SGT，[原生GPU启动观察](../runs/m2-action-pooling-comparison-20261013-v5/initial_native_gpu_observation.json)记录active/running、seed42 pooled M2 trainer PID3793453、CPU预算连续两份采样READY、原GPU守卫ACTIVE，holder的payload/allocated/reserved均0且租约匹配controller。[隔离运行预检收据](../runs/m2-action-pooling-comparison-20261013-v5/seed42/runtime_preflight_probe/receipt.json)实际returncode0，parent_cuda_before/after均false；CUDA主进程预检交接问题已在真实启动中核实修复。此时新增raw0，累计516/1336；新训练尚无更新或终局结果，不能据启动判断M2优势。

## 2026-10-13晚间状态复查

v5新增364条（seed42 M2的152条、seed43 SFT60条及M2的152条），连同原516条共880条，独立核原始记录为160训练＋720评估，全部COMPLETE、complete=true，0未完成/错误。seed42为COMPLETE；seed43仍欠plain、M1高LR、M1低LR，三个目录均不存在。五个已完成RL各actor4/critic4，共各20次更新，归档与owned moment退役收据均COMPLETE；所有已运行GPU守卫COMPLETE/return0，最高ACTIVE采样峰值70.5166GiB，未触发80GiB停止线。

17:03:09至17:33:04 SGT，seed43 plain的CPU门禁保留347份coherent采样：实际holder payload credit持续76GiB，nonholder恒14.05371094GiB，预算总量90.05371094GiB，ready始终false。[门禁收据](../runs/m2-action-pooling-comparison-20261013-v5/seed43/native_budget-m2_plain_lr1e7_eta025.json)为TIMEOUT，1800.0045秒后结束；17:33:09 SGT真实主进程exit1。plain没有启动trainer或产生科学输出，不是M2训练失败或CUDA OOM。当前服务failed/MainPID0，不会自动重试。本次复查未启动新模型请求或修改原run证据。

两seed的隔离运行预检均exit0、parent CUDA前后均false；controller_idle均记录REFILLING，末段采样的实际76GiB payload证明占位回补已生效。此前父CUDA预检问题没有复发，当前阻塞是80GiB预算规则下容量等待超时。

当前完整seed42的第4轮Train开发集读数如下，净收益为百分比，greedy及sampled分开：

| 模型 | Greedy净收益 | Sampled净收益 |
|---|---:|---:|
| SFT | 0.7367% | 0.6132% |
| M1 LR=1e-7 | 0.7621% | 0.9288% |
| M1 LR=2e-7 | 0.9774% | 0.9751% |
| M2-plain | 1.1047% | 0.9115% |
| M2 | 0.7261% | 0.8734% |

[现成配对报告](../runs/m2-action-pooling-comparison-20261013-v5/stage2_paired_comparisons.csv)中，M2−plain为greedy −0.378638、sampled −0.038086个百分点，12个共同完整窗口、分别12/48槽位，零配对排除。M2对两档M1的差值也为负；当前seed42尚未显示池化额外收益，不据此作显著性或方法失败判断。seed43 M2的greedy/sample为0.7168%/0.7384%，其SFT为0.6940%/0.9580%；plain/M1还没有可配对槽位，不能形成两seed池化对照结论。SFT与RL的sampled种子包含不同policy_step，二者不是exact CRN。所有读数仍是既有Train开发窗口，正式Valid/OOS未开启。下一步只需补齐剩余三组456条，保留已完成880条；阶段读数仍为PARTIAL、金融覆盖INCOMPLETE，服务执行终态为FAILED。

## 2026-10-13晚间继续剩余三组

用户指出当前显存已足够后，[22:50:52 SGT资源复查](../runs/m2-action-pooling-latest-timeout-audit-20261013-v1/current_resource_recheck.json)确认holder76GiB、无claim，其他占用1.01465GiB，固定启动预算合计77.01465GiB，满足80GiB；实际可用磁盘114.712GiB满足107GiB。17:33的失败是当时等待超时；服务Restart=no，资源恢复不会自动重启。当前资源已不构成启动阻碍，正在显式准备保留880条、仅补seed43 plain→M1高LR→M1低LR，共456条。

[原v5修改前快照](../runs/m2-action-pooling-latest-timeout-audit-20261013-v1/v5_original_snapshot.json)绑定911份文件、1,885,367,250字节及22:48:28 SGT真实合同检查exit0；旧FAILED及exit1保留。新执行仍使用原科学协议、四轮、共同SFT、数据和配对seed，不重跑任何已完成cell，不恢复优化器。

新入口固定`cpu_budget_timeout_after_seven_cells_v1`：导入七组880条，seed42不再发起预算等待、运行预检或trainer；seed43只执行plain→M1高LR→M1低LR，三组456条。通过冻结的v2/v4/v5来源链核对原始绝对路径及整目录SHA，critic head分别在seed42、seed43内核验一致，不要求两seed同head。相对v5仅恢复入口工程源码变化，105份源码/配置清单及训练协议保持不变。

[CPU回归收据](../runs/m2-action-pooling-latest-timeout-audit-20261013-v1/v6_cpu_validation_receipt.json)记录63项针对性检查通过、Ruff通过，以及真实v5快照、祖先合同、七组canonical证据核验通过。当前源码SHA为`82fd7adf7049097303c4c195f7b597ef7274e1cef14ec428e1593452ff60199e`。[测试日志](../runs/m2-action-pooling-latest-timeout-audit-20261013-v1/v6_cpu_continuation_pytest.log)单独保存，未重复全部旧测试。正式准备重放v5新增的两份M2归档；三个更早RL归档通过此前完整验收合同及全部历史文件SHA继承验证，不声称本次全部五份重新解码。

23:04:07 SGT，[真实v6准备收据](../runs/m2-action-pooling-latest-timeout-audit-20261013-v1/v6_prepare_receipt.json)实际exit0：880条证据复核通过，两份新增M2归档完整原SHA重放通过，祖先三RL归档沿旧完整验收及不可变目录继承。v6[根合同](../runs/m2-action-pooling-comparison-20261013-v6/run_contract.json)SHA为`d8a2ea952cf38805da642f48ac271f7ff7c9e72e825b25f3bebc7b55dc1c0ca9`，105份源码/配置封存；[恢复合同](../runs/m2-action-pooling-comparison-20261013-v6/recovery_contract.json)绑定原v5快照、原失败退出及精确余下456条。

23:05:23 SGT，[启动前复查](../runs/m2-action-pooling-comparison-20261013-v6/prelaunch_observation.json)再次确认预算77.01465GiB满足80GiB，holder76GiB、无claim，真实可用磁盘122415218688字节满足107GiB，三个待运行目录均不存在；原v5仍与911份文件快照完全一致。此时资源已允许启动，不是继续等待显存。

23:06:09 SGT，`m2-action-pooling-comparison-20261013-v6.service`首次启动，直接MainPID3834917；[启动收据](../runs/m2-action-pooling-comparison-20261013-v6/launch_receipt.json)为LAUNCHED。23:10:28 SGT，[实际原生GPU观察](../runs/m2-action-pooling-comparison-20261013-v6/initial_native_gpu_observation.json)确认active/running、当前seed43 plain、trainer PID3835181、CPU预算连续两份采样READY、运行预检exit0且父CUDA前后false，原GPU守卫ACTIVE；holder payload/allocated/reserved全部0，claim匹配controller。seed42新状态COMPLETE、imported668/new0，未创建新budget或runtime probe，证明没有重跑。此时新raw0、累计880/1336；本次真实模型任务已恢复，尚无新终局结果。

## 2026-10-14最终完成及开发集结果

本批于02:38:44 SGT全部结束，[真实退出收据](../runs/m2-action-pooling-comparison-20261013-v6/service_exit_receipt.json)记录controller_returncode=0。[终态](../runs/m2-action-pooling-comparison-20261013-v6/state.json)为COMPLETE，两个seed及十个cell均完成；原880条按合同继承，本次新增456条，累计1336条（256训练＋1080评估），原始记录全部完整，零缺失、零未完成。八个RL臂各完成actor/critic四次更新，合计各32次；八份actor归档与八份owned moment退役收据均COMPLETE。未重跑已完成cell、未恢复优化器，也未自动重试旧失败。

各已运行GPU守卫均COMPLETE、returncode=0，ACTIVE采样最高70.5166GiB，未触发80GiB停止线。本次新增三臂最高57.4785GiB。完成后服务inactive/dead、Result=success；复查GPU利用率为0，仅保留原持久holder，GPU停止训练是正常结束。

[最终读数](../runs/m2-action-pooling-comparison-20261013-v6/stage2_readout.json)为execution_status=COMPLETE、financial_status=COMPLETE，issues为空。第4轮开发集平均净收益如下，数值单位为百分比；SFT为共同初始化的step0基线。

| 模型 | Seed42 greedy | Seed42 sampled | Seed43 greedy | Seed43 sampled |
|---|---:|---:|---:|---:|
| SFT | 0.7367% | 0.6132% | 0.6940% | 0.9580% |
| M1 LR=1e-7 | 0.7621% | 0.9288% | 0.5785% | 0.8042% |
| M1 LR=2e-7 | 0.9774% | 0.9751% | 0.8011% | 0.8526% |
| M2-plain | 1.1047% | 0.9115% | 0.6535% | 0.8314% |
| M2 | 0.7261% | 0.8734% | 0.7168% | 0.7384% |

[最终配对比较](../runs/m2-action-pooling-comparison-20261013-v6/stage2_paired_comparisons.csv)中的sampled净收益差为：

| 第4轮配对差值（百分点） | Seed42 | Seed43 |
|---|---:|---:|
| M2 − M2-plain | -0.0381 | -0.0930 |
| M2 − M1 LR=1e-7 | -0.0555 | -0.0657 |
| M2 − M1 LR=2e-7 | -0.1017 | -0.1142 |

每项均有12个共同完整窗口、48个sampled配对槽位，零排除、零缺失。Greedy方向混合：M2−plain在seed42为−0.3786个百分点、seed43为＋0.0633个百分点；M2对高LR M1在两个seed上仍均为负。两类解码结果分别报告，不合并为单一优势判断。SFT与RL的sampled种子包含不同policy_step，二者不是exact CRN，池化判断以RL臂间配对为依据。

当前四轮、两个seed、12个既有Train开发窗口的结果未显示预定的池化收益增益。读数中的performance_pass=false与formal_performance_claim=false表示未建立性能优势，不表示执行失败；本批也没有开启正式Valid或Final OOS，不作显著性或方法普遍失效结论。第二步执行及读数已完成，第三步尚未开始。随后完成了存档机制分析与CPU试验（见下文）；当前先验证状态条件下的具体订单credit，暂不扩大训练量。

2026-10-14，[机制分析](2026-10-14_M2_ACTION_POOLING_MECHANISM_REPORT.md)已完成，量化了同批信号变化、前置状态及订单异质性、逐窗收益和费用敏感度。其后的[CPU机制试验](2026-10-14_M2_CREDIT_ORACLE_PROBE_REPORT.md)也已完成；当前先定义并验证具体订单credit目标、分组、gate和状态基线，详见[下一步](2026-10-11_M2_NEXT_STEPS.md)。本批历史证据和正式结果不改写。
