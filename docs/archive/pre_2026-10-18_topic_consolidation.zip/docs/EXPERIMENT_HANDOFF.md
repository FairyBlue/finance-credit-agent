# 实验接手指南

状态基线：2026-10-14，UTC+8。当前两 seed、四轮动作池化对照已完成，1336/1336 条完整，
但固定第 4 轮 sampled 的 M2−plain 分别为 −0.0381/−0.0930 个百分点，未建立池化优势。
随后存档机制分析和 CPU oracle 试验也已完成；当前先验证同状态下具体订单的 credit，暂不扩大 RL。
正式 Valid 与 Final OOS 保持关闭。

## 接手顺序

1. 先读 [RESEARCH_BRIEF](../RESEARCH_BRIEF.md)、[EVAL_PROTOCOL](../EVAL_PROTOCOL.md)
   和 [M2 screening 规范](../M2_V1_PREREGISTRATION.md)，区分正式研究提案、已批准协议与当前实现。
   state/regime anchor 和 M3 仍属未实现提案，当前 M2 只按同日动作族池化。
2. 阅读[下一步计划](2026-10-11_M2_NEXT_STEPS.md)、
   [完成对照](2026-10-12_M2_ACTION_POOLING_COMPARISON_REPORT.md)、
   [机制分析](2026-10-14_M2_ACTION_POOLING_MECHANISM_REPORT.md)和
   [CPU credit 试验](2026-10-14_M2_CREDIT_ORACLE_PROBE_REPORT.md)。
   具体状态、原始计数与执行身份以各报告绑定的收据为准。
3. 需要背景时从[文档导航](README.md)读阶段总结：
   [H100/M1](history/01_H100_AND_M1.md)、[screening 工程](history/02_M2_SCREENING_ENGINEERING.md)、
   [行为诊断](history/03_M2_BEHAVIOR_DIAGNOSTICS.md)、[概率排查](history/04_INFERENCE_PROBABILITY.md)、
   [共同初始化与学习](history/05_COMMON_INITIALIZATION_AND_LEARNING.md)、
   [4B 对照与运行恢复](history/06_4B_COMPARISON_AND_RUNTIME.md)。
4. 安装查 [SETUP](../SETUP.md)和 [H100_COMPATIBILITY](H100_COMPATIBILITY.md)，
   协作查 [COLLABORATION](COLLABORATION.md)。新工程调试与训练统一使用 Qwen3-4B；
   旧 1.7B 命令、runbook commit 和容量记录只属于历史运行。

## 当前工作边界

共同拒单恢复已通过[固定范围验收](2026-10-11_M2_ORDER_RECOVERY_SFT_REPORT.md)，
仍会发生可恢复的无效请求。池化对照使用新的共同 SFT 和观察版本，不能与旧 R5 拼接。
CPU 试验发现同族异质订单的排序损失、具体订单分歧 gate 盲点和状态基线误差；
下一步固定 credit 目标、期限和后续策略，在预先选定的 Train 状态上分别验证分组、gate 与 baseline，
报告四兄弟 singleton 覆盖。未来 oracle 标签仅用于离线评价，不直接接入训练或提示。

复核结果时区分完整轨迹、actor/critic 实际更新、模型保存和金融表现；失败不补零，
不将 script/teacher 成交算作模型自主交易，不把工程 PASS 写成方法优势。
正式对照和 M2−M1 superiority gate 仍需按原协议冻结，已有开发结果不能替代它们。

`runs/`、大部分 `data/` 和模型权重不随源码同步；只取得源码时需另取对应运行归档。
[9/17](results/2026-09-17-backup/README.md)与 [10/04](results/2026-10-04-backup/README.md)
是历史备份，模型是否可恢复以实际清单为准。旧报告已汇入阶段总结，历史执行合同保留；
原始字节与哈希核验使用[原文 ZIP](archive/pre_2026-10-10_documents.zip)及其
[manifest](archive/pre_2026-10-10_manifest.json)，最新进度读导航。人工时间统一使用 UTC+8。
