# M2 参数网格 R1：保留未完成评估，继续固定训练对照

登记：2026-10-06，新加坡时间（UTC+8）。R1 独立服务已于 **16:23:45 SGT** 启动。
状态复查：**2026-10-07 20:55 SGT**，R1 已于 **10月6日18:23:32 SGT 因 CUDA OOM 停止**。
首个 M1 四轮已完成执行验收；首个 M2 两轮后在下一轮生成前唤醒推理引擎失败。
本修订规则及封存副本保留，部分结果和资源诊断见[执行报告（阶段汇总）](history/06_4B_COMPARISON_AND_RUNTIME.md)。
实际进度见[实时状态](../runs/m2-parameter-grid-20261006-r1/LIVE_STATUS.md)。

本修订服务于用户确认的本轮目的：看清性能稳定范围和现存问题，寻找下一步提升方案。
参数、模型、日期与判读沿用[原网格计划（阶段汇总）](history/06_4B_COMPARISON_AND_RUNTIME.md)。

## 已观察到的问题

原服务 15:50:53 SGT 启动，16:03:08 SGT 停止，状态 FAILED。
seed42 共同 SFT 评估已尝试 50 条：49 COMPLETE、1 INCOMPLETE；M1/M2 尚未更新。
失败在 `formal-train-0399` 的 greedy 第 0 轮：2024-08-08 当前 MSFT 权重
20.137266%，却连续 253 次请求 `buy(MSFT, target_weight=0.2)`，全部拒单，未推进日期。
错误反馈在实际请求中可见，近期错误记录饱和后状态及 prompt 固定，最终达到 256 交互上限。
每次响应仅 22 tokens，未触及单响应 4096-token cap；不是 thinking 重复问题。
同窗四条 sampled 均完整，但前置轨迹不同，不能据此推断同一状态采样一定恢复。

[原失败状态](../runs/m2-parameter-grid-20261006/state.json)、原模型与全部轨迹保留。
详见[失败诊断收据](../runs/m2-grid-preparation-20261006/failure_analysis.json)。

## 修订的执行规则

只对本批显式启用 `retain_prefix_v1`，环境变量
`FINANCE_GRID_EVALUATION_INCOMPLETE=retain_prefix_v1`。默认及旧实验保持严格停止。

- 仅在评估中、已有真实输出且达到原 256-step 上限而未终止时，保留实际未完成 prefix。
  原证据仍标记 INCOMPLETE，记录拒单、请求、日期和完整性；不生成终局收益或金融 Y。
- 返回上游的实际 prefix 仅用于使评估批次完成传输，reward 0 明确标记 transport-only。
  通用验证日志改为 transport-only 名称；实际金融结果始终从完整原始轨迹读取。
- 训练轨迹仍须完整；未完成训练、工程异常、缺失身份、超出输入/响应边界仍硬失败。
  不改变非法请求的执行结果，不增加推理时投资规则。
- 所有计划评估槽位都须尝试并核对身份；完整率和失败率是主要读数之一。
  不完整评估的收益为空，不记成零，不使用未完成 prefix 的账面盈亏充当终局收益。
- 同配置收益差只在双方共同完整的窗口/采样槽位上计算，报告覆盖与排除数量。
  若所有槽位执行完但有不完整评估，执行状态为 COMPLETE_WITH_EVALUATION_FAILURES，
  金融覆盖为 INCOMPLETE，不标记性能 PASS。

## 固定预算与留存

R1 新目录 `runs/m2-parameter-grid-20261006-r1/`，新 profile v2、新源码/输入合同。
仍为 seed42/43，actor LR 1e-7/2e-7，每 LR 的 M1 η0、M2 η0.125/0.25；critic LR 1e-6。
每臂四轮、32 条完整训练；第 2/4 轮各 12 窗 ×（greedy1 + sampled4）。
每 seed 共同 SFT 60 条评估及六个 RL 臂，R1 共 1,944 次预定轨迹尝试。
原失败批次 50 次尝试另列，总计划尝试数 **1,994**；不导入或筛选原失败批次的部分轨迹。
重执行是为了检查改后的评估隔离协议；相同失败再次出现时照样保留为 INCOMPLETE。
不增加 seed、η、轮数、正式 Valid/OOS 或 A1/A2，也不重新训练共同 SFT。

沿用已经实测的无损模型归档、成功训练臂 moments 退休、串行 GPU 准入与独立 systemd 服务。
模型归档/训练验收与金融评估覆盖分别记录；实际训练与模型导出完整才允许归档。
网络或客户端断线不结束服务；无自动重跑，最长 48 小时。
每完成一臂更新收益、配对覆盖、失败摘要、交易行为与训练诊断，最终统一判断。

## 启动前验收

607 项集成测试及补充 78 项证据校验测试，共 **685 项通过**，Ruff 与 diff 检查通过；
包括真实环境 256-step 拒单循环回放、
完整评估语义不变、训练拒绝不完整、无收益填零、实际 14 条 Hydra 命令和整网格失败状态。
两 seed 共 40 个完整 CPU 窗口回放通过，最大 prompt 4,593 tokens。
R1 的两个 seed 的 train/dev/calibration 与原批次逐字节一致。
沿用已完成的真实 4B 无损归档精确恢复验收，归档实现仅增加明确的 v2 profile 白名单。
[验收收据](../runs/m2-parameter-grid-20261006-r1/implementation_validation.json)。
[补充校验收据](../runs/m2-parameter-grid-20261006-r1/supplementary_validation.json)。

服务为 `m2-parameter-grid-20261006-r1.service`，Linger=yes、Restart=no、标准输入关闭、
MemoryMax64G、RuntimeMax48h。启动时空闲显存约 73.85 GiB；
[启动收据](../runs/m2-parameter-grid-20261006-r1/launch_receipt.json)。
